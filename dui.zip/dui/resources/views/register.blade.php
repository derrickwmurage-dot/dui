<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($title) ? $title.' - '.config('app.name') : config('app.name') }}</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">

    <link rel=icon href="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" sizes="16x16" type="image/png">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        .custom-gradient {
            background: linear-gradient(to top right, rgba(248, 170, 52, 1), rgba(36, 110, 213, 1));
        }
    </style>
</head>
<body class="custom-gradient min-h-screen">
    <!-- Toast Notifications -->
    <div class="fixed top-0 left-0 right-0 z-50 flex justify-center mt-4 px-4">
        @if(session('success'))
            <div class="toast bg-green-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105">
                {{ session('success') }}
            </div>
        @endif
        @if($errors->any())
            <div class="toast bg-red-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="min-h-screen flex flex-col md:flex-row items-center justify-center p-4">
        <!-- Left side image -->
        <div class="hidden lg:block w-full md:w-1/2 xl:w-2/3 p-8 transform transition-all duration-700 hover:-translate-y-6">
            <img 
            src="https://perplexing-beans-assets.vercel.app/assets/auth/africa2.jpg" 
            alt="" 
            class="rounded-3xl shadow-2xl object-cover transform transition duration-500 hover:scale-105 w-full h-full"
            >
        </div>

        <!-- Register form -->
        <div class="w-full md:w-1/2 xl:w-1/3 px-4 md:px-8 lg:px-12">
            <div class="bg-white bg-opacity-10 rounded-2xl p-8 shadow-2xl backdrop-filter backdrop-blur-lg">
                <div class="text-center mb-8">
                    <h1 class="text-3xl md:text-4xl font-bold text-white mb-2">Create Account</h1>
                    <p class="text-blue-200">Sign up to start your journey</p>
                </div>

                <form id="registerForm" action="{{ route('register') }}" method="POST" class="space-y-6">
                    @csrf
                    <div class="space-y-2">
                        <label class="text-blue-100 font-medium">Email Address</label>
                        <input type="email" name="email" id="email" placeholder="Enter Email Address" class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-opacity-50 transition duration-300" required>
                    </div>

                    <div class="space-y-2">
                        <label class="text-blue-100 font-medium">Password</label>
                        <input type="password" name="password" id="password" placeholder="Enter Password" minlength="6" class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-opacity-50 transition duration-300" required>
                    </div>

                    <button type="submit" id="submitButton" class="w-full py-3 px-4 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition duration-300 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Sign Up
                    </button>

                    <div class="relative my-6">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-white border-opacity-20"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 text-blue-200 bg-transparent">Or continue with</span>
                        </div>
                    </div>

                    <button type="button" class="w-full py-3 px-4 bg-white text-gray-800 font-medium rounded-lg flex items-center justify-center space-x-2 transition duration-300 transform hover:scale-105 hover:shadow-xl" onclick="signInWithGoogle()">
                        <svg class="w-5 h-5" viewBox="0 0 48 48">
                            <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
                            <path fill="#FF3D00" d="m6.306 14.691 6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/>
                            <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
                            <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
                        </svg>
                        <span>Sign up with Google</span>
                    </button>
                </form>

                <p class="mt-8 text-center text-blue-200">
                    Already have an account? 
                    <a href="{{ route('login') }}" class="font-medium text-white hover:text-blue-400 transition duration-300">Login here</a>
                </p>
            </div>

            <p class="text-center text-blue-200 text-sm mt-8">&copy; 2025 Duit Technology</p>
        </div>
    </div>

    <!-- Firebase Configuration -->
    <script type="module">
        // Import the functions you need from the SDKs you need
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
        import { getAuth, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

        async function initializeFirebase() {
            try {
                // const response = await fetch('/auth/firebase-config');
                // const config = await response.json();

                // if (config.error) {
                //     throw new Error(config.error);
                // }

                // // Initialize Firebase
                // const app = initializeApp({
                //     apiKey: config.apiKey,
                //     authDomain: config.authDomain,
                //     projectId: config.projectId,
                //     storageBucket: config.storageBucket,
                //     messagingSenderId: config.messagingSenderId,
                //     appId: config.appId,
                // });
                const app = initializeApp({
                    apiKey: "{{ env('FIREBASE_API_KEY') }}",
                    authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
                    projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
                    storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
                    messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
                    appId: "{{ env('FIREBASE_APP_ID') }}",
                });

                // Initialize Auth
                return getAuth(app);
            } catch (error) {
                console.error('Firebase initialization error:', error);
                // alert('Failed to initialize Firebase: ' + (error.message || 'Unknown error'));
            }
        }

        // Initialize auth globally
        const authPromise = initializeFirebase();

        // Make signInWithGoogle available globally
        window.signInWithGoogle = async function() {
            try {
                const auth = await authPromise;
                const provider = new GoogleAuthProvider();
                const result = await signInWithPopup(auth, provider);
                
                // Get the user information
                const user = result.user;
                const userData = {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    photoURL: user.photoURL
                };

                // Send to your backend
                const response = await fetch('/auth/google/callback', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ user: userData })
                });

                const data = await response.json();

                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    throw new Error(data.error || 'Authentication failed');
                }

            } catch (error) {
                console.error('Sign-in error:', error);
                // alert('Google sign-in failed: ' + (error.message || 'Unknown error'));
            }
        }

        // Form submission handling
        document.getElementById('registerForm').addEventListener('submit', function() {
            document.getElementById('submitButton').disabled = true;
        });

        // Automatically remove toast notifications after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                document.querySelectorAll('.toast').forEach(function(toast) {
                    toast.classList.add('opacity-0');
                    setTimeout(function() {
                        toast.remove();
                    }, 500);
                });
            }, 5000);
        });
    </script>
</body>
</html>