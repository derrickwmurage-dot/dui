<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invest in Africa - Empowering African Ventures</title>
    <link href="{{ asset('style.css') }}" rel="stylesheet">

    <link rel=icon href="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" sizes="16x16" type="image/png">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
</head>
<body class="bg-gradient-to-b from-slate-50 to-white">
    <nav class="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-slate-200">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex h-16 items-center justify-between">
                <div class="flex items-center">
                    <img src="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" alt="Logo" class="h-8 w-8 mr-2">
                    <span class="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-yellow-600 bg-clip-text text-transparent">Invest in Africa</span>
                </div>
                <div class="hidden md:flex items-center gap-8">
                    <a href="#features" class="text-slate-600 hover:text-yellow-600 transition-colors">Features</a>
                    <a href="#testimonials" class="text-slate-600 hover:text-yellow-600 transition-colors">Testimonials</a>
                    <a href="{{ route('home') }}">
                        <button class="bg-yellow-600 text-white px-6 py-2 rounded-full hover:bg-yellow-700 transition-all shadow-lg hover:shadow-yellow-200">
                            Get Started
                        </button>
                    </a>
                </div>
                <button id="mobile-menu-button" class="md:hidden text-slate-600 p-2 hover:bg-slate-100 rounded-lg transition-colors">
                    <i class="ph ph-list text-2xl"></i>
                </button>
            </div>
            
            <!-- Mobile Menu -->
            <div id="mobile-menu" class="md:hidden hidden">
                <div class="px-2 pt-2 pb-3 space-y-1">
                    <a href="#features" class="block px-3 py-2 text-slate-600 hover:text-yellow-600 hover:bg-slate-100 rounded-lg transition-colors">
                        Features
                    </a>
                    <a href="#testimonials" class="block px-3 py-2 text-slate-600 hover:text-yellow-600 hover:bg-slate-100 rounded-lg transition-colors">
                        Testimonials
                    </a>
                    <a href="{{ route('home') }}" class="block px-3 py-2">
                        <button class="w-full bg-yellow-600 text-white px-6 py-2 rounded-full hover:bg-yellow-700 transition-all shadow-lg hover:shadow-yellow-200">
                            Get Started
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="pt-32 pb-24 px-4">
        <div class="max-w-6xl mx-auto text-center">
            <div class="absolute top-40 left-1/2 -translate-x-1/2 w-full h-96 bg-gradient-to-r from-yellow-500/30 to-yellow-500/30 blur-3xl -z-10 animate-pulse-slow"></div>
            <span class="inline-block animate-fade-in px-4 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium mb-4">
                Empowering African Ventures 🚀
            </span>
            <h1 class="text-4xl md:text-6xl font-bold mb-6 animate-slide-up">
                Invest in
                <span class="bg-gradient-to-r from-emerald-400 to-yellow-600 bg-clip-text text-transparent">Africa's Future</span>
            </h1>
            <p class="text-lg text-slate-600 mb-8 max-w-2xl mx-auto animate-slide-up">
                Join us in supporting innovative African startups and ventures. Together, we can drive growth and create lasting impact.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-slide-up">
                <a href="{{ route('home') }}">
                    <button class="group bg-yellow-600 text-white px-8 py-3 rounded-full text-lg font-medium hover:bg-yellow-700 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2">
                        Start Investing
                        <i class="ph ph-arrow-right group-hover:translate-x-1 transition-transform"></i>
                    </button>
                </a>
            </div>
            <div class="relative rounded-xl overflow-hidden shadow-2xl animate-fade-in">
                <div class="absolute inset-0 bg-gradient-to-tr from-yellow-600/20 to-yellow-600/20"></div>
                <img 
                src="https://perplexing-beans-assets.vercel.app/assets/homepage/handshake.jpg"
                alt="Investing in Africa" 
                class="w-full"
                />
            </div>
        </div>
    </section>

    <!-- Features -->
    <section id="features" class="py-24 bg-white">
        <div class="max-w-6xl mx-auto px-4">
            <div class="text-center mb-16">
                <span class="text-yellow-600 font-medium">Features</span>
                <h2 class="text-3xl md:text-4xl font-bold mb-4">Why Invest with Us</h2>
                <p class="text-slate-600 max-w-2xl mx-auto">Discover the benefits of investing in African ventures through our platform.</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="group p-6 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-xl transition-all">
                    <div class="w-12 h-12 bg-yellow-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <i class="ph ph-chart-line-up text-2xl text-white"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">High Growth Potential</h3>
                    <p class="text-slate-600">Invest in startups with high growth potential and innovative solutions.</p>
                    <ul class="mt-4 space-y-2 text-slate-600">
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            Diverse portfolio
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            Expert guidance
                        </li>
                    </ul>
                </div>
                <div class="group p-6 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-xl transition-all">
                    <div class="w-12 h-12 bg-yellow-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <i class="ph ph-shield-check text-2xl text-white"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Secure Investments</h3>
                    <p class="text-slate-600">Your investments are protected with top-notch security measures.</p>
                    <ul class="mt-4 space-y-2 text-slate-600">
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            Transparent processes
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            Regulatory compliance
                        </li>
                    </ul>
                </div>
                <div class="group p-6 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-xl transition-all">
                    <div class="w-12 h-12 bg-yellow-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <i class="ph ph-lightning text-2xl text-white"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Fast and Easy</h3>
                    <p class="text-slate-600">Investing in African ventures has never been easier.</p>
                    <ul class="mt-4 space-y-2 text-slate-600">
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            User-friendly platform
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="ph ph-check text-yellow-600"></i>
                            Quick transactions
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section id="testimonials" class="py-24 bg-white">
        <div class="max-w-6xl mx-auto px-4">
            <div class="text-center mb-16">
                <span class="text-yellow-600 font-medium">Testimonials</span>
                <h2 class="text-3xl md:text-4xl font-bold mb-4">What Our Investors Say</h2>
                <p class="text-slate-600 max-w-2xl mx-auto">Hear from our investors about their experiences with our platform.</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="bg-slate-50 p-6 rounded-2xl">
                    <div class="flex items-center gap-4 mb-4">
                        <img src="https://placehold.co/48x48/6366F1/FFFFFF/png" alt="Avatar" class="rounded-full"/>
                        <div>
                            <div class="font-medium">Sarah Johnson</div>
                            <div class="text-slate-600 text-sm">Investor at TechCorp</div>
                        </div>
                    </div>
                    <p class="text-slate-600">"Investing in African startups through this platform has been a rewarding experience. The growth potential is immense."</p>
                    <div class="flex gap-1 mt-4 text-yellow-400">
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                    </div>
                </div>
                <div class="bg-slate-50 p-6 rounded-2xl">
                    <div class="flex items-center gap-4 mb-4">
                        <img src="https://placehold.co/48x48/6366F1/FFFFFF/png" alt="Avatar" class="rounded-full"/>
                        <div>
                            <div class="font-medium">Mark Thompson</div>
                            <div class="text-slate-600 text-sm">Venture Capitalist at StartupX</div>
                        </div>
                    </div>
                    <p class="text-slate-600">"The platform's security and compliance measures give me confidence in my investments."</p>
                    <div class="flex gap-1 mt-4 text-yellow-400">
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                    </div>
                </div>
                <div class="bg-slate-50 p-6 rounded-2xl">
                    <div class="flex items-center gap-4 mb-4">
                        <img src="https://placehold.co/48x48/6366F1/FFFFFF/png" alt="Avatar" class="rounded-full"/>
                        <div>
                            <div class="font-medium">Emily Chen</div>
                            <div class="text-slate-600 text-sm">Angel Investor at DataCo</div>
                        </div>
                    </div>
                    <p class="text-slate-600">"The ease of use and quick transactions make investing in African ventures a breeze."</p>
                    <div class="flex gap-1 mt-4 text-yellow-400">
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                        <i class="ph ph-star-fill"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-yellow-700 text-white py-12">
        <div class="max-w-6xl mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8 mb-8">
                <div>
                    <span class="text-2xl font-bold">Invest in Africa</span>
                    <p class="text-slate-400 mt-2">Empowering African ventures through strategic investments.</p>
                    <div class="flex space-x-4 mt-4">
                        <a href="https://twitter.com/DuitTechnology" class="text-slate-400 hover:text-white transition-colors">
                            <i class="ph ph-twitter-logo text-xl"></i>
                        </a>
                        <a href="https://www.linkedin.com/company/duit-technology-limited/" class="text-slate-400 hover:text-white transition-colors">
                            <i class="ph ph-linkedin-logo text-xl"></i>
                        </a>
                        <a href="https://www.instagram.com/duittechnology?igsh=dmczdjUyNzRjNXJj" class="text-slate-400 hover:text-white transition-colors">
                            <i class="ph ph-instagram-logo text-xl"></i>
                        </a>
                        <a href="https://www.tiktok.com/@duittechnology?lang=en" class="text-slate-400 hover:text-white transition-colors">
                            <i class="ph ph-tiktok-logo text-xl"></i>
                        </a>
                    </div>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Company</h4>
                    <ul class="space-y-2 text-slate-400">
                        <li><a href="https://duitechnology.com" class="hover:text-white transition-colors">Home</a></li>
                        <li><a href="https://duitechnology.com/about" class="hover:text-white transition-colors">About</a></li>
                        <li><a href="https://duitechnology.com/investors" class="hover:text-white transition-colors">Investors</a></li>
                        <li><a href="https://duitechnology.com/companies" class="hover:text-white transition-colors">Companies</a></li>
                        <li><a href="https://duitechnology.com/blog" class="hover:text-white transition-colors">Blogs</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Resources</h4>
                    <ul class="space-y-2 text-slate-400">
                        <li><a href="https://duitechnology.com/apply" class="hover:text-white transition-colors">Apply To Invest</a></li>
                        <li><a href="https://duitechnology.com/companies" class="hover:text-white transition-colors">Apply for Investment</a></li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-slate-800 pt-8 text-center text-slate-400">
                <p>&copy; 2025 Duit Technology. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script>
        // Mobile menu toggle functionality
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        
        mobileMenuButton.addEventListener('click', () => {
            const isHidden = mobileMenu.classList.contains('hidden');
            
            // Toggle menu visibility
            if (isHidden) {
                mobileMenu.classList.remove('hidden');
                mobileMenu.classList.add('animate-fade-in');
            } else {
                mobileMenu.classList.add('hidden');
                mobileMenu.classList.remove('animate-fade-in');
            }
            
            // Optional: Change hamburger icon to close icon
            const icon = mobileMenuButton.querySelector('i');
            icon.classList.toggle('ph-list');
            icon.classList.toggle('ph-x');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('#mobile-menu a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.add('hidden');
                const icon = mobileMenuButton.querySelector('i');
                icon.classList.add('ph-list');
                icon.classList.remove('ph-x');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', (event) => {
            if (!mobileMenuButton.contains(event.target) && 
                !mobileMenu.contains(event.target) && 
                !mobileMenu.classList.contains('hidden')) {
                mobileMenu.classList.add('hidden');
                const icon = mobileMenuButton.querySelector('i');
                icon.classList.add('ph-list');
                icon.classList.remove('ph-x');
            }
        });
    </script>
</body>
</html>