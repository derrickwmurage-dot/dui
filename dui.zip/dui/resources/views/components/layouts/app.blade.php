<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-theme="bumblebee">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ isset($title) ? $title.' - '.config('app.name') : config('app.name') }}</title>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css" />

    {{-- Flatpickr  --}}
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    {{-- Currency --}}
    <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/robsontenorio/mary@0.44.2/libs/currency/currency.js"></script>

    {{-- <link rel="apple-touch-icon" sizes="180x180" href="https://perplexing-beans-assets.vercel.app/assets/favicons/apple-touch-icon.png"> --}}
    {{-- <link rel="icon" type="image/png" sizes="32x32" href="https://perplexing-beans-assets.vercel.app/assets/favicons/favicon-32x32.png"> --}}
    {{-- <link rel="icon" type="image/png" sizes="16x16" href="https://perplexing-beans-assets.vercel.app/assets/favicons/favicon-16x16.png"> --}}
    {{-- <link rel="manifest" href="https://perplexing-beans.vercel.app/assets/favicons/site.webmanifest') }}"> --}}

    <link rel=icon href="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" sizes="16x16" type="image/png">

    {{-- PhotoSwipe --}}
    <script src="https://cdn.jsdelivr.net/npm/photoswipe@5.4.3/dist/umd/photoswipe.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/photoswipe@5.4.3/dist/umd/photoswipe-lightbox.umd.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/photoswipe@5.4.3/dist/photoswipe.min.css" rel="stylesheet">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen font-sans antialiased bg-base-200/50 dark:bg-base-200">

    <div>
        <x-nav sticky full-width>
            <x-slot:brand>
                {{-- Drawer toggle for "main-drawer" --}}
                <label for="main-drawer" class="lg:hidden mr-3">
                    <x-icon name="o-bars-3" class="cursor-pointer" />
                </label>
        
                {{-- Brand --}}
                    <div class="flex items-center">
                        <img src="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" alt="Logo" class="h-8 w-8 mr-2">
                        <span>Invest in Africa</span>
                    </div>
            </x-slot:brand>
        
            {{-- Right side actions --}}
            <x-slot:actions>
                <x-theme-toggle darkTheme="sunset" lightTheme="bumblebee" />
                <x-button label="Profile" icon="o-user" link="/profile" class="btn-ghost btn-sm" responsive />
                {{--<x-button icon="o-bell" class="btn-circle relative">
                    <x-badge value="2" class="badge-error absolute -right-2 -top-2" />
                </x-button>--}}
                <x-button label="Logout" icon="o-power" link="/logout" class="btn-ghost btn-sm" responsive />
                {{-- <x-button label="Logout" icon="o-power" link="/logout" class="btn-ghost btn-sm" responsive /> --}}
            </x-slot:actions>
        </x-nav>
    </div>
    
    {{-- MAIN --}}
    <x-main full-width>
        {{-- SIDEBAR --}}
        <x-slot:sidebar drawer="main-drawer" collapsible class="bg-base-100 lg:bg-inherit">
    
            
            {{-- MENU --}}
            <x-menu activate-by-route>
    
                {{-- User
                @if($user = auth()->user())
                    <x-menu-separator />
    
                    <x-list-item :item="$user" value="name" sub-value="email" no-separator no-hover class="-mx-2 !-my-2 rounded">
                        <x-slot:actions>
                            <x-button icon="o-power" class="btn-circle btn-ghost btn-xs" tooltip-left="logoff" no-wire-navigate link="/logout" />
                        </x-slot:actions>
                    </x-list-item>
    
                    <x-menu-separator />
                @endif --}}
    
                <x-menu-item title="Home" icon="o-home" link="for-investment" link="/home" />
                <x-menu-item title="Marketplace" icon="o-shopping-cart" link="/marketplace" />
                <x-menu-item title="Collaborative Spaces" icon="o-users" link="/collaborative-spaces" />
                <x-menu-item title="Advisory Services" icon="o-briefcase" link="/advisory-services" />
                
                <x-menu-sub title="More Options" icon="o-cog">
                    <x-menu-item title="Apply for Investment" icon="o-currency-dollar" link="/more/for-investment" />
                    <x-menu-item title="Apply to Invest" icon="o-credit-card" link="/more/to-invest" />
                    <x-menu-item title="My Wishlist" icon="o-heart" link="/more/wishlist" />
                    <x-menu-item title="My Portfolio" icon="o-chart-bar" link="/more/portfolio" />
                    <x-menu-item title="Careers" icon="o-briefcase" link="/more/careers" />
                </x-menu-sub>
            </x-menu>
        </x-slot:sidebar>
    
        {{-- The `$slot` goes here --}}
        <x-slot:content>
            {{ $slot }}
        </x-slot:content>
    </x-main>
    
    {{-- Toast --}}
    <x-toast position="toast-top toast-center" />
</body>
</html>
