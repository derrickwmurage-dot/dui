@component('mail::message')

# New KYC Submission

A new KYC submission has been received for review.

## Submission Details

- **User ID**: {{ $userId }}
- **ID Photo**: [View ID Photo]({{ $kycData['idImageUrl'] }})
- **Profile Photo**: [View Profile Photo]({{ $kycData['profileImageUrl'] }})
- **Approved Status**: {{ $kycData['approved'] ? 'Yes' : 'No' }}
- **Submitted At**: {{ $kycData['timestamp']->get()->format('Y-m-d H:i:s') }}

Please review this KYC submission and take appropriate action.

@component('mail::button', ['url' => url('/profile/kyc')])
View KYC Submissions
@endcomponent

Thanks,<br>
{{ config('app.name') }}

@endcomponent