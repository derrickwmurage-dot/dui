<h1>Investment Approved - Action Required</h1>
<p>A new investment has been approved. Please arrange a Google Meet introduction between the investor and marketplace owner.</p>
<p><strong>Marketplace:</strong> {{ $marketplaceTitle }}</p>
<p><strong>Investor Name:</strong> {{ $investorName }}</p>
<p><strong>Investor Email:</strong> {{ $investorEmail }}</p>
<p><strong>Marketplace Owner Email:</strong> {{ $ownerEmail }}</p>
<p><strong>Investment Amount:</strong> ${{ number_format($investmentAmount, 2) }} </p>
<p><strong>Equity:</strong> {{ $equity }}% </p>
<p>Please schedule the meeting and inform both parties of the details.</p>