<!DOCTYPE html>
<html>
<head>
    <title>New Investee Application Submitted</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>New Investee Application Submitted</h1>

    <p>A new investee application has been submitted for review.</p>

    <h2>Applicant Details</h2>
    <ul>
        <li><strong>User ID</strong>: {{ $userId }}</li>
        <li><strong>First Name</strong>: {{ $applicationData['firstName'] }}</li>
        <li><strong>Second Name</strong>: {{ $applicationData['secondName'] }}</li>
        <li><strong>Email</strong>: {{ $applicationData['email'] }}</li>
        <li><strong>Phone</strong>: {{ $applicationData['phone'] }}</li>
        <li><strong>Country</strong>: {{ $applicationData['country'] }}</li>
    </ul>

    <h2>Investment Details</h2>
    <ul>
        <li><strong>Venture Name</strong>: {{ $applicationData['company'] ?? 'N/A' }}</li>
        <li><strong>Website</strong>: 
            @if($applicationData['website'])
                <a href="{{ $applicationData['website'] }}">{{ $applicationData['website'] }}</a>
            @else
                N/A
            @endif
        </li>
        <li><strong>Industry</strong>: {{ $applicationData['industry'] ?? 'N/A' }}</li>
        <li><strong>Level</strong>: {{ $applicationData['selectedLevels'] ?? $applicationData['level'] ?? 'N/A' }}</li>
        <li><strong>Company Solution</strong>: {{ $applicationData['details'] ?? 'N/A' }}</li>
        <li><strong>Country Headquarters</strong>: {{ $applicationData['country'] }}</li>
        <li><strong>Amount Raising</strong>: ${{ number_format($applicationData['amount'] ?? 0, 2) }}</li>
    </ul>

    <h2>Challenges</h2>
    <ul>
    @forelse($applicationData['selectedLevels'] ?? [] as $challenge)
        <li>{{ $challenge }}</li>
    @empty
        <li>No specific challenges provided</li>
    @endforelse
    </ul>

    <h2>Additional Information</h2>
    <ul>
        <li><strong>Referral</strong>: {{ $applicationData['referral'] }}</li>
        <li><strong>Details</strong>: {{ $applicationData['details'] ?? 'N/A' }}</li>
        <li><strong>Submitted At</strong>: {{ $applicationData['timestamp']->get()->format('Y-m-d H:i:s') }}</li>
    </ul>

    <p>Please review this application and take appropriate action.</p>
    <p><a href="{{ url('/more/to-invest') }}" class="button">View Investor Applications</a></p>

    <p>Thanks,<br>{{ config('app.name') }}</p>
</body>
</html>