<!DOCTYPE html>
<html>
<head>
    <title>Subscription Expiry Reminder</title>
</head>
<body>
    <p>Dear {{ $name }},</p>
    <p>{!! nl2br(e($subscriptionMessage)) !!}</p> <!-- Use the new variable name -->
    <p>Please renew your subscription in the <a href="{{ url('/more/to-invest') }}">Investor Application form</a>.</p>
    <p>Thank you!</p>
</body>
</html>