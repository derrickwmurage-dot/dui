<!DOCTYPE html>
<html>
<head>
    <title>Service Booking Status Update</title>
</head>
<body>
    <h1>Service Booking Status Update</h1>
    <p>Dear {{ $bookingDetails['userName'] }},</p>
    <p>Your service booking has been {{ $status ? 'approved' : 'rejected' }} by {{ $bookingDetails['serviceProviderName'] }}.</p>
    
    <h2>Booking Details:</h2>
    <ul>
        <li><strong>Service Provider:</strong> {{ $bookingDetails['serviceProviderName'] }}</li>
        <li><strong>Service Date:</strong> {{ $bookingDetails['serviceDate'] }}</li>
        <li><strong>Service Time:</strong> {{ $bookingDetails['serviceTime'] }}</li>
        <li><strong>Additional Info:</strong> {{ $bookingDetails['additionalInfo'] }}</li>
    </ul>

    @if($status)
        <p>We look forward to serving you! Please contact us if you have any questions.</p>
    @else
        <p>We apologize for any inconvenience. Please feel free to make a new booking request.</p>
    @endif

    <p>Regards,<br>Duit Technology</p>
</body>
</html>