<!DOCTYPE html>
<html>
<head>
    <title>Payment Confirmation</title>
</head>
<body>
    <h1>Payment Confirmation</h1>
    <p>Dear Investor,</p>
    <p>Your payment for the investment in "{{ $investmentDetails['marketplaceItemName'] }}" has been successfully processed.</p>
    <p>Investment Details:</p>
    <ul>
        <li>Investment Amount: ${{ number_format($investmentDetails['investmentAmount'], 2) }}</li>
        <li>Equity: {{ number_format($investmentDetails['equity'], 2) }}%</li>
        <li>Additional Offerings: {{ $investmentDetails['extraOfferings'] }}</li>
    </ul>
    <p>Thank you for your investment.</p>
</body>
</html>