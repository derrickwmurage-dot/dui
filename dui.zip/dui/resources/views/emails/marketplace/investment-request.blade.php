<!DOCTYPE html>
<html>
<head>
    <title>New Investment Request</title>
</head>
<body>
    <h1>New Investment Request</h1>
    <p>Dear {{ $investmentDetails['ownerName'] }},</p>
    <p>You have received a new investment request for your marketplace item "{{ $investmentDetails['marketplaceItemName'] }}".</p>
    <p>Investment Details:</p>
    <ul>
        <li>Investor Name: {{ $investmentDetails['investorName'] }}</li>
        <li>Investment Amount: ${{ number_format($investmentDetails['investmentAmount'], 2) }}</li>
        <li>Equity: {{ number_format($investmentDetails['equity'], 2) }}%</li>
        <li>Additional Offerings: {{ $investmentDetails['extraOfferings'] }}</li>
    </ul>
    <p>Please log in to your account to review and approve the investment request.</p>
</body>
</html>