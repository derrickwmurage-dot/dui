<!DOCTYPE html>
<html>
<head>
    <title>Investor Application Updated</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Investor Application Updated</h1>

    <p>An existing investor application has been updated.</p>

    <h2>Applicant Details</h2>
    <ul>
        <li><strong>User ID</strong>: {{ $userId }}</li>
        <li><strong>First Name</strong>: {{ $applicationData['firstName'] }}</li>
        <li><strong>Second Name</strong>: {{ $applicationData['secondName'] }}</li>
        <li><strong>Email</strong>: {{ $applicationData['email'] }}</li>
        <li><strong>Phone</strong>: {{ $applicationData['phone'] }}</li>
        <li><strong>Country</strong>: {{ $applicationData['country'] }}</li>
    </ul>

    <h2>Updated Investment Details</h2>
    <ul>
        <li><strong>Venture Name</strong>: {{ $applicationData['company'] ?? 'N/A' }}</li>
        <li><strong>Website</strong>: 
            @if($applicationData['website'])
                <a href="{{ $applicationData['website'] }}">{{ $applicationData['website'] }}</a>
            @else
                N/A
            @endif
        </li>
        <li><strong>Industry</strong>: {{ $applicationData['industry'] ?? 'N/A' }}</li>
        <li><strong>Level</strong>: {{ is_array($applicationData['selectedLevels']) ? implode(', ', $applicationData['selectedLevels']) : ($applicationData['selectedLevels'] ?? $applicationData['level'] ?? 'N/A') }}</li>
        <li><strong>Company Solution</strong>: {{ $applicationData['details'] ?? 'N/A' }}</li>
        <li><strong>Country Headquarters</strong>: {{ $applicationData['country'] }}</li>
        <li><strong>Amount Raising</strong>: 
            @if(is_array($applicationData['amount']) && !empty($applicationData['amount']))
                ${{ implode(', $', array_map(fn($val) => $val, $applicationData['amount'])) }}
            @else
                N/A
            @endif
        </li>
    </ul>

    <h2>Additional Updated Information</h2>
    <ul>
        <li><strong>Pitch Deck</strong>: 
            @if($applicationData['document'])
                <a href="{{ $applicationData['document'] }}">View Pitch Deck</a>
            @else
                N/A
            @endif
        </li>
        <li><strong>Relevant Documents</strong>: {{ $applicationData['address'] ?? 'N/A' }} (Proof of Residence)</li>
        <li><strong>Referral</strong>: {{ $applicationData['referral'] }}</li>
        <li><strong>Details</strong>: {{ $applicationData['details'] ?? 'N/A' }}</li>
        <li><strong>Updated At</strong>: {{ $applicationData['timestamp']->get()->format('Y-m-d H:i:s') }}</li>
    </ul>

    <p>Please review the updated application details.</p>
    <p><a href="{{ url('/more/to-invest') }}" class="button">View Investor Applications</a></p>

    <p>Thanks,<br>{{ config('app.name') }}</p>
</body>
</html>