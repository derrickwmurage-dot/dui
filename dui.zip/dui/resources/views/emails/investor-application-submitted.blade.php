<!DOCTYPE html>
<html>
<head>
    <title>New Investee Application Submitted</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>New Investee Application Submitted</h1>

    <p>A new investee application has been submitted for review.</p>

    <h2>Applicant Details</h2>
    <ul>
        <li><strong>User ID</strong>: {{ $userId }}</li>
        <li><strong>First Name</strong>: {{ $applicationData['firstName'] }}</li>
        <li><strong>Second Name</strong>: {{ $applicationData['secondName'] }}</li>
        <li><strong>Email</strong>: {{ $applicationData['email'] }}</li>
        <li><strong>Phone</strong>: {{ $applicationData['phone'] }}</li>
        <li><strong>Country</strong>: {{ $applicationData['country'] }}</li>
    </ul>

    <h2>Venture Details</h2>
    <ul>
        <li><strong>Venture Name</strong>: {{ $applicationData['ventureName'] }}</li>
        <li><strong>Website</strong>: 
            @if($applicationData['website'])
                <a href="{{ $applicationData['website'] }}">{{ $applicationData['website'] }}</a>
            @else
                N/A
            @endif
        </li>
        <li><strong>Industry</strong>: {{ $applicationData['industry'] }}</li>
        <li><strong>Business Model</strong>: {{ $applicationData['businessModel'] }}</li>
        <li><strong>Level</strong>: {{ $applicationData['level'] }}</li>
        <li><strong>Company Solution</strong>: {{ $applicationData['companySolution'] }}</li>
        <li><strong>African Led</strong>: {{ $applicationData['africanLed'] }}</li>
        <li><strong>African Percentage</strong>: {{ $applicationData['africanPercentage'] }}%</li>
        <li><strong>Female Founder</strong>: {{ $applicationData['femaleFounder'] }}</li>
        <li><strong>Female Percentage</strong>: {{ $applicationData['femalePercentage'] }}%</li>
        <li><strong>Country Headquarters</strong>: {{ $applicationData['countryHeadquarters'] }}</li>
        <li><strong>City</strong>: {{ $applicationData['city'] }}</li>
        <li><strong>Date Founded</strong>: {{ $applicationData['date'] }}</li>
        <li><strong>Lifecycle Stage</strong>: {{ $applicationData['lifecycle'] }}</li>
        <li><strong>How They Make Money</strong>: {{ $applicationData['makeMoney'] }}</li>
        <li><strong>Generating Revenue</strong>: {{ $applicationData['generatingRevenue'] }}</li>
        <li><strong>Amount Raising</strong>: ${{ number_format(floatval($applicationData['amountRaising']), 2) }}</li>
        <li><strong>Months of Runway</strong>: {{ $applicationData['monthsRunway'] }}</li>
        <li><strong>External Funding</strong>: {{ $applicationData['externalFunding'] }}</li>
    </ul>

    <h2>Challenges</h2>
    <ul>
    @forelse($applicationData['selectedChallenges'] as $challenge)
        <li>{{ $challenge }}</li>
    @empty
        <li>No challenges provided</li>
    @endforelse
    </ul>

    <h2>Additional Information</h2>
    <ul>
        <li><strong>Pitch Deck</strong>: 
            @if($applicationData['documentUrl'])
                <a href="{{ $applicationData['documentUrl'] }}">View Pitch Deck</a>
            @else
                N/A
            @endif
        </li>
        <li><strong>Relevant Documents</strong>: {{ $applicationData['relevantDocuments'] ?? 'N/A' }}</li>
        <li><strong>Referral</strong>: {{ $applicationData['referral'] }}</li>
        <li><strong>Details</strong>: {{ $applicationData['details'] ?? 'N/A' }}</li>
        <li><strong>Mailing Preference</strong>: {{ $applicationData['mailing'] }}</li>
        <li><strong>Submitted At</strong>: {{ $applicationData['timestamp']->get()->format('Y-m-d H:i:s') }}</li>
    </ul>

    <p>Please review this application and take appropriate action.</p>
    <p><a href="{{ url('/more/for-investment') }}" class="button">View Investee Applications</a></p>

    <p>Thanks,<br>{{ config('app.name') }}</p>
</body>
</html>