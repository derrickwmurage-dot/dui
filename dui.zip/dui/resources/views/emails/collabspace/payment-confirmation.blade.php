<!DOCTYPE html>
<html>
<head>
    <title>Payment Confirmation</title>
</head>
<body>
    <h1>Payment Confirmation</h1>
    <p>Dear {{ $paymentDetails['userName'] }},</p>
    <p>Thank you for your payment. Here are the details:</p>
    <ul>
        <li>Studio Name: {{ $paymentDetails['studioName'] }}</li>
        <li>Amount: ${{ number_format($paymentDetails['amount'], 2) }}</li>
        <li>Days: {{ $paymentDetails['days'] }}</li>
        <li>Start Date: {{ \Carbon\Carbon::parse($paymentDetails['startDate'])->format('M d, Y') }}</li>
    </ul>
    <p>Thank you for choosing our service.</p>
</body>
</html>