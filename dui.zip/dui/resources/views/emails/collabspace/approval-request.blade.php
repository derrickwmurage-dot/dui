<!DOCTYPE html>
<html>
<head>
    <title>Collaborative Space Booking Approval</title>
</head>
<body>
    <h1>Collaborative Space Booking Approval</h1>
    <p>A new booking request has been made for your collaborative space. Here are the details:</p>
    <ul>
        <li><strong>User Name:</strong> {{ $bookingDetails['userName'] }}</li>
        <li><strong>Studio Name:</strong> {{ $bookingDetails['studioName'] }}</li>
        <li><strong>Amount:</strong> {{ $bookingDetails['amount'] }}</li>
        <li><strong>Days:</strong> {{ $bookingDetails['days'] }}</li>
        <li><strong>Start Date:</strong> {{ $bookingDetails['startDate']->format('Y-m-d') }}</li>
        <li><strong>Additional Info:</strong> {{ $bookingDetails['additionalInfo'] }}</li>
    </ul>
    <p>Please log in to your account to approve or reject this booking request.</p>
    <a href="{{ route('approve-booking', ['id' => $bookingDetails['id']]) }}" style="display: inline-block; padding: 10px 20px; color: white; background-color: green; text-decoration: none;">Approve Booking</a>
</body>
</html>