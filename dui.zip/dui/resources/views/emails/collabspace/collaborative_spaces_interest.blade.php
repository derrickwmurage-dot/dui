<!DOCTYPE html>
<html>
<head>
    <title>New Interest in Collaborative Space</title>
</head>
<body>
    <h1>New Interest in Your Space</h1>
    <p>Dear Space Owner,</p>
    <p>A user has shown interest in booking your space: <strong>{{ $studioName }}</strong></p>
    <ul>
        <li><strong>User Name:</strong> {{ $userName }}</li>
        <li><strong>Start Date:</strong> {{ $startDate }}</li>
        <li><strong>Duration:</strong> {{ $days }} day(s)</li>
        <li><strong>Amount:</strong> ${{ $amount }}</li>
        <li><strong>Additional Info:</strong> {{ $additionalInfo ?: 'None provided' }}</li>
    </ul>
    <p>Please review this request and take appropriate action.</p>
    <p>
        <a href="{{ route('approve-booking', ['id' => $bookingId]) }}" 
           style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
           Approve Booking
        </a>
    </p>
    <p>Regards,<br>Duit Technology</p>
</body>
</html>