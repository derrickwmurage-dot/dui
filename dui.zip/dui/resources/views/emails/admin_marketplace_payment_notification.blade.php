@component('mail::message')

# New Marketplace Payment Received

A new payment has been successfully processed for a marketplace investment.

## Payment Details

- **Reference ID**: {{ $reference }}
- **Investor User ID**: {{ $userId }}
- **Investor Name**: {{ $investmentDetails['investorName'] }}
- **Investor Email**: Not provided in metadata
- **Marketplace Item**: {{ $investmentDetails['marketplaceItemName'] }}
- **Owner Name**: {{ $investmentDetails['ownerName'] }}
- **Investment Amount**: ${{ number_format($investmentDetails['investmentAmount'], 2) }}
- **Equity**: {{ $investmentDetails['equity'] }}%
- **Extra Offerings**: {{ $investmentDetails['extraOfferings'] ?? 'N/A' }}
- **Received At**: {{ now()->format('Y-m-d H:i:s') }}

## Action Required

Please review this payment and ensure all records are updated accordingly.

@component('mail::button', ['url' => url('/marketplace-payments')])
View Marketplace Payments
@endcomponent

Thanks,<br>
{{ config('app.name') }}

@endcomponent