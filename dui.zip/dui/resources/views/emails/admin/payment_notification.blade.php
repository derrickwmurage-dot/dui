<h1>New Payment Notification</h1>

<p>A new payment has been received with the following details:</p>

<ul>
    <li>User: {{ $userName }}</li>
    <li>Amount: {{ $amount }}</li>
    <li>Service Provider: {{ $serviceProviderName }}</li>
    <li>Date: {{ $serviceDate }}</li>
    <li>Time: {{ $serviceTime }}</li>
    <li>Transaction Reference: {{ $reference }}</li>
</ul>

<p>Please review this transaction in the admin panel.</p>