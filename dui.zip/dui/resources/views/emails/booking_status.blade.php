<!DOCTYPE html>
<html>
<head>
    <title>Booking Status Update</title>
</head>
<body>
    <h1>Booking Status Update</h1>
    <p>Dear {{ $bookingDetails['userName'] }},</p>
    <p>Your booking request for {{ $bookingDetails['studioName'] }} has been {{ $status ? 'approved' : 'rejected' }}.</p>
    
    <h2>Booking Details:</h2>
    <ul>
        <li><strong>Studio Name:</strong> {{ $bookingDetails['studioName'] }}</li>
        <li><strong>Start Date:</strong> {{ $bookingDetails['startDate'] }}</li>
        <li><strong>Duration:</strong> {{ $bookingDetails['days'] }} day(s)</li>
        <li><strong>Amount:</strong> ${{ $bookingDetails['amount'] }}</li>
    </ul>

    @if($status)
        <p>We look forward to welcoming you! Please contact us if you have any questions.</p>
    @else
        <p>We apologize for any inconvenience. Please feel free to make a new booking request.</p>
    @endif

    <p>Regards,<br>Duit Technology</p>
</body>
</html>