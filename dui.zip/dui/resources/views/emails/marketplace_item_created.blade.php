<!DOCTYPE html>
<html>
<head>
    <title>New Marketplace Item Created</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; text-decoration: none; }
    </style>
</head>
<body>
    <h1>New Marketplace Item Created</h1>

    <p>A new marketplace item has been submitted for review.</p>

    <h2>Item Details</h2>
    <ul>
        <li><strong>Title</strong>: {{ $marketplaceItem['title'] }}</li>
        <li><strong>Description</strong>: {{ $marketplaceItem['description'] }}</li>
        <li><strong>Company Ask</strong>: ${{ number_format($marketplaceItem['companyAsk'], 2) }}</li>
        <li><strong>Amount Invested</strong>: ${{ number_format($marketplaceItem['amountInvested'], 2) }}</li>
        <li><strong>Earnings</strong>: ${{ number_format($marketplaceItem['earnings'], 2) }}</li>
        <li><strong>Revenue</strong>: ${{ number_format($marketplaceItem['revenue'], 2) }}</li>
        <li><strong>Creator</strong>: {{ $creatorName }} ({{ $creatorEmail }})</li>
    </ul>

    @if(!empty($marketplaceItem['pitchDeck']))
    <p><strong>Pitch Deck</strong>: <a href="{{ $marketplaceItem['pitchDeck'] }}">View Pitch Deck</a></p>
    @endif

    @if(!empty($marketplaceItem['imageUrl']))
    <h2>Images</h2>
    <ul>
        @foreach($marketplaceItem['imageUrl'] as $image)
        <li><a href="{{ $image }}">View Image</a></li>
        @endforeach
    </ul>
    @endif

    <h2>Additional Details</h2>
    <ul>
        @foreach($marketplaceItem['moreInfo'] as $key => $value)
        <li><strong>{{ $key }}</strong>: {{ $value }}</li>
        @endforeach
    </ul>

    <p>Please review this submission and take appropriate action.</p>
    <p><a href="{{ url('/marketplace') }}" class="button">View Marketplace</a></p>

    <p>Thanks,<br>{{ config('app.name') }}</p>
</body>
</html>