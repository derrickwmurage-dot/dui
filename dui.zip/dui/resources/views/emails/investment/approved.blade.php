@component('mail::message')
# Investment Approved

Hello {{ $investorName }},

We’re excited to inform you that your investment in **{{ $marketplaceTitle }}** has been approved!

**Details:**
- **Investment Amount**: ${{ number_format($investmentAmount, 2) }}
- **Equity Stake**: {{ number_format($equity, 2) }}%

### Next Steps:
1. The Duit Technology team will arrange a Google Meet introduction between you and the startup team.  
2. The Shareholders' Agreement (SHA) will be drafted and finalized.  
3. Once the SHA is signed, you may proceed with the investment payment of ${{ number_format($investmentAmount, 2) }}.  

We will be in touch soon to schedule the introduction. If you have any questions, feel free to contact us at [info@duitechnology.com](mailto:info@duitechnology.com).

Thank you for investing with us!  

Best regards,  
The Invest in Africa Team  
@endcomponent
