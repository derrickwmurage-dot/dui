@component('mail::message')
# Investment Request Not Approved

Hello {{ $investorName }},

We regret to inform you that your investment request for **{{ $marketplaceTitle }}** has not been approved.

If you have any questions or need further clarification, please reach out to us at [info@duitechnology.com](mailto:info@duitechnology.com).

Thank you for your interest in investing with us.

Best regards,  
Duit Technology
@endcomponent