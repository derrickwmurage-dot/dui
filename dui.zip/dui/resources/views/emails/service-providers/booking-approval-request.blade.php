<!DOCTYPE html>
<html>
<head>
    <title>Booking Approval Request</title>
</head>
<body>
    <h1>Booking Approval Request</h1>
    <p>Dear {{ $bookingDetails['serviceProviderName'] }},</p>
    <p>A new booking has been made. Here are the details:</p>
    <ul>
        <li>User Name: {{ $bookingDetails['userName'] }}</li>
        <li>Service Date: {{ \Carbon\Carbon::parse($bookingDetails['serviceDate'])->format('M d, Y') }}</li>
        <li>Service Time: {{ $bookingDetails['serviceTime'] }}</li>
        <li>Additional Info: {{ $bookingDetails['additionalInfo'] }}</li>
    </ul>
    <p>Please review this booking request and take appropriate action.</p>
    <p>
        <a href="{{ route('approve-service-booking', ['id' => $bookingDetails['id']]) }}" 
           style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">
           Approve Booking
        </a>
    </p>
    <p>Regards,<br>Duit Technology</p>
</body>
</html>