<!DOCTYPE html>
<html>
<head>
    <title>Payment Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            background: #4CAF50;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            border-radius: 8px 8px 0 0;
        }
        .content {
            padding: 20px;
            text-align: left;
        }
        .footer {
            margin-top: 20px;
            font-size: 12px;
            text-align: center;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            Payment Confirmation
        </div>
        <div class="content">
            <p>Hello, {{ $userName }}!</p>
            <p>Your payment of <strong>Ksh {{ number_format($amount, 2) }}</strong> to <strong>{{ $serviceProviderName }}</strong> has been successfully processed.</p>

            <p><strong>Transaction Details:</strong></p>
            <ul>
                <li><strong>Status:</strong> Success</li>
                <li><strong>Service Date:</strong> {{ $serviceDate }}</li>
                <li><strong>Service Time:</strong> {{ $serviceTime }}</li>
            </ul>

            <p>Thank you for choosing our platform!</p>
        </div>
        <div class="footer">
            &copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
        </div>
    </div>
</body>
</html>