<!DOCTYPE html>
<html>
<head>
    <title>Collaborative Space Booking Confirmed</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Collaborative Space Booking Confirmed</h1>

    <p>Dear {{ $paymentData['customerName'] }},</p>

    <p>Your booking for the collaborative space has been successfully confirmed and paid for. Below are the details:</p>

    <h2>Booking Details</h2>
    <ul>
        <li><strong>Space Name</strong>: {{ $verificationData['data']['metadata']['title'] }}</li>
        <li><strong>Amount Paid</strong>: {{ $paymentData['currency'] }} {{ number_format($paymentData['amount'], 2) }}</li>
        <li><strong>Payment Date</strong>: {{ (new \Carbon\Carbon($paymentData['createdAt']))->format('F j, Y, g:i A') }}</li>
        <li><strong>Reference</strong>: {{ $paymentData['refId'] }}</li>
    </ul>

    <p>Thank you for choosing our collaborative space. We look forward to hosting you!</p>

    <p><a href="{{ url('/collaborative-spaces') }}" class="button">View Booking Details</a></p>

    <p>Best regards,<br>{{ config('app.name') }}</p>
</body>
</html>