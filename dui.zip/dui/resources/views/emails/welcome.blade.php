<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Our Platform</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <h1 style="color: #2c3e50;">Welcome to Invest in Africa!</h1>
    <p>Dear User,</p>
    <p>We are thrilled to have you join our platform. At <strong>Invest in Africa</strong>, we are committed to connecting investors and entrepreneurs to create opportunities and drive growth across the continent.</p>
    <p>To help you get started, we’ve attached some resources that will guide you through the process:</p>
    <ul>
        <li><strong>Investor Guide:</strong> Learn how to make the most of your investments.</li>
        <li><strong>Startup Guide:</strong> Discover how to grow and scale your business effectively.</li>
    </ul>
    <p>If you have any questions or need assistance, feel free to reach out to our support team. We’re here to help!</p>
    <p>Once again, welcome aboard. Let’s make a difference together!</p>
    <p style="margin-top: 20px;">Best regards,</p>
    <p><strong>Duit Technology</strong></p>
</body>
</html>