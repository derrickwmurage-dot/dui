<!DOCTYPE html>
<html>
<head>
    <title>Profile Updated</title>
</head>
<body>
    <h1>Profile Updated</h1>
    <p><strong>User ID:</strong> {{ $userId }}</p>
    <p><strong>Profile Completion:</strong> {{ $completionPercentage }}%</p>
    <p>The profile has been successfully updated in the system.</p>
</body>
</html>