<!DOCTYPE html>
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <p>This is a test email from Laravel using GoDaddy SMTP.</p>
</body>
</html>
