<!DOCTYPE html>
<html>
<head>
    <title>Collaborative Space Booked and Paid</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 10px; }
        a { color: #3490dc; text-decoration: none; }
        .button { background-color: #3490dc; color: white; padding: 10px 20px; display: inline-block; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Collaborative Space Booked and Paid</h1>

    <p>A collaborative space has been booked and paid for successfully. Below are the details:</p>

    <h2>Booking Details</h2>
    <ul>
        <li><strong>User Email</strong>: {{ $userEmail }}</li>
        <li><strong>User Name</strong>: {{ $paymentData['customerName'] }}</li>
        <li><strong>Space Name</strong>: {{ $verificationData['data']['metadata']['title'] }}</li>
        <li><strong>Amount Paid</strong>: {{ $paymentData['currency'] }} {{ number_format($paymentData['amount'], 2) }}</li>
        <li><strong>Payment Date</strong>: {{ (new \Carbon\Carbon($paymentData['createdAt']))->format('F j, Y, g:i A') }}</li>
        <li><strong>Reference</strong>: {{ $paymentData['refId'] }}</li>
    </ul>

    <p>Please review the booking details as needed.</p>

    <p><a href="{{ url('/collaborative-spaces') }}" class="button">View All Bookings</a></p>

    <p>Regards,<br>{{ config('app.name') }}</p>
</body>
</html>