<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Service Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .custom-gradient {
            background: linear-gradient(to top right, rgba(248, 170, 52, 1), rgba(36, 110, 213, 1));
        }
    </style>
</head>
<body class="custom-gradient min-h-screen flex items-center justify-center">
    <!-- Toast Notifications -->
    <div class="fixed top-0 left-0 right-0 z-50 flex justify-center mt-4 px-4">
        @if(session('success'))
            <div class="toast bg-green-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105 relative">
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="toast bg-red-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105 relative">
                {{ session('error') }}
            </div>
        @endif
    </div>

    <div class="w-full max-w-md bg-white bg-opacity-10 rounded-2xl p-8 shadow-2xl backdrop-filter backdrop-blur-lg">
        <div class="text-center mb-8">
            <h1 class="text-3xl md:text-4xl font-bold text-white mb-2">Approve Service Booking</h1>
            <p class="text-blue-200">Booking ID: <strong>#{{ $id }}</strong></p>
        </div>

        <!-- Spinner -->
        <div id="spinner" class="hidden fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <svg class="animate-spin h-12 w-12 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
        </div>

        <form method="POST" action="{{ route('approve-service-booking.submit', ['id' => $id]) }}" onsubmit="showSpinner()" class="space-y-6">
            @csrf
            <p class="text-blue-200 text-center">Are you sure you want to approve this booking?</p>
            <div class="flex justify-center space-x-4">
                <button type="submit" name="status" value="approve" 
                    class="w-full py-3 px-4 bg-green-500 hover:bg-green-600 text-white font-medium rounded-lg transition duration-300 transform hover:scale-105 hover:shadow-xl">
                    Approve
                </button>
                <button type="submit" name="status" value="reject" 
                    class="w-full py-3 px-4 bg-red-500 hover:bg-red-600 text-white font-medium rounded-lg transition duration-300 transform hover:scale-105 hover:shadow-xl">
                    Reject
                </button>
            </div>
        </form>
    </div>

    <script>
        function showSpinner() {
            document.getElementById('spinner').classList.remove('hidden');
        }
    </script>
</body>
</html>