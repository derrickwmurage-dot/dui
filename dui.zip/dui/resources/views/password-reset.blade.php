<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($title) ? $title.' - '.config('app.name') : config('app.name') }}</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gradient-to-br from-green-600 to-indigo-900 min-h-screen">
    <!-- Toast Notifications -->
    <div class="fixed top-0 left-0 right-0 z-50 flex justify-center mt-4 px-4">
        @if(session('success'))
            <div class="toast bg-green-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105">
                {{ session('success') }}
            </div>
        @endif
        @if($errors->any())
            <div class="toast bg-red-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <div class="min-h-screen flex items-center justify-center p-4">
        <!-- Reset Password form -->
        <div class="w-full max-w-md px-4">
            <div class="bg-white bg-opacity-10 rounded-2xl p-8 shadow-2xl backdrop-filter backdrop-blur-lg">
                <div class="text-center mb-8">
                    <h1 class="text-3xl md:text-4xl font-bold text-white mb-2">Reset Password</h1>
                    <p class="text-blue-200">Enter your email to reset your password</p>
                </div>

                <form id="resetForm" action="{{ route('password.reset') }}" method="POST" class="space-y-6">
                    @csrf
                    <div class="space-y-2">
                        <label class="text-blue-100 font-medium">Email Address</label>
                        <input type="email" name="email" id="email" placeholder="Enter Email Address" class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-opacity-50 transition duration-300" required>
                    </div>

                    <button type="submit" id="submitButton" class="w-full py-3 px-4 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition duration-300 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Send Reset Link
                    </button>
                </form>

                <p class="mt-8 text-center text-blue-200">
                    Remember your password? 
                    <a href="{{ route('login') }}" class="font-medium text-white hover:text-blue-400 transition duration-300">Login here</a>
                </p>
            </div>

            <p class="text-center text-blue-200 text-sm mt-8">&copy; 2025 Duit Technology</p>
        </div>
    </div>

    <script>
        document.getElementById('resetForm').addEventListener('submit', function() {
            document.getElementById('submitButton').disabled = true;
        });

        // Automatically remove toast notifications after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                document.querySelectorAll('.toast').forEach(function(toast) {
                    toast.remove();
                });
            }, 5000);
        });
    </script>
</body>
</html>