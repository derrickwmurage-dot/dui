<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($title) ? $title.' - '.config('app.name') : config('app.name') }}</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <style>
        .custom-gradient {
            background: linear-gradient(to top right, rgba(248, 170, 52, 1), rgba(36, 110, 213, 1));
        }
    </style>
    <link rel=icon href="https://perplexing-beans-assets.vercel.app/assets/logo/duit_light_icon.png" sizes="16x16" type="image/png">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="custom-gradient min-h-screen">
    <!-- Toast Notifications -->
    <div class="fixed top-0 left-0 right-0 z-50 flex justify-center mt-4 px-4">
        @if(session('success'))
            <div class="toast bg-green-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105 relative">
                {{ session('success') }}
            </div>
        @endif
        @if($errors->any())
            <div class="toast bg-red-500 bg-opacity-90 text-white p-4 rounded-lg shadow-xl transform transition duration-500 hover:scale-105 relative">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>

    <!-- Loading Spinner -->
    <div id="loading-spinner" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 hidden">
        <div class="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
    </div>

    <div class="min-h-screen flex flex-col md:flex-row items-center justify-center p-4">
        <!-- Left side image -->
        <div class="hidden lg:block w-full md:w-1/2 xl:w-2/3 p-8 transform transition-all duration-700 hover:-translate-y-6">
            <img 
                src="https://perplexing-beans-assets.vercel.app/assets/auth/africa.jpg" 
                alt="" 
                class="rounded-3xl shadow-2xl w-full h-auto object-cover transform transition duration-500 hover:scale-105"
            >
        </div>

        <!-- Login form -->
        <div class="w-full md:w-1/2 xl:w-1/3 px-4 md:px-8 lg:px-12">
            <div class="bg-white bg-opacity-10 rounded-2xl p-8 shadow-2xl backdrop-filter backdrop-blur-lg">
                <div class="text-center mb-8">
                    <h1 class="text-3xl md:text-4xl font-bold text-white mb-2">Welcome Back</h1>
                    <p class="text-blue-200">Sign in to continue</p>
                </div>

                <form action="{{ route('login') }}" method="POST" class="space-y-6">
                    @csrf
                    <div class="space-y-2">
                        <label class="text-blue-100 font-medium">Email</label>
                        <input type="email" name="email" class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-opacity-50 transition duration-300" placeholder="your@email.com" required>
                    </div>

                    <div class="space-y-2">
                        <label class="text-blue-100 font-medium">Password</label>
                        <input type="password" name="password" class="w-full px-4 py-3 rounded-lg bg-white bg-opacity-10 border border-white border-opacity-20 text-white placeholder-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-opacity-50 transition duration-300" placeholder="••••••••" required>
                    </div>

                    <div class="flex items-center justify-between">
                        <label class="flex items-center text-sm text-blue-200">
                            <input type="checkbox" class="rounded border-white border-opacity-20 text-blue-500 focus:ring-blue-500">
                            <span class="ml-2">Remember me</span>
                        </label>
                        <a href="{{ route('password.reset') }}" class="text-sm text-blue-200 hover:text-white transition duration-300">Forgot Password?</a>
                    </div>

                    <button type="submit" class="w-full py-3 px-4 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition duration-300 transform hover:scale-105 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Sign In
                    </button>

                    <div class="relative my-6">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-white border-opacity-20"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 text-blue-200 bg-transparent">Or continue with</span>
                        </div>
                    </div>

                    <button type="button" class="w-full py-3 px-4 bg-white text-gray-800 font-medium rounded-lg flex items-center justify-center space-x-2 transition duration-300 transform hover:scale-105 hover:shadow-xl" onclick="signInWithGoogle()">
                        <svg class="w-5 h-5" viewBox="0 0 48 48">
                            <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
                            <path fill="#FF3D00" d="m6.306 14.691 6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/>
                            <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
                            <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
                        </svg>
                        <span>Sign in with Google</span>
                    </button>
                </form>

                <p class="mt-8 text-center text-blue-200">
                    Don't have an account? 
                    <a href="{{ route('register') }}" class="font-medium text-white hover:text-blue-400 transition duration-300">Sign up</a>
                </p>
            </div>

            <p class="text-center text-blue-200 text-sm mt-8">© 2025 Duit Technology</p>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
        import { getAuth, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

        async function initializeFirebase() {
            try {
                // console.log('Fetching Firebase config');
                // const response = await fetch('/auth/firebase-config');
                // const config = await response.json();
                // if (config.error) {
                //     console.error('Firebase config error:', config.error);
                //     throw new Error(config.error);
                // }
                // const app = initializeApp({
                //     apiKey: config.apiKey,
                //     authDomain: config.authDomain,
                //     projectId: config.projectId,
                //     storageBucket: config.storageBucket,
                //     messagingSenderId: config.messagingSenderId,
                //     appId: config.appId,
                // });

                const app = initializeApp({
                    apiKey: "{{ env('FIREBASE_API_KEY') }}",
                    authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
                    projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
                    storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
                    messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
                    appId: "{{ env('FIREBASE_APP_ID') }}",
                });


                // console.log('Firebase initialized successfully');
                return getAuth(app);
            } catch (error) {
                console.error('Firebase initialization failed:', error.message);
                throw error;
            }
        }

        const authPromise = initializeFirebase();

        window.signInWithGoogle = async function() {
            try {
                // console.log('Starting Google sign-in');
                const auth = await authPromise;
                if (!auth) {
                    console.error('Authentication not initialized');
                    throw new Error('Authentication not initialized');
                }
                const provider = new GoogleAuthProvider();
                // console.log('Opening Google sign-in popup');
                const result = await signInWithPopup(auth, provider);
                // console.log('Google sign-in popup completed, user:', result.user.email);
                const user = result.user;
                const userData = {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    photoURL: user.photoURL
                };
                // console.log('Sending user data to backend:', userData);
                const loadingSpinner = document.getElementById('loading-spinner');
                loadingSpinner.classList.remove('hidden');
                const response = await fetch('/auth/google/callback', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ user: userData })
                });
                loadingSpinner.classList.add('hidden');
                const data = await response.json();
                // console.log('Backend response:', data);
                if (data.success) {
                    // console.log('Redirecting to:', data.redirect);
                    window.location.href = data.redirect;
                } else {
                    console.error('Backend error:', data.error);
                    throw new Error(data.error || 'Authentication failed');
                }
            } catch (error) {
                document.getElementById('loading-spinner').classList.add('hidden');
                console.error('Google sign-in error:', error.message);
                alert('Google sign-in failed: ' + error.message);
            }
        }
    </script>

    <meta name="csrf-token" content="{{ csrf_token() }}">
</body>
</html>