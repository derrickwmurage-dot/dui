<div
    x-data
    data-firebase-user="{{ session('firebase_user') }}"
    data-firebase-token="{{ session('firebase_token') }}"
>
    @assets
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-storage-compat.js"></script>
    @endassets

    <x-header title="KYC Verification" separator progress-indicator />

    <!-- KYC Status -->
    <div class="mb-6">
        @if($kycSubmitted)
            <div class="p-4 rounded-lg bg-gray-100">
                <p class="text-sm font-medium text-gray-700">
                    KYC Status: 
                    @if($kycApproved)
                        <span class="text-green-600">Approved</span>
                    @else
                        <span class="text-yellow-600">Pending Approval</span>
                    @endif
                </p>
                @if(!empty($kycTimestamp))
                    <p class="text-sm text-gray-600">Submitted on: {{ $kycTimestamp }}</p>
                @endif
            </div>
        @else
            <p class="text-sm text-gray-600">Please submit your KYC documents below.</p>
        @endif
    </div>

    <!-- Image Upload Section -->
    <div class="space-y-6">
        <!-- ID Photo -->
        <div>
            <label class="block text-sm font-medium text-gray-700">ID Photo</label>
            <div class="mt-2">
                <!-- Uploaded Image -->
                @if($idPhotoUrl)
                    <div class="relative">
                        <img src="{{ $idPhotoUrl }}" alt="ID Photo" class="max-w-xs rounded-lg shadow-md">
                        <button 
                            wire:click="removeImage('idPhoto')" 
                            class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                            title="Remove Image"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                @else
                    <!-- Preview for Selected Image -->
                    <div id="idPhotoPreview" class="hidden relative max-w-xs">
                        <img id="idPhotoPreviewImg" src="#" alt="ID Photo Preview" class="max-w-xs rounded-lg shadow-md">
                        <button 
                            onclick="clearImagePreview('idPhoto', 'idPhotoPreview')"
                            class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                            title="Clear Preview"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    <!-- File Input -->
                    <input 
                        type="file" 
                        id="idPhoto" 
                        accept="image/jpeg,image/png,image/gif" 
                        onchange="handleImageSelection(event, 'idPhoto', 'idPhotoPreview', 'idPhotoUrl', 'idPhotoStatus', 'idPhotoProgress', 'idPhoto_percentage')"
                        class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                    <input type="hidden" wire:model="idPhotoUrl" />
                    <div id="idPhotoStatus" class="mt-2"></div>
                    <div id="idPhotoProgress" class="mt-2 hidden">
                        <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                        <span id="idPhoto_percentage" class="text-sm">0%</span>
                    </div>
                @endif
            </div>
        </div>

        <!-- Profile Photo -->
        <div>
            <label class="block text-sm font-medium text-gray-700">Profile Photo</label>
            <div class="mt-2">
                <!-- Uploaded Image -->
                @if($profilePhotoUrl)
                    <div class="relative">
                        <img src="{{ $profilePhotoUrl }}" alt="Profile Photo" class="max-w-xs rounded-lg shadow-md">
                        <button 
                            wire:click="removeImage('profilePhoto')" 
                            class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                            title="Remove Image"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                @else
                    <!-- Preview for Selected Image -->
                    <div id="profilePhotoPreview" class="hidden relative max-w-xs">
                        <img id="profilePhotoPreviewImg" src="#" alt="Profile Photo Preview" class="max-w-xs rounded-lg shadow-md">
                        <button 
                            onclick="clearImagePreview('profilePhoto', 'profilePhotoPreview')"
                            class="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                            title="Clear Preview"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    <!-- File Input -->
                    <input 
                        type="file" 
                        id="profilePhoto" 
                        accept="image/jpeg,image/png,image/gif" 
                        onchange="handleImageSelection(event, 'profilePhoto', 'profilePhotoPreview', 'profilePhotoUrl', 'profilePhotoStatus', 'profilePhotoProgress', 'profilePhoto_percentage')"
                        class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                    />
                    <input type="hidden" wire:model="profilePhotoUrl" />
                    <div id="profilePhotoStatus" class="mt-2"></div>
                    <div id="profilePhotoProgress" class="mt-2 hidden">
                        <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                        <span id="profilePhoto_percentage" class="text-sm">0%</span>
                    </div>
                @endif
            </div>
        </div>

        <!-- Save Button with Loader -->
        @if(!$kycApproved)
            <div class="mt-6">
                <x-button 
                    label="Submit KYC" 
                    class="btn-primary" 
                    wire:click="saveKYC" 
                    spinner="saveKYC"
                >
                    @if($isSaving)
                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    @endif
                    Submit
                </x-button>
            </div>
        @endif
    </div>

    <script>
        (function() {
            let firebaseInitialized = false;
            const config = {
                apiKey: "{{ env('FIREBASE_API_KEY') }}",
                authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
                projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
                storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
                messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
                appId: "{{ env('FIREBASE_APP_ID') }}"
            };

            function initializeFirebase() {
                if (firebaseInitialized) return;
                if (typeof firebase === 'undefined') {
                    console.error('Firebase SDK not loaded');
                    setTimeout(initializeFirebase, 1000);
                    return;
                }
                try {
                    if (!firebase.apps.length) {
                        firebase.initializeApp(config);
                    }
                    firebaseInitialized = true;
                    // console.log('Firebase initialized successfully');
                    const rootElement = document.querySelector('[data-firebase-user]');
                    const sessionUser = rootElement?.dataset.firebaseUser;
                    if (sessionUser) {
                        // console.log('User authenticated via session');
                        return;
                    }
                    firebase.auth().onAuthStateChanged(user => {
                        if (!user && !sessionUser) {
                            // console.log('No user found, redirecting to login...');
                            window.location.href = '/login';
                        } else {
                            // console.log('User authenticated:', user?.uid || sessionUser);
                        }
                    });
                } catch (error) {
                    console.error('Firebase initialization error:', error);
                    setTimeout(initializeFirebase, 1000);
                }
            }

            document.addEventListener('DOMContentLoaded', initializeFirebase);
            initializeFirebase();

            window.handleImageSelection = function(event, inputId, previewId, modelName, statusElementId, progressElementId, percentageElementId) {
                const file = event.target.files[0];
                const previewContainer = document.getElementById(previewId);
                const previewImg = document.getElementById(`${previewId}Img`);

                if (file) {
                    if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
                        alert('Please select a valid image (JPEG, PNG, or GIF).');
                        event.target.value = '';
                        return;
                    }
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewImg.src = e.target.result;
                        previewContainer.classList.remove('hidden');
                    };
                    reader.readAsDataURL(file);
                    window.uploadToFirebase(event, modelName, statusElementId, progressElementId, percentageElementId);
                } else {
                    previewContainer.classList.add('hidden');
                }
            };

            window.clearImagePreview = function(inputId, previewId) {
                const input = document.getElementById(inputId);
                const previewContainer = document.getElementById(previewId);
                input.value = '';
                previewContainer.classList.add('hidden');
                Livewire.dispatch('update', { [inputId === 'idPhoto' ? 'idPhotoUrl' : 'profilePhotoUrl']: '' });
            };

            window.uploadToFirebase = function(event, modelName, statusElementId, progressElementId, percentageElementId, retries = 3) {
                if (!firebaseInitialized) {
                    console.warn('Firebase not initialized, retrying...');
                    if (retries > 0) {
                        setTimeout(() => window.uploadToFirebase(event, modelName, statusElementId, progressElementId, percentageElementId, retries - 1), 1000);
                    } else {
                        alert('Upload system not ready. Please refresh the page.');
                    }
                    return;
                }

                const rootElement = document.querySelector('[data-firebase-user]');
                const sessionUser = rootElement?.dataset.firebaseUser;

                if (sessionUser) {
                    proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, sessionUser);
                    return;
                }

                const user = firebase.auth().currentUser;
                if (!user) {
                    firebase.auth().onAuthStateChanged(user => {
                        if (user) {
                            proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                        } else {
                            // console.log('No user found, redirecting to login...');
                            window.location.href = '/login';
                        }
                    });
                } else {
                    proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                }
            };

            function proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, userId) {
                const file = event.target.files[0];
                if (!file) {
                    console.error('No file selected');
                    alert('No file selected');
                    return;
                }

                if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
                    console.error('Invalid file type:', file.type);
                    alert('Please select a valid image (JPEG, PNG, or GIF).');
                    return;
                }

                const statusElement = document.getElementById(statusElementId);
                const progressElement = document.getElementById(progressElementId);
                const progressBar = progressElement.querySelector('progress');
                const percentageElement = document.getElementById(percentageElementId);

                statusElement.innerHTML = `<svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
                progressElement.classList.remove('hidden');
                progressBar.value = 0;
                percentageElement.textContent = '0%';

                const storage = firebase.storage();
                const storageRef = storage.ref(`kyc/${userId}/${file.name}_${Date.now()}`);
                const uploadTask = storageRef.put(file);

                uploadTask.on('state_changed',
                    snapshot => {
                        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                        progressBar.value = progress;
                        percentageElement.textContent = `${Math.round(progress)}%`;
                    },
                    error => {
                        console.error('Upload failed:', error);
                        alert('Upload failed: ' + error.message);
                        statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                        progressElement.classList.add('hidden');
                    },
                    () => {
                        uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                            // console.log(`Dispatching ${modelName} with URL: ${downloadURL}`);
                            @this.set(modelName, downloadURL);
                            Livewire.dispatch('update', { [modelName]: downloadURL });
                            
                            statusElement.innerHTML = `<svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>`;
                            progressElement.classList.add('hidden');
                            document.getElementById(modelName === 'idPhotoUrl' ? 'idPhoto' : 'profilePhoto').value = '';
                        }).catch(error => {
                            console.error('URL fetch failed:', error);
                            alert('Failed to get URL');
                            statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                            progressElement.classList.add('hidden');
                        });
                    }
                );
            }
        })();
    </script>
</div>