<div class="container mx-auto p-4">
    <x-button label="Back to Profile" class="bg-success" icon="o-arrow-uturn-left" link="/profile" spinner />
    <h1 class="text-3xl font-bold mb-4">Terms of Service for Duit Technology Investment Company</h1>

    <h2 class="text-2xl font-semibold mb-2">Introduction</h2>
    <p class="mb-4">
        Welcome to Duit Technology Investment Company. By using our platform, you agree to comply with and be bound by the following Terms of Service ("Terms"). These Terms govern your use of the platform, and by accessing the platform, you agree to these Terms in full. If you do not agree with these Terms, you should not use our platform.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Platform Use</h2>
    <p class="mb-4">
        You agree to use the platform only for lawful purposes and in a way that does not infringe the rights of, restrict, or inhibit anyone else's use and enjoyment of the platform. Prohibited behavior includes harassing or causing distress or inconvenience to any other user, transmitting obscene or offensive content, or disrupting the normal flow of dialogue within the platform.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Account Registration</h2>
    <p class="mb-4">
        To access certain features of the platform, you may be required to register an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete. You are responsible for safeguarding your account credentials and for any activities or actions under your account, whether you have authorized such activities or actions.
    </p>

    <h2 class="text-2xl font-semibold mb-2">User Content</h2>
    <p class="mb-4">
        The platform may allow you to submit, upload, publish, or otherwise make available content such as text, photos, audio, video, or other materials ("User Content"). You retain ownership rights to your User Content, but by making available any User Content on or through the platform, you hereby grant to Duit Technology Investment Company a worldwide, irrevocable, perpetual, non-exclusive, transferable, royalty-free license to use, copy, modify, create derivative works based upon, distribute, publicly display, publicly perform, and distribute your User Content in connection with operating and providing the platform.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Prohibited Activities</h2>
    <p class="mb-4">
        You agree not to engage in any of the following prohibited activities:
        <ul class="list-disc list-inside">
            <li>Using the platform for any illegal purpose or in violation of any local, state, national, or international law.</li>
            <li>Impersonating any person or entity, or falsely stating or otherwise misrepresenting your affiliation with a person or entity.</li>
            <li>Interfering with or disrupting the operation of the platform or the servers or networks used to make the platform available.</li>
            <li>Attempting to gain unauthorized access to any portion of the platform or any other systems or networks connected to the platform, whether through hacking, password mining, or any other means.</li>
        </ul>
    </p>

    <h2 class="text-2xl font-semibold mb-2">Intellectual Property Rights</h2>
    <p class="mb-4">
        All content, trademarks, logos, and other intellectual property rights on the platform are the property of Duit Technology Investment Company or its licensors. You agree not to reproduce, duplicate, copy, sell, resell, or exploit any portion of the platform without express written permission from us.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Termination</h2>
    <p class="mb-4">
        We may terminate or suspend your access to the platform, without prior notice or liability, for any reason whatsoever, including without limitation if you breach these Terms. Upon termination, your right to use the platform will immediately cease.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Limitation of Liability</h2>
    <p class="mb-4">
        To the maximum extent permitted by law, Duit Technology Investment Company shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses, resulting from (i) your use or inability to use the platform; (ii) any unauthorized access to or use of our servers and/or any personal information stored therein; (iii) any interruption or cessation of transmission to or from the platform; (iv) any bugs, viruses, trojan horses, or the like that may be transmitted to or through our platform by any third party; (v) any errors or omissions in any content; and (vi) any defamatory, offensive, or illegal conduct of any third party.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Governing Law</h2>
    <p class="mb-4">
        These Terms shall be governed by and construed in accordance with the laws of the Republic of Kenya, without regard to its conflict of law provisions.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Changes to Terms</h2>
    <p class="mb-4">
        We reserve the right to modify these Terms at any time. Any changes to the Terms will be effective immediately upon posting on the platform. Your continued use of the platform following the posting of revised Terms means that you accept and agree to the changes.
    </p>

    <h2 class="text-2xl font-semibold mb-2">Contact Information</h2>
    <p class="mb-4">
        If you have any questions about these Terms, please contact us at duitechnology@gmail.com or +254799899757.
    </p>

    <p class="mb-4">
        By using our platform, you agree to be bound by these Terms of Service.
    </p>
</div>