<div> 
    {{-- To attain knowledge, add things every day; To attain wisdom, subtract things every day. --}}
    
    <x-header title="Privacy Policy for Duit Technology Investment Company" />
    
    <x-button wire:click="redirectToProfile" label="Back To Profile" class="btn-primary" icon="o-chevron-left" icon-left spinner responsive />
    <div class="my-4"></div>
    
    <x-card>
        <h2 class="text-2xl font-bold mb-4">Introduction</h2>
        <p>
            Duit Technology Investment Company operates a platform that connects startups with potential investors and partners. 
            This Privacy Policy ("Policy") describes how we collect, use, and share your personal information when you use the Platform. 
            We are committed to protecting your privacy and adhering to all applicable data protection laws, 
            including the Data Protection Act, 2019 of Kenya.
            By using our platform, you agree to be bound by the terms in this Privacy Policy as outlined hereunder.
        </p>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Information We Collect</h2>
        <p>
            We collect a variety of personal information about you through the Platform, which can be categorized into three main types:
        </p>

        <ul class="space-y-4">
            <li>
                <strong>Information You Provide Directly:</strong>
                <ul class="list-disc pl-5">
                    <li>Registration and account information: Your name, email address, phone number, company name, and other details submitted during registration and account management.</li>
                    <li>Financial Information: Such as mode of payment and financial account details may be utilized to facilitate secure and efficient transaction processing on the platform.</li>
                    <li>Content and interactions: Information you provide through forms, applications, surveys, and other interactions with the Platform, including startup descriptions, funding goals, and communication with users.</li>
                </ul>
            </li>

            <li>
                <strong>Information Collected Automatically:</strong>
                <ul class="list-disc pl-5">
                    <li>Device and usage data: Your IP address, browser type, operating system, timestamps, pages visited, and other technical information about your device and its interactions with the Platform.</li>
                    <li>Cookies and similar technologies: We use cookies and other tracking technologies to collect information about your browsing activity on the Platform, such as the pages you visit and the links you click.</li>
                </ul>
            </li>

            <li>
                <strong>Information from Third-Party Sources:</strong>
                <ul class="list-disc pl-5">
                    <li>Publicly available information: We may collect information about you that is publicly available online, such as your professional profile on LinkedIn or company information on government websites.</li>
                    <li>Third-party partners: We may receive information about you from third-party providers, such as social media platforms and business databases, to enhance your profile and personalize your experience.</li>
                </ul>
            </li>
        </ul>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Use of Personal Information</h2>
        <p>
            We use your personal information for several purposes, including:
        </p>
        <ul class="list-disc pl-5">
            <li>Providing and maintaining the Platform: Delivering essential features, functionalities, and content related to connecting startups with investors and partners.</li>
            <li>Account management and verification: Facilitating account creation, managing user profiles, and verifying identity to ensure a secure environment.</li>
            <li>Connecting with investors and partners: Matching startups with relevant investors and partners based on their profiles, needs, and interests.</li>
            <li>Marketing and communication: Sending you relevant information about the Platform, new features, investment opportunities, and events, subject to your consent.</li>
            <li>Platform improvement: Analyzing usage data and user feedback to improve the functionality, performance, and user experience of the Platform.</li>
            <li>Compliance and legal obligations: Responding to legal inquiries, complying with regulatory requirements, and enforcing our terms and conditions.</li>
        </ul>
        <p>
            Our platform is not intended for users under the age of 18, and the use of their information shall be subject to the consent and access by a supervising adult in care of the child(ren).
        </p>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Sharing of Personal Information</h2>
        <p>
            We may share your personal information with the following third parties:
        </p>
        <ul class="list-disc pl-5">
            <li>Service providers: We rely on service providers to operate the Platform effectively. This may involve sharing information with cloud storage providers, payment processors, marketing platforms, and other companies that assist us in delivering our services.</li>
            <li>Investors and partners: To facilitate potential funding and collaboration, we may share your startup information with interested investors and partners who fulfill your criteria.</li>
            <li>Legal and regulatory authorities: We are obligated to comply with legal requests and may share your information with law enforcement agencies or other authorities as required by law or to comply with court orders and subpoenas.</li>
            <li>Consent: Your consent is required to use and/or share any information provided on the platform. By using said platform, you agree to grant your consent for and only for the purposes stated on the said platform.</li>
        </ul>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Data Security</h2>
        <p>
            We take the security of your personal information very seriously and implement various measures to protect it from unauthorized access, disclosure, alteration, or destruction. These measures include:
        </p>
        <ul class="list-disc pl-5">
            <li>Encryption: Using industry-standard encryption protocols to protect your data while it is at rest and in transit.</li>
            <li>Firewalls and intrusion detection systems: Implementing advanced security technologies to detect and prevent unauthorized access to our servers and databases.</li>
            <li>Regular security audits and updates: Regularly conducting security audits and updating our systems and software to address vulnerabilities and maintain a secure environment.</li>
            <li>Data access controls: Limiting access to your personal information to authorized personnel and requiring them to comply with our strict data security policies.</li>
        </ul>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Data Retention and Disposition</h2>
        <p>
            We only retain your personal information for as long as necessary to fulfill the purposes described in this Policy. We may also retain your information for longer periods if required by law, such as for tax or financial reporting purposes. However, we will always strive to minimize the amount of data we store and regularly review and delete outdated or unnecessary information.
        </p>
        <p>
            All outdated, unnecessary, and prohibited information whether at the request of our clients or at our initiative shall be disposed of using industry-standard data destruction and disposal protocols to protect your data even after it no longer serves the purposes outlined hereinabove.
        </p>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Your Rights</h2>
        <p>
            You have certain rights regarding your personal information under applicable data protection laws, including:
        </p>
        <ul class="list-disc pl-5">
            <li>Right to Consent: You have a right to consent or to withdraw consent to the acquiring or use of any information requested that falls under the ambit of personal and/or private information.</li>
            <li>Right to access: You have the right to request access to the personal information we hold about you.</li>
            <li>Right to rectification: You have the right to request that we correct any inaccurate or incomplete personal information.</li>
            <li>Right to erasure: You have the right to request that we delete your personal information.</li>
            <li>Right to restrict processing: You have the right to request that we restrict the processing.</li>
            <li>Right to opt-out: You have a right to opt-out of any agreements or arrangements from the platform by a notice written to the administrators of the platform or by accessing account preferences and privacy settings provided on the platform.</li>
            <li>Right to manage your account: You have a right to manage your account by accessing account preferences and privacy settings.</li>
        </ul>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Changes to this Privacy Policy</h2>
        <p>
            We reserve the right to modify this Privacy Policy.
        </p>
        <p>
            Users will be notified of significant changes, and continued use of the platform constitutes acceptance of updated terms.
        </p>
    </x-card>

    <x-card class="mt-4">
        <h2 class="text-2xl font-bold mb-4">Contact Information</h2>
        <p>
            For questions regarding this Privacy Policy, please contact us at 
            <span class="font-semibold">duitechnology@gmail.com</span> 
            or 
            <span class="font-semibold">+254799899757</span>.
        </p>
    </x-card>

    <x-card class="mt-4">
        <p>
            By using our platform, you agree and are bound to the terms outlined in this Privacy Policy.
        </p>
    </x-card>
</div>