<div>
    <x-form wire:submit="submit">
        @if ($step === 1)
            <x-header title="Business Verification" subtitle="General Company Information" />

            <x-input label="Company Name" placeholder="Enter Company Name" wire:model.defer="formData.companyName" />
            <x-input label="Owner Full names" placeholder="Enter Owner full names" wire:model.defer="formData.ownerFullNames" />
            <x-input label="Owner passport/id" placeholder="Enter Owner passport/id" wire:model.defer="formData.ownerPassportId" />
            
            @php
                $config3 = ['maxDate' => now()->format('Y-m-d')];
            @endphp
            <x-datepicker 
                label="Date of incorporation" 
                placeholder="Enter date of incorporation" 
                wire:model.defer="formData.dateOfIncorporation"
                :config="$config3" 
            />
            <x-input label="Owner Details" placeholder="Enter Owner Details" wire:model.defer="formData.ownerDetails" />
            <x-input label="Operating Country" placeholder="Enter Operating Country" wire:model.defer="formData.operatingCountry" />

            <x-radio 
                label="Has any shareholder passed a resolution" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.shareholderResolution"
            />
            <x-radio 
                label="Are there any current agreements pertaining to disposal, voting or acquisition of the Company's shares?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.currentAgreements"
            />
            <x-radio 
                label="Is there any capital changes in the company from the date of incorporation?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.capitalChanges"
            />
            <x-radio 
                label="Has any third party been issued with any security to cover the company or been issued with any security over any company asset?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.thirdPartySecurity"
            />
        @elseif ($step === 2)
            <x-header title="Business Verification" subtitle="Business Information" />
            
            <x-input label="Description of main business activity" placeholder="Enter Description of main business activity" wire:model.defer="formData.mainBusinessActivity" />
            <x-input label="Is the company involved in any other business? If yes, detail" placeholder="Enter Is the company involved in any other business? If yes, detail" wire:model.defer="formData.otherBusinessDetails" />
            <x-radio 
                label="Does the company hold any shares in partnership, association or in another company?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.sharesInOtherCompanies"
            />
            <x-radio 
                label="Is the company a member of any trade association?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.tradeAssociation"
            />
            <x-textarea label="Provide a list with details of the competitors of the company" placeholder="Enter Provide a list with details of the competitors of the company" wire:model.defer="formData.competitorsList" />
            <x-radio 
                label="Are there any agreements (legally enforceable) that might restrict the Company's activities in any jurisdiction?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.restrictiveAgreements"
            />
            <x-radio 
                label="Have there been any formal complaints or situations where the company was involved with any investigations with any office regulating fair trading or fair competition?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.fairTradingInvestigations"
            />
            <x-radio 
                label="Are there any agreements the company has with any dealer, supplier or an intermediary pertaining to allocation of customer territory or restrictions on resale?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.customerTerritoryRestrictions"
            />
            <x-radio 
                label="Has the company signed a contract of sale of any product/service where the delivery and payments take more than six months to be completed?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.longTermContracts"
            />
            <x-input label="Describe the credit agreements the Company has with respect to its clients where the clients take more than 30 days to make the payment. Also list the circumstances and types of discount provided" placeholder="Enter Describe the credit agreements the Company has with respect to its clients where the clients take more than 30 days to make the payment. Also list the circumstances and types of discount provided" wire:model.defer="formData.creditAgreements" />
            <x-input label="Describe the agreements the Company has entered into which cannot be terminated without a notice period that is less than a month and which cannot be broken without the Company paying any compensation" placeholder="Enter Describe the agreements the Company has entered into which cannot be terminated without a notice period that is less than a month and which cannot be broken without the Company paying any compensation" wire:model.defer="formData.terminationAgreements" />
            <x-radio 
                label="Does the company possess any licenses and distribution agreements?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.licensesDistributionAgreements"
            />
            <x-radio 
                label="Are there any arrangements which when terminated can change the control of the company?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.controlChangeArrangements"
            />
            <x-radio 
                label="Are there any arrangements which when terminated can cause a significant monetary impact on the Company?" 
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.monetaryImpactArrangements"
            />
            <x-radio 
                label="Are there any contracts that are currently being negotiated by the Company that are of material nature?(The contracts under consideration can be either made by or proposed to the Company)"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.materialContractsUnderNegotiation"
            />
            <x-radio 
                label="Are there any contracts whether written or unwritten that can restrict the activities of the company?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.restrictiveContracts"
            />
            <x-radio 
                label="Are there any customers that accounted for more than 5% of Company's total revenue in the preceding year?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.customersMoreThan5Percent"
            />
            <x-radio 
                label="Are there any suppliers that accounted for more than 5% of Company's total services in the preceding year?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.suppliersMoreThan5Percent"
            />
            <x-radio 
                label="Are there any material contracts that are not part of any contract asked above?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.materialContracts"
            />
        @elseif ($step === 3)
            <x-header title="Business Verification" subtitle="Accounting Information" />
            <x-radio 
                label="Specify which accounting standard is being used (US, GAAP, IFRS) and state whether there has been any change in the adopted accouting standard"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.accountingStandard"
            />
            <x-input label="Accounting Standard" placehodler="Enter Accounting Standard" wire:model.defer="formData.accountingStandardForm" />
            <x-input label="State the names and contact details of Company's bankers (Bank name, address and phone number)" placeholder="Enter State the names and contact details of Company's bankers (Bank name, address and phone number)" wire:model.defer="formData.bankersDetails" />
            <x-input label="State the details of all accounts (a/c name & a/c number) held by Company along with the current overdraft or any borrowing. Only one account." placeholder="Enter State the details of all accounts (a/c name & a/c number) held by Company along with the current overdraft or any borrowing. Only one account." wire:model.defer="formData.accountDetails" />
            <x-radio 
                label="Does the Company have debt securities along with mortgages and any property belonging to the Company that has been used as a collateral?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.debtSecurities"
            />
            <x-radio 
                label="Are there any loans given to the Company by any third-party including loans given by any person or entity including loans given by any person or entity associated with the Directors or Shareholders of the company?"                
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.loansGiven"
            />
            <x-radio 
                label="Does the Company have budgets, financial forecasts for the last five financial years?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.financialForecasts"
            />
            <x-radio 
                label="Does the Company have any grants received or applied by the company in the past five years?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.grantsReceived"
            />
            <x-radio 
                label="Does the Company have any credit sales agreements, hire purchase agreements, leasing and/or rental contracts?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.creditSalesAgreements"
            />
            <x-radio 
                label="Does the Company have any guarantees, indemnities or sureties given in favor of the Company?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.guaranteesGiven"
            />
            <x-radio 
                label="Does the Company have liabilities or potential liabilities outstanding or arising from any acquisition or divestment agreement?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.liabilitiesOutstanding"
            />
            <x-radio 
                label="Is there any reorganization that will be carried out in the next twelve months?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.reorganization"
            />
            <x-radio 
                label="Have there been previous reorganizations(if any) that have taken place in the past?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.previousReorganizations"
            />
            <x-radio 
                label="Are there any contracts to acquire or divest using Company shares ir any other shares in the last five years?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.acquireDivestContracts"
            />

        @elseif ($step === 4)
            <x-header title="Business Verification" subtitle="Asset Information" />
            
            <!-- Add fields for Accounting Information here -->
            <x-input label="Provide details about all Company Assets below stating current value in Kenya Shillings (incl cash, software, property etc)" placeholder="Enter Prove details about all Company Assets below stating current value in Kenya Shillings (incl cash, software, property etc)" wire:model.defer="formData.companyAssets" />
            <x-radio 
                label="Does the Company own any property and/or land?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.companyOwnsProperty"
            />
        @elseif ($step === 5)
            <x-header title="Business Verification" subtitle="Intellectual Property" />
            
            <x-radio 
                label="Does the Company own any patents, trade marks, registered designs, and property rights?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.companyOwnsIntellectualProperty"
            />
            <x-input label="Mention the people in the Company that look after the Company's intellectual/ Industrial Property Rights (IPR)" placeholder="Enter Mention the people in the Company that look after the Company's intellectual/ Industrial Property Rights (IPR)" wire:model.defer="formData.intellectualPropertyRights" />
            <x-input label="Describe how the decisions pertaining to the exploitation of Company's IPR are made" placeholder="Enter Describe how the decisions pertaining to the exploitation of Company's IPR are made" wire:model.defer="formData.iprExploitation" />
            <x-radio 
                label="Have there been any dispute between the persons looking after the Company's IPR regarding the rights or any other facts?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.iprDisputes"
            />
        @elseif ($step === 6)
        <x-header title="Business Verification" subtitle="Employment Policy" />
            
            <x-radio 
                label="Have there been any disciplinary actions taken against any employee?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.disciplinaryActions"
            />
            <x-radio 
                label="Are there employees of the Company part of any trade union, staff association or any worker's representation body?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.tradeUnionMembers"
            />
            <x-radio 
                label="Does the Company have any liability regarding financial support or has received any contribution notice?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.financialSupportLiability"
            />
            <x-radio 
                label="Have any of the directors of the Company ever filed for bankruptcy, have any outstanding convictions or ever held any government position?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.directorsBackground"
            />
            <x-radio 
                label="Did any of the directors have any material interest in any business that files for bankruptcy or been under investigation in the past twelve months?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.directorsMaterialInterest"
            />
            <x-radio 
                label="Are there any Directors, employees or majority shareholders who have taken an interest in a business that is in direct competition with the Company?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.directorsCompetingBusiness"
            />
        @elseif ($step === 7)
            <x-header title="Business Verification" subtitle="Compliance and ESG" />
            
            <x-input label="Describe the events, acts or circumstances or omissions that mights make the Company non-compliance with any law, regulation pertaining to health and safety of workers, environment or asset that the company uses." placeholder="Enter Describe the events, acts or circumstances or omissions that mights make the Company non-compliance with any law, regulation pertaining to health and safety of workers, environment or asset that the company uses." wire:model.defer="formData.complianceDescription" />
            <x-input label="Confirm that no officer or employee has ever failed to perform any statutory duty with respect to the Company." placeholder="Enter Confirm that no officer or employee has ever failed to perform any statutory duty with respect to the Company." wire:model.defer="formData.statutoryDuty" />
            <x-radio 
                label="Are there any disputes or potential disputes with existing employees, customers, suppliers?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.disputesWithEmployees"
            />
            <x-input label="Describe the situations where any of the Company's permits or licenses can be suspended, revoked or not renewed." placeholder="Enter Describe the situations where any of the Company's permits or licenses can be suspended, revoked or not renewed." wire:model.defer="formData.licenseSuspension" />
            <x-input label="Provide details of any withdrawal or refusal of insurance cover in the past five years." placeholder="Enter Provide details of any withdrawal or refusal of insurance cover in the past five years." wire:model.defer="formData.insuranceCover" />
            <x-input label="Describe the situations where a claim under an insurance policy can be made in the next twelve months about which insurer is not notified about." placeholder="Enter Describe the situations where a claim under an insurance policy can be made in the next twelve months about which insurer is not notified about." wire:model.defer="formData.insuranceClaim" />
            <x-radio 
                label="Has the Company carried out any processing of personal data according to the relevant data protection laws applicable to the Company?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.dataProcessing"
            />
            <x-radio 
                label="Does the Company use any data pertaining to any minors?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.minorData"
            />
            <x-radio 
                label="Is the Company compliant with the latest data protection acts?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.dataProtectionCompliant"
            />
            <x-radio 
                label="Does the Company employ any third-party to process personal data?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.thirdPartyDataProcessing"
            />
            <x-radio 
                label="Does the Company have any copyright of any software that it uses?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.softwareCopyright"
            />
            <x-input label="Describe the circumstances in which the Company might lose its access to its software or hardware." placeholder="Enter Describe the circumstances in which the Company might lose its access to its software or hardware." wire:model.defer="formData.softwareAccess" />
            <x-input label="Provide details(if any) of any past dispute or ongoing dispute with respect to the usage of the Company's IT infrastructure with any third-party" placeholder="Enter Provide details(if any) of any past dispute or ongoing dispute with respect to the usage of the Company's IT infrastructure with any third-party" wire:model.defer="formData.itDispute" />
            <x-input label="Provide details of domain names registered in the name of the Company including details of the email provider used by the Company." placeholder="Enter Provide details of domain names registered in the name of the Company including details of the email provider used by the Company." wire:model.defer="formData.domainNames" />
            <x-input label="Details any health and safety related risk assessments carried out by the Company." placeholder="Enter Details any health and safety related risk assessments carried out by the Company." wire:model.defer="formData.healthSafetyRiskAssessment" />
            <x-radio 
                label="Has there been any communication between the Company and the Health and Safety Authority or any relevant authority in the past?"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.healthSafetyCommunication"
            />
            <x-radio 
                label="Has the Company received or given any notice from the regulating Environmental Agency regarding non-compliance with respect to the sites, properties currently as well as formerly used by the Company?" placeholder="Enter Has the Company received or given any notice from the regulating Environmental Agency regarding non-compliance with respect to the sites, properties currently as well as formerly used by the Company?" wire:model.defer="formData.environmentalNonCompliance"
                :options="[
                    ['id' => 'true', 'name' => 'Yes'],
                    ['id' => 'false', 'name' => 'No'],
                ]" 
                wire:model.defer="formData.environmentalNonCompliance"
            />
        @endif

        <x-slot:actions>
            @if ($step > 1)
                <x-button wire:click="previousStep" label="Back" class="btn-primary" spinner />
            @endif
            @if ($step < 7)
                <x-button wire:click="nextStep" label="Next" class="btn-primary" spinner />
            @else
                <x-button type="submit" label="Submit" class="btn-primary" spinner="submit" icon="o-check-circle" responsive />
            @endif
        </x-slot:actions>
    </x-form>
</div>