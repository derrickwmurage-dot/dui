<div>
    <x-header title="Advisory Services" subtitle="" >
        <x-slot:middle class="!justify-end">
            <div class="relative flex">
                <x-input 
                    icon="o-bolt" 
                    placeholder="Search..." 
                    wire:model.live.debounce.300ms="searchTerm" 
                />
                
                <x-loading 
                    wire:loading
                    wire:target="searchTerm"
                    class="absolute right-3 top-1/2 transform -translate-y-1/2"
                />
            </div>
        </x-slot:middle>
    </x-header>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        @forelse($advisoryServicesData as $data)
            <div class="flex h-full">
                <x-card 
                    class="w-full h-full transition-transform duration-150 hover:scale-[1.02] cursor-pointer relative flex flex-col" 
                    wire:loading.class="opacity-50"
                    wire:target="openServiceProvidersPage('{{ $data['id'] }}')"
                >
                    {{-- Loading overlay --}}
                    <div 
                        wire:loading
                        wire:target="openServiceProvidersPage('{{ $data['id'] }}')"
                        class="absolute inset-0 bg-white/50 flex items-center justify-center z-10"
                    >
                        <x-loading />
                    </div>

                    <!-- Card content -->
                    <div class="text-justify p-4 flex-grow">
                        <p class="font-bold">{{ $data['title'] ?? 'No title' }}</p>
                        <p class="overflow-hidden text-ellipsis line-clamp-3">
                            {{ Str::limit($data['description'] ?? 'No description available.', 200) }}
                        </p>
                    </div>
                    
                    <!-- Buttons container sticks to the bottom -->
                    <div class="mt-auto flex justify-between items-center p-4 border-t">
                        <x-button 
                            label="LEARN MORE" 
                            class="btn-ghost text-blue-600" 
                            wire:click="openAdvisoryServiceDetails('{{ $data['id'] ?? '' }}')"
                            spinner
                        />
                        <x-button 
                            label="INQUIRE" 
                            class="btn-secondary" 
                            wire:click="openServiceProvidersPage('{{ $data['id'] }}')"
                            spinner
                            responsive
                            icon="o-question-mark-circle"
                        />
                        @if(isset($data['price']))
                            <span class="font-bold text-lg">
                                ${{ number_format($data['price'], 2) }}
                            </span>
                        @endif
                    </div>
                    
                </x-card>
            </div>
        @empty
            <div class="col-span-full text-center py-12">
                <p class="text-2xl text-gray-500">No advisory services found.</p>
            </div>
        @endforelse
    </div>

    <!-- Modal for Advisory Service Details -->
    <x-modal wire:model="advisoryServiceDetailsModal" class="backdrop-blur">
        <div class="p-6">
            <x-header title="{{ $selectedAdvisoryService['title'] ?? 'Details' }}" />
            <p>{{ $selectedAdvisoryService['description'] ?? 'No description available.' }}</p>
            
            <p class="font-bold">Features</p>
            @if(!empty($selectedAdvisoryService['features']))
                <ul class="list-disc pl-5">
                    @foreach($selectedAdvisoryService['features'] as $feature => $description)
                        <li>
                            <strong>{{ $feature }}</strong> <!-- Feature name as a subheading -->
                            <p class="ml-4">{{ $description }}</p> <!-- Description as a paragraph -->
                        </li>
                    @endforeach
                </ul>
            @else
                <p>No features available.</p>
            @endif

        </div>
    </x-modal>


    @if($paymentStatusModal)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full" id="payment-status-modal">
            <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <div class="mt-3 text-center">
                    @if($paymentStatus === 'success')
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                            <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4">Payment Successful!</h3>
                    @else
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                            <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4">Payment Not Completed</h3>
                    @endif
                    
                    <div class="mt-2 px-7 py-3">
                        <p class="text-sm text-gray-500">
                            {{ $paymentMessage }}
                        </p>
                    </div>
                    <div class="items-center px-4 py-3">
                        <button wire:click="closePaymentStatusModal"
                                class="px-4 py-2 bg-blue-500 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
