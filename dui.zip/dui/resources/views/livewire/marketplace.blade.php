<div
    x-data
    data-firebase-user="{{ session('firebase_user') }}"
    data-firebase-token="{{ session('firebase_token') }}"
>
    @assets
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-storage-compat.js"></script>
    @endassets

    <x-header title="Marketplace" subtitle="Invest in companies and startups">
        <x-slot:middle class="!justify-end">
            <div class="relative flex">
                <x-input 
                    icon="o-bolt" 
                    placeholder="Search..." 
                    wire:model.live.debounce="searchTerm" 
                />
                <x-loading 
                    wire:loading
                    wire:target="searchTerm"
                    class="absolute right-3 top-1/2 transform -translate-y-1/2"
                />
            </div>
        </x-slot:middle>
    </x-header>
    <x-button label="Add Marketplace Item" icon="o-plus-circle" wire:click="openCreateMarketplaceItemModal" class="btn-secondary" responsive spinner />

    <div class="container mx-auto p-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($marketplaceData as $index => $data)
                <div class="group bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl cursor-pointer" wire:click="openMarketplaceModal({{ $index }})">
                    <div class="relative h-64 overflow-hidden">
                        <img 
                            src="{{ $data['imageUrl'][0] ?? 'https://via.placeholder.com/400' }}" 
                            alt="{{ $data['title'] }}" 
                            class="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>

                    <div class="p-6">
                        <h5 class="text-xl font-bold mb-3 text-gray-800 dark:text-gray-100 line-clamp-1">{{ $data['title'] }}</h5>
                        <p class="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3 text-sm leading-relaxed">{{ $data['description'] }}</p>
                        <p class="text-gray-800 dark:text-gray-200 font-medium text-lg">${{ number_format($data['companyAsk'], 2) }}</p>

                        <div class="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                            <div class="flex space-x-4">
                                <button 
                                    wire:click.stop="toggleInterest({{ $index }}, 'interest')"
                                    class="group/btn flex items-center space-x-1 transition-colors {{ isset($data['showedInterestUsers']) && in_array(session('firebase_user'), $data['showedInterestUsers']) ? 'text-green-500' : 'text-gray-500 dark:text-gray-400 hover:text-green-500' }}"
                                >
                                    <x-icon name="o-hand-thumb-up" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                    <span class="text-sm font-medium">{{ count($data['showedInterestUsers'] ?? []) }}</span>
                                </button>
                                <button 
                                    wire:click.stop="toggleInterest({{ $index }}, 'disinterest')"
                                    class="group/btn flex items-center space-x-1 transition-colors {{ isset($data['showedDisinterestUsers']) && in_array(session('firebase_user'), $data['showedDisinterestUsers']) ? 'text-red-500' : 'text-gray-500 dark:text-gray-400 hover:text-red-500' }}"
                                >
                                    <x-icon name="o-hand-thumb-down" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                    <span class="text-sm font-medium">{{ count($data['showedDisinterestUsers'] ?? []) }}</span>
                                </button>
                                <button 
                                    wire:click.stop="openComments({{ $index }})"
                                    class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors"
                                >
                                    <x-icon name="o-chat-bubble-bottom-center-text" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                    <span class="text-sm font-medium">{{ count($data['reviews'] ?? []) }}</span>
                                </button>
                            </div>
                            @php
                                $userId = session('firebase_user');
                                $isInvestor = false;
                                $isApproved = false;
                                $isCreator = $data['creator'] === (string) $userId;
                                if(isset($data['investors']) && is_array($data['investors'])) {
                                    foreach ($data['investors'] as $investor) {
                                        if ($investor['investorId'] === $userId) {
                                            $isInvestor = true;
                                            $isApproved = $investor['approved'];
                                            break;
                                        }
                                    }
                                }
                            @endphp
                            @if ($isCreator)
                                <button wire:click.stop="redirectToInvestors({{ $index }})" class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors">
                                    <x-icon name="o-users" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                    <span class="text-sm font-medium">Show Investors</span>
                                </button>
                            @elseif ($isInvestor)
                                @if (!$isApproved)
                                    <button class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 cursor-not-allowed">
                                        <x-icon name="o-clock" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                        <span class="text-sm font-medium">Approval Pending</span>
                                    </button>
                                @else
                                    <button wire:click.stop="approvedInvestorAction({{ $index }})" class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors">
                                        <x-icon name="o-check-circle" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                        <span class="text-sm font-medium">Approved - Take Action</span>
                                    </button>
                                @endif
                            @else
                                <button wire:click.stop="openInvestModal({{ $index }})" class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors">
                                    <x-icon name="o-shopping-cart" class="w-5 h-5 transition-transform group-hover/btn:scale-110" label="Invest" />
                                    <span wire:loading wire:target="openInvestModal({{ $index }})">
                                        <x-loading />
                                    </span>
                                </button>
                            @endif
                            @if ($isCreator)
                                <button wire:click.stop="openEditMarketplaceItemModal({{ $index }})" class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors">
                                    <x-icon name="o-pencil" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                    <span class="text-sm font-medium">Edit</span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <!-- Modals -->
        <x-modal wire:model="marketplaceModal" max-width="4xl">
            @if($modalData)
                <div class="relative overflow-hidden rounded-xl bg-white dark:bg-gray-800">
                    <div class="relative h-[60vh] transform transition-transform duration-1000 hover:scale-105">
                        <img 
                            src="{{ $modalData['imageUrl'][0] ?? 'https://via.placeholder.com/400' }}" 
                            alt="{{ $modalData['title'] }}" 
                            class="absolute inset-0 w-full h-full object-cover"
                        >
                        <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                        <div class="absolute bottom-0 left-0 right-0 p-8 text-white">
                            <h2 class="text-4xl font-bold mb-2 transform transition-all duration-500 translate-y-0">{{ $modalData['title'] }}</h2>
                        </div>
                    </div>

                    <div class="mt-4 text-gray-800 dark:text-gray-200">
                        {{ $modalData['description'] }}
                        <hr class="border-gray-200 dark:border-gray-700" />
                    </div>

                    <div class="p-6">
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Company Valuation:</b> ${{ number_format($companyValuation, 2) }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Company Ask:</b> ${{ number_format($modalData['companyAsk'], 2) }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Equity Stake:</b> {{ number_format($equityAmount * 100, 4) }}%</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Amount Raised:</b> ${{ number_format($modalData['amountInvested'], 2) }}</p>
                        <x-button link="/marketplace/info/{{ $modalData['id'] }}" class="btn-secondary" label="More Info here" icon="o-information-circle" spinner />
                    </div>
                </div>
            @endif
        </x-modal>

        <x-modal wire:model="investModal" max-width="4xl">
            @if($modalInvestData)
                <x-form wire:submit.prevent="submitInvestForm" class="dark:bg-gray-800">
                    <x-textarea label="State what other values you will add to the venture besides funding" wire:model="valueAddition" />
                    <input type="range" min="0" max="{{ $modalInvestData['companyAsk'] ?? 0 }}" step="1" wire:model.live="investmentAmount" class="range" label="Select the investment amount" />
                    <p class="dark:text-gray-200">Selected Investment: ${{ number_format($investmentAmount, 2) }}</p>
                    <p class="dark:text-gray-200">Equity: {{ number_format($equityPercentage, 2) }}%</p>
                    <x-slot:actions>
                        <x-button class="btn-ghost" label="Cancel" wire:click="closeInvestModal" />
                        <x-button class="btn-secondary" label="Submit" type="submit" spinner="submitInvestForm" />
                    </x-slot:actions>
                </x-form>
            @endif
        </x-modal>

        <x-modal wire:model="paymentModal">
            @if($investmentDetails)
                <x-form wire:submit.prevent="proceedToPayment" class="dark:bg-gray-800">
                    <div class="flex justify-center">
                        <x-icon name="o-banknotes" class="dark:text-gray-200" />
                    </div>
                    <p class="dark:text-gray-200">Proceed and make payment of ${{ number_format($investmentDetails['investmentAmount'], 2) }} 
                        to {{ $investmentDetails['companyName'] }}
                        for an equity stake of {{ number_format($investmentDetails['equity'], 4) }}%</p>
                    <x-slot:actions>
                        <x-button class="btn-ghost" label="Cancel" wire:click="closePaymentModal" />
                        <x-button class="btn-secondary" label="Proceed" type="submit" spinner="proceedToPayment" />
                    </x-slot:actions>
                </x-form>
            @endif
        </x-modal>

        <x-modal wire:model="createMarketplaceItemModal" max-width="2xl">
            <x-form wire:submit="createMarketplace" class="dark:bg-gray-800">
                <x-header title="Add Marketplace Item" subtitle="Fill in the details to create a new marketplace listing" />
                <div class="space-y-4">
                    <x-input label="Title" wire:model="form.title" placeholder="Enter the title" required />
                    <x-textarea label="Description" wire:model="form.description" placeholder="Describe your marketplace item" rows="4" required />
                    <x-input label="Amount Invested ($)" wire:model="form.amountInvested" type="number" placeholder="Total amount already invested" step="0.01" />
                    <x-input label="Company Ask ($)" wire:model="form.companyAsk" type="number" placeholder="Amount you're asking for" required step="0.01" />
                </div>
                <div class="mt-6 space-y-4">
                    <!-- Pitch Deck -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload Pitch Deck</label>
                        @if($pitchDeckUrl)
                            <div class="mt-2 flex items-center">
                                <a href="{{ $pitchDeckUrl }}" target="_blank" class="text-blue-600 underline">View Pitch Deck</a>
                                <button wire:click="$set('pitchDeckUrl', '')" class="ml-4 text-red-500 hover:text-red-700" title="Remove Pitch Deck">
                                    <x-icon name="o-x-circle" class="w-5 h-5" />
                                </button>
                            </div>
                        @else
                            <input 
                                type="file" 
                                id="pitchDeckInput" 
                                accept="application/pdf" 
                                onchange="uploadPitchDeckToFirebase(event, 'pitchDeckUrl', 'pitchDeckStatus', 'pitchDeckProgress', 'pitchDeck_percentage')"
                                class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 dark:file:bg-gray-700 dark:file:text-gray-300"
                            >
                            <input type="hidden" wire:model="pitchDeckUrl" />
                            <div id="pitchDeckStatus" class="mt-2"></div>
                            <div id="pitchDeckProgress" class="mt-2 hidden">
                                <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                                <span id="pitchDeck_percentage" class="text-sm">0%</span>
                            </div>
                            <span class="text-xs text-gray-500 dark:text-gray-400">Only PDF, recommended max 5MB</span>
                        @endif
                        @error('pitchDeckUrl') <x-alert title="Pitch Deck Error" :description="$message" negative class="mt-2" /> @enderror
                    </div>
                    <!-- Images -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload Images</label>
                        <!-- File Input for Multiple Images -->
                        <input 
                            type="file" 
                            id="imageInput" 
                            accept="image/jpeg,image/png,image/gif" 
                            multiple
                            onchange="handleMultipleImageSelection(event, 'imageInput', 'imagePreviewContainer', 'imageUrls', 'imageUploadStatus', 'imageUploadProgress', 'imageUpload_percentage')"
                            class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 dark:file:bg-gray-700 dark:file:text-gray-300"
                        >
                        <!-- Status and Progress -->
                        <div id="imageUploadStatus" class="mt-2"></div>
                        <div id="imageUploadProgress" class="mt-2 hidden">
                            <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                            <span id="imageUpload_percentage" class="text-sm">0%</span>
                        </div>
                        <span class="text-xs text-gray-500 dark:text-gray-400">JPEG, PNG, or GIF. Multiple images allowed.</span>
                        <!-- Preview Container -->
                        <div id="imagePreviewContainer" class="mt-2 flex flex-wrap gap-2"></div>
                        <!-- Uploaded Images -->
                        <div class="mt-2 flex flex-wrap gap-2">
                            @foreach($imageUrls as $index => $url)
                                <div class="relative">
                                    <img src="{{ $url }}" alt="Uploaded Image" class="h-20 w-20 object-cover rounded-lg">
                                    <button wire:click="removeImage({{ $index }})" class="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600" title="Remove Image">
                                        <x-icon name="o-x-circle" class="w-4 h-4" />
                                    </button>
                                </div>
                            @endforeach
                        </div>
                        @error('imageUrls') <x-alert title="Image Error" :description="$message" negative class="mt-2" /> @enderror
                    </div>
                </div>
                <div class="mt-6 space-y-4">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Additional Details (Optional)</h3>
                    <x-input label="Founder" wire:model="form.founder" placeholder="Name of the founder" />
                    <x-input label="Business Type" wire:model="form.businessType" placeholder="e.g., B2C, B2B" />
                    <x-input label="Website" wire:model="form.website" placeholder="https://example.com" icon="o-link" />
                    <x-input label="Location" wire:model="form.location" placeholder="City, Country" icon="o-map-pin" />
                    <x-input label="Financial Forecast" wire:model="form.financialForecast" placeholder="Projected revenue" />
                    <x-input label="Operations & Management" wire:model="form.operationsAndManagement" placeholder="Team structure" />
                    <x-input label="Marketing & Sales Strategy" wire:model="form.marketingAndSalesStrategy" placeholder="Marketing plan" />
                    <x-input label="Financial Statements" wire:model="form.financialStatements" placeholder="Financial summary" />
                    <x-input label="Portfolio Management" wire:model="form.portfolioManagement" placeholder="Portfolio details" />
                    <x-input label="Research & Development" wire:model="form.researchAndDevelopement" placeholder="R&D plans" />
                    <x-input label="Risk Management" wire:model="form.riskManagement" placeholder="Risk mitigation" />
                    <x-input label="Exit Strategy" wire:model="form.exitStrategy" placeholder="Exit plan" />
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Company Valuation (Please provide accurate data)</label>
                        <x-input label="Enter your average revenue per annum" wire:model.live="form.companyValuation" type="number" placeholder="Annual Revenue" step="0.01" />
                        <x-input label="Enter your average earnings per annum" wire:model.live="form.earnings" type="number" placeholder="Annual Earnings" step="0.01" />
                        <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                            Calculated Company Valuation: ${{ number_format($calculatedCompanyValuation, 2) }}
                        </div>
                    </div>
                </div>
                <x-slot:actions>
                    <div>Note that you are only allowed to post one start-up per account</div>
                    <x-button label="Cancel" class="btn-ghost" wire:click="closeCreateMarketplaceItemModal" />
                    <x-button 
                        label="Submit" 
                        class="btn-secondary" 
                        type="submit" 
                        icon="o-check-circle" 
                        spinner="createMarketplace"
                        wire:loading.attr="disabled"
                        :disabled="$isSubmitting"
                    >
                        <span wire:loading wire:target="createMarketplace">Submitting...</span>
                        <span wire:loading.remove wire:target="createMarketplace">Submit</span>
                    </x-button>
                </x-slot:actions>
            </x-form>
            
            <script>
(function() {
    let firebaseInitialized = false;
    const config = {
        apiKey: "{{ env('FIREBASE_API_KEY') }}",
        authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
        projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
        storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
        messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
        appId: "{{ env('FIREBASE_APP_ID') }}"
    };

    function initializeFirebase() {
        if (firebaseInitialized) return;
        if (typeof firebase === 'undefined') {
            console.error('Firebase SDK not loaded');
            setTimeout(initializeFirebase, 1000);
            return;
        }
        try {
            if (!firebase.apps.length) {
                firebase.initializeApp(config);
            }
            firebaseInitialized = true;
            const rootElement = document.querySelector('[data-firebase-user]');
            const sessionUser = rootElement?.dataset.firebaseUser;
            const sessionToken = rootElement?.dataset.firebaseToken;

            if (sessionUser) return;
            firebase.auth().onAuthStateChanged(user => {
                if (!user && !sessionUser) {
                    window.location.href = '/login';
                }
            });
        } catch (error) {
            console.error('Firebase initialization error:', error);
            setTimeout(initializeFirebase, 1000);
        }
    }

    document.addEventListener('DOMContentLoaded', initializeFirebase);
    initializeFirebase();

    // Image upload handler
    window.handleMultipleImageSelection = function(event, inputId, previewContainerId, modelName, statusElementId, progressElementId, percentageElementId) {
        const input = document.getElementById(inputId);
        const previewContainer = document.getElementById(previewContainerId);
        const files = Array.from(event.target.files).filter(file => file.type.startsWith('image/'));

        if (!files.length) {
            statusElementId.innerHTML = 'No valid images selected.';
            return;
        }

        previewContainer.innerHTML = '';
        if (modelName.startsWith('editForm.imageUrl')) {
            const uploadedImagesContainer = previewContainer.nextElementSibling;
            if (uploadedImagesContainer) {
                uploadedImagesContainer.style.display = 'none';
            }
        }

        files.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewDiv = document.createElement('div');
                previewDiv.className = 'relative h-20 w-20';
                previewDiv.innerHTML = `
                    <img src="${e.target.result}" alt="Image Preview" class="h-20 w-20 object-cover rounded-lg">
                    <button onclick="clearImagePreview('${inputId}', '${previewContainerId}', ${index})" class="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600" title="Clear Preview">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                `;
                previewContainer.appendChild(previewDiv);
            };
            reader.readAsDataURL(file);

            const uploadEvent = { target: { files: [file] } };
            window.uploadToFirebase(uploadEvent, `${modelName}.newImageUrls.${index}`, statusElementId, progressElementId, percentageElementId);
        });
    };

    // Clear image preview
    window.clearImagePreview = function(inputId, previewContainerId, index) {
        const input = document.getElementById(inputId);
        const previewContainer = document.getElementById(previewContainerId);
        const previews = previewContainer.getElementsByClassName('relative');
        if (previews[index]) {
            previews[index].remove();
        }
        if (previews.length === 0) {
            input.value = '';
            const uploadedImagesContainer = previewContainer.nextElementSibling;
            if (uploadedImagesContainer && previewContainerId === 'editImagePreviewContainer') {
                uploadedImagesContainer.style.display = 'flex';
            }
        }
        if (previewContainerId === 'editImagePreviewContainer') {
            @this.set(`editForm.imageUrl.newImageUrls.${index}`, null);
        } else {
            @this.set(`imageUrls.${index}`, null);
        }
    };

    // General Firebase upload function
    window.uploadToFirebase = function(event, modelName, statusElementId, progressElementId, percentageElementId, retries = 3) {
        if (!firebaseInitialized) {
            console.warn('Firebase not initialized, retrying...');
            if (retries > 0) {
                setTimeout(() => window.uploadToFirebase(event, modelName, statusElementId, progressElementId, percentageElementId, retries - 1), 1000);
            } else {
                alert('Upload system not ready. Please refresh the page.');
            }
            return;
        }

        const rootElement = document.querySelector('[data-firebase-user]');
        const sessionUser = rootElement?.dataset.firebaseUser;

        if (sessionUser) {
            proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, sessionUser);
            return;
        }

        const user = firebase.auth().currentUser;
        if (!user) {
            firebase.auth().onAuthStateChanged(user => {
                if (user) {
                    proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                } else {
                    window.location.href = '/login';
                }
            });
        } else {
            proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
        }
    };

    // Dedicated Pitch Deck upload function
    window.uploadPitchDeckToFirebase = function(event, modelName, statusElementId, progressElementId, percentageElementId, retries = 3) {
        if (!firebaseInitialized) {
            console.warn('Firebase not initialized, retrying...');
            if (retries > 0) {
                setTimeout(() => window.uploadPitchDeckToFirebase(event, modelName, statusElementId, progressElementId, percentageElementId, retries - 1), 1000);
            } else {
                alert('Upload system not ready. Please refresh the page.');
            }
            return;
        }

        const rootElement = document.querySelector('[data-firebase-user]');
        const sessionUser = rootElement?.dataset.firebaseUser;

        if (sessionUser) {
            proceedWithPitchDeckUpload(event, modelName, statusElementId, progressElementId, percentageElementId, sessionUser);
            return;
        }

        const user = firebase.auth().currentUser;
        if (!user) {
            firebase.auth().onAuthStateChanged(user => {
                if (user) {
                    proceedWithPitchDeckUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                } else {
                    window.location.href = '/login';
                }
            });
        } else {
            proceedWithPitchDeckUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
        }
    };

    function proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, userId) {
        const file = event.target.files[0];
        if (!file) {
            console.error('No file selected');
            alert('No file selected');
            return;
        }
        if (!file.type.startsWith('image/')) {
            console.error('Invalid file type for image upload');
            alert('Please select an image file (JPEG, PNG, GIF)');
            return;
        }

        const statusElement = document.getElementById(statusElementId);
        const progressElement = document.getElementById(progressElementId);
        const progressBar = progressElement.querySelector('progress');
        const percentageElement = document.getElementById(percentageElementId);

        statusElement.innerHTML = `<svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
        progressElement.classList.remove('hidden');
        progressBar.value = 0;
        percentageElement.textContent = '0%';

        const storage = firebase.storage();
        const storageRef = storage.ref(`images/${userId}/${file.name}_${Date.now()}`);
        const uploadTask = storageRef.put(file);

        uploadTask.on('state_changed',
            snapshot => {
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                progressBar.value = progress;
                percentageElement.textContent = `${Math.round(progress)}%`;
            },
            error => {
                console.error('Upload failed:', error);
                alert('Upload failed: ' + error.message);
                statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                progressElement.classList.add('hidden');
            },
            () => {
                uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                    if (modelName.startsWith('editForm.imageUrl')) {
                        @this.call('addNewImageUrl', downloadURL);
                    } else {
                        @this.call('addImageUrl', downloadURL);
                    }
                    statusElement.innerHTML = `<svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>`;
                    progressElement.classList.add('hidden');
                }).catch(error => {
                    console.error('URL fetch failed:', error);
                    alert('Failed to get URL');
                    statusElement.innerHTML = '';
                    progressElement.classList.add('hidden');
                });
            }
        );
    }

    function proceedWithPitchDeckUpload(event, modelName, statusElementId, progressElementId, percentageElementId, userId) {
        const file = event.target.files[0];
        if (!file) {
            console.error('No file selected');
            alert('No file selected');
            return;
        }
        if (file.type !== 'application/pdf') {
            console.error('Invalid file type for pitch deck');
            alert('Please select a PDF file');
            return;
        }

        const statusElement = document.getElementById(statusElementId);
        const progressElement = document.getElementById(progressElementId);
        const progressBar = progressElement.querySelector('progress');
        const percentageElement = document.getElementById(percentageElementId);

        statusElement.innerHTML = `<svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
        progressElement.classList.remove('hidden');
        progressBar.value = 0;
        percentageElement.textContent = '0%';

        const storage = firebase.storage();
        const storageRef = storage.ref(`documents/${userId}/${file.name}_${Date.now()}`);
        const uploadTask = storageRef.put(file);

        uploadTask.on('state_changed',
            snapshot => {
                const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                progressBar.value = progress;
                percentageElement.textContent = `${Math.round(progress)}%`;
            },
            error => {
                console.error('Upload failed:', error);
                alert('Upload failed: ' + error.message);
                statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                progressElement.classList.add('hidden');
            },
            () => {
                uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                    @this.set(modelName, downloadURL);
                    statusElement.innerHTML = `<svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>`;
                    progressElement.classList.add('hidden');
                }).catch(error => {
                    console.error('URL fetch failed:', error);
                    alert('Failed to get URL');
                    statusElement.innerHTML = '';
                    progressElement.classList.add('hidden');
                });
            }
        );
    }
})();
</script>
        </x-modal>

        <x-modal wire:model="subscriptionExpiredModal">
            <div class="p-6">
                <x-header title="Renew Subscription" />
                <p>Your subscription has expired. Do you want to renew your subscription for another year?</p>
            </div>
            <x-slot:actions>
                <x-button label="Cancel" class="btn-ghost" wire:click="closeSubscriptionExpiredModal" />
                <x-button label="Renew" class="btn-secondary" wire:click="renewSubscription" spinner="renewSubscription" />
            </x-slot:actions>
        </x-modal>

        <x-modal wire:model="successModal">
            @if($successDetails)
                <div class="p-6 dark:bg-gray-800">
                    <x-header title="Payment Successful" />
                    <div class="flex justify-center my-4">
                        <x-icon name="o-check-circle" class="w-24 h-24 text-green-500" />
                    </div>
                    <p class="dark:text-gray-200">You have successfully paid ${{ number_format($successDetails['investmentAmount'], 2) }} 
                        for {{ $successDetails['marketplaceItemName'] }} 
                        at an equity stake of {{ number_format($successDetails['equity'], 4) }}%.</p>
                </div>
            @endif
            <x-slot:actions>
                <x-button class="btn-secondary" label="Close" wire:click="closeSuccessModal" />
            </x-slot:actions>
        </x-modal>

        <x-modal wire:model="editMarketplaceItemModal" max-width="2xl">
            <x-form wire:submit.prevent="updateMarketplace" class="dark:bg-gray-800">
                <x-header title="Edit Marketplace Item" subtitle="Update the details of your marketplace listing" />
                <div class="space-y-4">
                    <x-input 
                        label="Title" 
                        wire:model="editForm.title" 
                        error-field="editForm.title" 
                        placeholder="Enter the title" 
                        required 
                    />
                    <x-textarea 
                        label="Description" 
                        wire:model="editForm.description" 
                        error-field="editForm.description" 
                        placeholder="Describe your marketplace item" 
                        rows="4" 
                        required 
                    />
                    <x-input 
                        label="Amount Invested ($)" 
                        wire:model="editForm.amountInvested" 
                        error-field="editForm.amountInvested" 
                        type="number" 
                        placeholder="Total amount already invested" 
                        step="0.01" 
                    />
                    <x-input 
                        label="Company Ask ($)" 
                        wire:model="editForm.companyAsk" 
                        error-field="editForm.companyAsk" 
                        type="number" 
                        placeholder="Amount you're asking for" 
                        required 
                        step="0.01" 
                    />
                </div>
                <div class="mt-6 space-y-4">
                    <!-- Pitch Deck -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload Pitch Deck</label>
                        @if($editForm['pitchDeck'] ?? false)
                            <div class="mt-2 flex items-center">
                                <a href="{{ $editForm['pitchDeck'] }}" target="_blank" class="text-blue-600 underline">View Pitch Deck</a>
                                <button wire:click="$set('editForm.pitchDeck', '')" class="ml-4 text-red-500 hover:text-red-700" title="Remove Pitch Deck">
                                    <x-icon name="o-x-circle" class="w-5 h-5" />
                                </button>
                            </div>
                        @else
                            <input 
                                type="file" 
                                id="editPitchDeckInput" 
                                accept="application/pdf" 
                                onchange="uploadPitchDeckToFirebase(event, 'editForm.pitchDeck', 'editPitchDeckStatus', 'editPitchDeckProgress', 'editPitchDeck_percentage')"
                                class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 dark:file:bg-gray-700 dark:file:text-gray-300"
                            >
                            <input type="hidden" wire:model="editForm.pitchDeck" />
                            <div id="editPitchDeckStatus" class="mt-2"></div>
                            <div id="editPitchDeckProgress" class="mt-2 hidden">
                                <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                                <span id="editPitchDeck_percentage" class="text-sm">0%</span>
                            </div>
                            <span class="text-xs text-gray-500 dark:text-gray-400">Only PDF, recommended max 5MB</span>
                        @endif
                        @error('editForm.pitchDeck') <x-alert title="Pitch Deck Error" :description="$message" negative class="mt-2" /> @enderror
                    </div>
                    <!-- Images -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Upload Images</label>
                        <input 
                            type="file" 
                            id="editImageInput" 
                            accept="image/jpeg,image/png,image/gif" 
                            multiple
                            onchange="handleMultipleImageSelection(event, 'editImageInput', 'editImagePreviewContainer', 'editForm.imageUrl', 'editImageUploadStatus', 'editImageUploadProgress', 'editImageUpload_percentage')"
                            class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 dark:file:bg-gray-700 dark:file:text-gray-300"
                        >
                        <div id="editImageUploadStatus" class="mt-2"></div>
                        <div id="editImageUploadProgress" class="mt-2 hidden">
                            <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                            <span id="editImageUpload_percentage" class="text-sm">0%</span>
                        </div>
                        <span class="text-xs text-gray-500 dark:text-gray-400">JPEG, PNG, or GIF. Multiple images allowed.</span>
                        <div id="editImagePreviewContainer" class="mt-2 flex flex-wrap gap-2"></div>
                        <div class="mt-2 flex flex-wrap gap-2" id="editUploadedImages">
                            @foreach(($editForm['imageUrl'] ?? []) as $index => $url)
                                <div class="relative">
                                    <img src="{{ $url }}" alt="Uploaded Image" class="h-20 w-20 object-cover rounded-lg">
                                    <button wire:click="removeEditImage({{ $index }})" class="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600" title="Remove Image">
                                        <x-icon name="o-x-circle" class="w-4 h-4" />
                                    </button>
                                </div>
                            @endforeach
                        </div>
                        @error('editForm.imageUrl') <x-alert title="Image Error" :description="$message" negative class="mt-2" /> @enderror
                    </div>
                </div>
                <div class="mt-6 space-y-4">
                    <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Additional Details (Optional)</h3>
                    <x-input 
                        label="Address" 
                        wire:model="editForm.moreInfo.Address" 
                        error-field="editForm.moreInfo.Address" 
                        placeholder="Business address" 
                    />
                    <x-input 
                        label="Founder" 
                        wire:model="editForm.moreInfo.Founder" 
                        error-field="editForm.moreInfo.Founder" 
                        placeholder="Name of the founder" 
                    />
                    <x-input 
                        label="Business Type" 
                        wire:model="editForm.moreInfo.Business Type" 
                        error-field="editForm.moreInfo.Business Type" 
                        placeholder="e.g., B2C, B2B" 
                    />
                    <x-input 
                        label="Website" 
                        wire:model="editForm.moreInfo.Website" 
                        error-field="editForm.moreInfo.Website" 
                        placeholder="https://example.com" 
                        icon="o-link" 
                    />
                    <x-input 
                        label="Location" 
                        wire:model="editForm.moreInfo.Location" 
                        error-field="editForm.moreInfo.Location" 
                        placeholder="City, Country" 
                        icon="o-map-pin" 
                    />
                    <x-input 
                        label="Financial Forecast" 
                        wire:model="editForm.moreInfo.Financial Forecast" 
                        error-field="editForm.moreInfo.Financial Forecast" 
                        placeholder="Projected revenue" 
                    />
                    <x-input 
                        label="Operations and Management" 
                        wire:model="editForm.moreInfo.Operations and Management" 
                        error-field="editForm.moreInfo.Operations and Management" 
                        placeholder="Team structure" 
                    />
                    <x-input 
                        label="Marketing and Sales Strategy" 
                        wire:model="editForm.moreInfo.Marketing and Sales Strategy" 
                        error-field="editForm.moreInfo.Marketing and Sales Strategy" 
                        placeholder="Marketing plan" 
                    />
                    <x-input 
                        label="Financial Statements" 
                        wire:model="editForm.moreInfo.Financial Statements" 
                        error-field="editForm.moreInfo.Financial Statements" 
                        placeholder="Financial summary" 
                    />
                    <x-input 
                        label="Portfolio Management" 
                        wire:model="editForm.moreInfo.Portfolio Management" 
                        error-field="editForm.moreInfo.Portfolio Management" 
                        placeholder="Portfolio details" 
                    />
                    <x-input 
                        label="Research and Development" 
                        wire:model="editForm.moreInfo.Research and Development" 
                        error-field="editForm.moreInfo.Research and Development" 
                        placeholder="R&D plans" 
                    />
                    <x-input 
                        label="Risk Management" 
                        wire:model="editForm.moreInfo.Risk Management" 
                        error-field="editForm.moreInfo.Risk Management" 
                        placeholder="Risk mitigation" 
                    />
                    <x-input 
                        label="Exit Strategy" 
                        wire:model="editForm.moreInfo.Exit Strategy" 
                        error-field="editForm.moreInfo.Exit Strategy" 
                        placeholder="Exit plan" 
                    />
                    <div>
                        <div>Company Valuation(Please provide accurate data)</div>
                        <x-input 
                            label="Enter your average revenue per annum" 
                            wire:model="editForm.revenue" 
                            error-field="editForm.revenue" 
                            placeholder="Annual Revenue" 
                            type="number" 
                            step="0.01" 
                            inline
                        />
                        <x-input 
                            label="Enter your average earnings per annum" 
                            wire:model="editForm.earnings" 
                            error-field="editForm.earnings" 
                            placeholder="Enter your average earnings per annum" 
                            type="number" 
                            step="0.01" 
                            inline
                        />
                    </div>
                </div>
                <x-slot:actions>
                    <x-button label="Cancel" class="btn-ghost" wire:click="$set('editMarketplaceItemModal', false)" />
                    <x-button label="Submit" class="btn-secondary" type="submit" icon="o-check-circle" spinner="updateMarketplace" />
                </x-slot:actions>
            </x-form>
        </x-modal>
    </div>
</div>