<div>
    <x-header title="My Profile" subtitle="{{ $emailDisplay }}" separator progress-indicator />
    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            Business Verification
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <p>Business Verification Status: <strong>{{ $businessVerificationStatus }}</strong></p>
                <p>Completion: <strong>{{ number_format($completionPercentage, 2) }}%</strong></p>
                <div class="mt-5">
                    <p>You can update your Profile <x-button label="Here" wire:click="redirectToBusinessVerification" /> to access all features of the application.</p>
                </div>
            </div>
        </x-slot:content>
    </x-collapse>
    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            KYC Verification
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <!-- Content for KYC Verification -->
                @if ($kycSubmitted)
                    <p>Your KYC documents have been submitted and are under review.</p>
                @else
                    <p>0% complete</p> <br />
                    Please complete your <x-button label="KYC Verification" class="btn-default" wire:click="redirectToKYC" /> to start investing.
                @endif
            </div>
        </x-slot:content>
    </x-collapse>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            My Portfolio
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <!-- Content for My Portfolio -->
                View and manage your investment portfolio <x-button label="Here" link="/more/portfolio" />
            </div>
        </x-slot:content>
    </x-collapse>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            My Wishlist
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <!-- Content for My Wishlist -->
                View and manage your wishlist items <x-button label="Here" link="/more/wishlist" />
            </div>
        </x-slot:content>
    </x-collapse>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            Contact Us
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5" wire:click="openContactModal">
                Feel free to reach out to us for any inquiries.
                <button class="btn btn-secondary">Contact Us</button>
            </div>
        </x-slot:content>
    </x-collapse>

    <x-modal wire:model="contactModal" persistent class="backdrop-blur">
        <x-header title="Contact Us" />
        <x-form wire:submit="sendContactForm">
            <x-input label="*First Name" wire:model="contactFirstName" inline />
            <x-input label="*Last Name" wire:model="contactLastName" inline />
            <x-input label="Company Name" wire:model="contactCompanyName" inline />
            <x-input label="*Email Address" wire:model="contactEmail" inline />
            <br />
            <x-textarea label="*Message" wire:model="contactMessage" inline />

            <div class="mt-2">
                @if($remainingContactAttempts > 0)
                    <p class="text-sm text-gray-600">
                        Remaining submissions: {{ $remainingContactAttempts }}
                    </p>
                @else
                    <p class="text-sm text-red-600">
                        Maximum submissions reached. Please try again in a new session.
                    </p>
                @endif
            </div>

            @if($lastContactSentAt && $isContactButtonDisabled)
                <p class="mt-2 text-sm text-gray-600">
                    Please wait <span 
                        x-data="{ countdown: 300 }"
                        x-init="setInterval(() => { 
                            if (countdown > 0) countdown--; 
                            if (countdown === 0) $wire.set('isContactButtonDisabled', false);
                        }, 1000)"
                        x-text="Math.ceil(countdown/60)"
                    ></span> minutes before sending another message.
                </p>
            @endif

            <x-slot:actions>
                <x-button label="Back" class="btn-default" wire:click="closeContactModal" spinner />
                <x-button 
                    label="Submit" 
                    class="btn-secondary" 
                    type="submit" 
                    spinner="sendContactForm"
                    :disabled="$isContactButtonDisabled || $remainingContactAttempts <= 0"
                />
            </x-slot:actions>
        </x-form>
    </x-modal>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50">
            Change Password
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <p class="font-bold justify-center">Reset your password</p>
                <x-form wire:submit="sendResetPasswordEmail">
                    Please provide the email address you used when you signed up for your Duilt account
                    <x-input label="Email Address" wire:model="email" inline />
                    <div class="mt-2">
                        @if($remainingAttempts > 0)
                            <p class="text-sm text-gray-600">
                                Remaining attempts: {{ $remainingAttempts }}
                            </p>
                        @else
                            <p class="text-sm text-red-600">
                                Maximum attempts reached. Please try again in a new session.
                            </p>
                        @endif
                    </div>
                    <x-slot:actions>
                        <x-button 
                            label="Send email" 
                            class="btn-secondary" 
                            type="submit" 
                            icon-right="o-arrow-right" 
                            spinner="sendResetPasswordEmail"
                            :disabled="$isButtonDisabled"
                        />
                    </x-slot:actions>
                </x-form>
                @if($lastEmailSentAt && $isButtonDisabled)
                    <p class="mt-2 text-sm text-gray-600">
                        Please wait <span 
                            x-data="{ countdown: 60 }"
                            x-init="setInterval(() => { 
                                if (countdown > 0) countdown--; 
                                if (countdown === 0) $wire.set('isButtonDisabled', false);
                            }, 1000)"
                            x-text="countdown"
                        ></span> seconds before sending another email.
                    </p>
                @endif
            </div>
        </x-slot:content>
    </x-collapse>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50 ">
            About Us
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100" wire:click="openLearnMoreModal">
            <div class="mt-5">
                <!-- Content for About Us -->
                Learn more about our company and mission <x-button class="btn-secondary" label="Here"/>
            </div>
        </x-slot:content>
    </x-collapse>

    <x-modal wire:model="learnMoreModal" persistent class="backdrop-blur">
        <x-header title="About Us" />
        <div class="mt-5">
            <p class="font-bold">About Us</p>
            <p> 
                Duit Technology is a corporate venture studio based in Kenya, focused on supporting and 
                promoting tech startups in Africa. Our primary business model involves referring these 
                startups to potential investors. We believe that by empowering African tech startups and 
                scale-ups we can create a more prosperous and equitable world for all.
            </p>
            <br />
            <p class="font-bold">Our Impact</p>
            <p>
                Empowering over 50 startups with $10M+ in funding, creating 1000+ jobs, and 
                improving millions of lives across in Africa.
            </p>
            <br />
            <p class="font-bold">Our Ecosystem</p>
            <p>
                We collaborate with key partners across Africa to build a 
                thriving ecosystem for innovation
            </p>
        </div>
        <x-slot:actions>
            <x-button label="Close" class="btn-secondary" wire:click="closeLearnMoreDetails" spinner />
        </x-slot:actions>
    </x-modal>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50 ">
            Terms and Conditions
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <!-- Content for Terms and Conditions -->
                Read our terms and conditions
                <x-button wire:click="redirectToTermsAndConditions" label="Here" class="btn-secondary" />
            </div>
        </x-slot:content>
    </x-collapse>

    <x-collapse collapse-plus-minus>
        <x-slot:heading class="!bg-blue-50 ">
            Privacy Policy
        </x-slot:heading>
        <x-slot:content class="!bg-blue-100">
            <div class="mt-5">
                <!-- Content for Privacy Policy -->
                You can view our privacy policy <x-button class="btn-secondary" label="Here" wire:click="redirectToPrivacyPolicy" />
            </div>
        </x-slot:content>
    </x-collapse>
</div>

<script>
    document.addEventListener('livewire:load', function () {
        @if ($lastEmailSentAt)
            let cooldownTime = {{ $cooldownTime }};
            let timerElement = document.getElementById('cooldown-timer');
            let interval = setInterval(function () {
                cooldownTime--;
                timerElement.textContent = cooldownTime;
                if (cooldownTime <= 0) {
                    clearInterval(interval);
                }
            }, 1000);
        @endif
    });
</script>