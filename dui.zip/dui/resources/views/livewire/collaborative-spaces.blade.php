<div>
    <x-header title="Co-Working Spaces" subtitle="Discover collaborative spaces to work, connect and grow.">
        <x-slot:middle class="!justify-end">
            <div class="relative flex">
                <x-input 
                    icon="o-bolt" 
                    placeholder="Search..." 
                    wire:model.live.debounce.300ms="searchTerm" 
                />
                
                <x-loading 
                    wire:loading
                    wire:target="searchTerm"
                    class="absolute right-3 top-1/2 transform -translate-y-1/2"
                />
            </div>
        </x-slot:middle>
    </x-header>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        @forelse($collaborativeSpacesData as $data)
            <div class="flex">
                <x-card 
                    class="w-full transition-transform duration-150 hover:scale-[1.02] cursor-pointer relative" 
                    wire:click="openCollaborativeSpacesDetails('{{ $data['title'] }}')"
                    wire:loading.class="opacity-50"
                    wire:target="openCollaborativeSpacesDetails('{{ $data['title'] }}')"
                >
                    <div 
                        wire:loading
                        wire:target="openCollaborativeSpacesDetails('{{ $data['title'] }}')"
                        class="absolute inset-0 bg-white/50 flex items-center justify-center z-10"
                    >
                        <x-loading />
                    </div>

                    <x-slot:figure>
                        <img 
                            src="{{ $data['images'][0] ?? 'https://picsum.photos/500/200' }}" 
                            alt="Collaborative space item" 
                            class="w-full h-48 object-cover"
                        />
                    </x-slot:figure>
                    
                    <div class="text-justify p-4 flex-grow">
                        <p class="font-bold">{{ $data['title'] ?? 'No title' }}</p>
                        {{ Str::limit($data['description'] ?? 'No description available.', 150) }}
                    </div>
                    
                    <div class="flex justify-between items-center p-4 pt-0">
                        @if(isset($data['address']))
                            <span class="text-sm text-gray-600">
                                {{ $data['address'] }}
                            </span>
                        @endif
                    
                        <x-icon name="o-information-circle" class="w-6 h-6 text-blue-500" />
                    </div>
                </x-card>
            </div>
        @empty
            <div class="col-span-full text-center py-12">
                <p class="text-2xl text-gray-500">No collaborative spaces found.</p>
            </div>
        @endforelse
    </div>

    <x-modal wire:model="collaborativeSpacesDetailsModal">
        <div wire:loading.remove wire:target="openCollaborativeSpacesDetails" class="p-6">
            @php
                $images = $selectedSpace['images'] ?? ['https://picsum.photos/500/200'];
            @endphp

            <x-image-gallery :images="$images" class="h-40 rounded-box" />

            <h2 class="text-xl font-bold mb-4">{{ $selectedSpace['title'] ?? 'Details' }}</h2>

            <p class="mb-6">{{ $selectedSpace['description'] ?? 'No description available.' }}</p>

            <div class="mb-6">
                <p class="font-bold mb-2">Features</p>
                @if(!empty($selectedSpace['features']))
                    <ul class="list-disc pl-5 space-y-1">
                        @foreach($selectedSpace['features'] as $feature)
                            <li>{{ $feature }}</li>
                        @endforeach
                    </ul>
                @else
                    <p class="text-gray-600">No features available.</p>
                @endif
            </div>

            <div class="flex items-center mt-4">
                <x-icon name="o-map-pin" class="w-5 h-5 text-blue-500 mr-2 flex-shrink-0" />
                <p class="text-sm text-gray-600">{{ $selectedSpace['address'] ?? 'No address available.' }}</p>
            </div>
            <div class="flex items-center mt-2">
                <x-icon name="o-currency-dollar" class="w-5 h-5 text-blue-500 mr-2 flex-shrink-0" />
                <p class="text-sm text-gray-600">{{ $selectedSpace['cost'] ?? 'No cost available.' }} / month</p>
            </div>

            @php
                $userRequests = collect($collaborativeSpacesPayments ?? [])->filter(function($payment) use ($selectedSpace) {
                    return isset($payment['studioName']) && 
                           isset($selectedSpace['title']) && 
                           $payment['studioName'] === $selectedSpace['title'] &&
                           $payment['userId'] === session('firebase_user');
                });

                $existingRequest = $userRequests->sortByDesc('timestamp')->first();

                $isPending = $existingRequest ? (!isset($existingRequest['managerApproval']) || $existingRequest['managerApproval'] === false) : false;
                $isApproved = $existingRequest ? (isset($existingRequest['managerApproval']) && $existingRequest['managerApproval'] === true && !$existingRequest['complete']) : false;
            @endphp

            @if($existingRequest)
                @if($isPending)
                    <x-button 
                        label="Approval Pending" 
                        class="btn-secondary mt-4" 
                        disabled
                        icon="o-clock"
                    />
                @elseif($isApproved)
                    <x-button 
                        label="Pay Now" 
                        class="btn-secondary mt-4" 
                        wire:click="initiatePayment('{{ $selectedSpace['title'] ?? '' }}')"
                        wire:loading.attr="disabled"
                        icon="o-credit-card"
                    />
                @else
                    <!-- Allow re-booking even if complete -->
                    <x-button 
                        label="Book Now" 
                        class="btn-secondary mt-4" 
                        wire:click="bookCoworkingSpace('{{ $selectedSpace['title'] ?? '' }}', '{{ intval($selectedSpace['cost'] ?? 0) }}')"
                        wire:loading.attr="disabled"
                        icon="o-calendar-date-range"
                    />
                @endif
            @else
                <x-button 
                    label="Book Now" 
                    class="btn-secondary mt-4" 
                    wire:click="bookCoworkingSpace('{{ $selectedSpace['title'] ?? '' }}', '{{ intval($selectedSpace['cost'] ?? 0) }}')"
                    wire:loading.attr="disabled"
                    icon="o-calendar-date-range"
                />
            @endif

            <div wire:loading wire:target="initiatePayment" class="mt-4">
                <x-icon name="o-arrow-path" class="w-6 h-6 text-blue-500 animate-spin" />
                <span class="text-gray-600">Processing payment...</span>
            </div>
        </div>

        <div wire:loading wire:target="openCollaborativeSpacesDetails" class="p-6 flex items-center justify-center">
            <div class="text-center">
                <x-icon name="o-arrow-path" class="w-10 h-10 text-blue-500 animate-spin mx-auto mb-4" />
                <p class="text-gray-600">Loading details...</p>
            </div>
        </div>
    </x-modal>

    <x-modal wire:model="bookingModal" wire:submit="saveBookingDetails">
        <x-header title="Book a Co-Working Space" />

        <x-form>
            <x-input wire:model="preferredBookingName" icon="o-user" label="Enter your preferred name" inline />
            
            @php
                $config2 = ['minDate' => now()->format('Y-m-d')];
            @endphp
            <x-datepicker 
                label="Date" 
                wire:model="bookingDate" 
                icon="o-calendar" 
                :config="$config2"
            />

            <x-radio 
                label="For how long do you want to book this space?" 
                icon="o-user" 
                :options="[
                    ['id' => '30', 'name' => '30 Days'],
                    ['id' => '7', 'name' => '7 Days'],
                    ['id' => '3', 'name' => '3 Days'],
                    ['id' => '1', 'name' => '1 Day'],
                ]"
                wire:model.live="selectedDuration" 
            />

            <!-- Display Calculated Price -->
            <div class="flex items-center mt-2">
                <x-icon name="o-currency-dollar" class="w-5 h-5 text-blue-500 mr-2 flex-shrink-0" />
                <p class="text-sm text-gray-600">Total Cost: {{ number_format($calculatedPrice, 2) }} USD</p>
            </div>

            <x-input wire:model="bookingFurtherClarifications" label="Enter any further clarifications" inline />

            <x-slot:actions>
                <x-button
                    label="Cancel"
                    class="btn-secondary"
                    wire:click="closeBookingModal"
                />
                <x-button
                    label="Book Now"
                    class="btn-secondary"
                    type="submit"
                    icon="o-calendar-date-range"
                    spinner="saveBookingDetails"
                />
            </x-slot:actions>
        </x-form>
    </x-modal>

    <x-modal wire:model="approvalStatusModal">
        <x-header title="Approval Status" />

        <div class="p-6">
            <p>Your booking request is awaiting approval. Please wait for the manager to approve your request before making a payment.</p>
            <x-button 
                label="Close" 
                class="btn-secondary mt-4" 
                wire:click="closeApprovalStatusModal"
            />
        </div>
    </x-modal>

    @if($paymentStatusModal)
        <x-modal wire:model="paymentStatusModal" class="backdrop-blur" persistent>
            <div class="dark:bg-gray-800">
                <div class="mt-3 text-center">
                    @if($paymentStatus === 'success')
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                            <x-icon name="o-check-circle" class="h-6 w-6 text-green-600" />
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4 dark:text-gray-100">Payment Successful!</h3>
                    @else
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                            <x-icon name="o-x-circle" class="h-6 w-6 text-red-600" />
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4 dark:text-gray-100">Payment Not Completed</h3>
                    @endif
                    
                    <div class="mt-2 px-7 py-3">
                        <p class="text-sm text-gray-500 dark:text-gray-300">
                            {{ $paymentMessage }}
                        </p>
                    </div>
                    <div class="items-center px-4 py-3">
                        <x-button wire:click="closePaymentStatusModal" label="Close" class="btn-secondary w-full" />
                    </div>
                </div>
            </div>
        </x-modal>
    @endif
</div>