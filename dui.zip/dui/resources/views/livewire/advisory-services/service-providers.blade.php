<div>
    <x-button link="/advisory-services" icon="o-arrow-uturn-left" label="Go Back" class="btn-secondary" spinner />
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
        @forelse($serviceProvidersData as $index => $provider)
            <div class="flex">
                <x-card class="w-full">
                    <div class="p-4 flex-grow">
                        <p class="font-bold">{{ $provider['name'] ?? 'No name' }}</p>
                        <p class="text-justify">{{ $provider['description'] ?? 'No description available.' }}</p>
                    </div>
                    <div class="p-4">
                        <p>Price: ${{ number_format($provider['price'] ?? 0, 2) }}</p>
                        <p>Contact: {{ $provider['contact'] ?? 'No contact available.' }}</p>
                        <p>Experience: {{ $provider['experienceYears'] ?? 'No experience information available.' }}</p>
                        <div class="flex">
                            <x-icon name="o-map-pin" class="w-5 h-5 text-blue-500 mr-2" />
                            <p>{{ $provider['location'] ?? 'Location not available.' }}</p>
                        </div>
                        <div class="flex mt-2">
                            <x-icon name="o-star" class="w-5 h-5 text-blue-500 mr-2" />
                            <p>{{ $provider['rating'] ?? 'Rating not available.' }}</p>
                        </div>
                    </div>
                    <x-slot:actions>
                        <div class="flex justify-between items-center p-4 pt-0">
                            <x-button 
                                label="{{ $provider['existingBooking'] ? 'Pay Now' : 'Request Service' }}" 
                                class="btn-secondary" 
                                wire:click="requestService({{ $index }})"
                                spinner
                            />
                        </div>
                    </x-slot:actions>
                </x-card>
            </div>
        @empty
            <div class="col-span-full text-center py-12">
                <p class="text-2xl text-gray-500">No service providers found.</p>
            </div>
        @endforelse
    </div>

    <x-modal wire:model="appointmentModal" class="backdrop-blur" persistent>
        <x-header title="Book Appointment" />
        <x-form wire:submit.prevent="bookAppointment">
            <x-input label="Enter preferred name" wire:model="bookingName" icon="o-user" />
            <x-input label="Enter any additional information" wire:model="bookingAdditionalInfo" icon="o-information-circle" />

            @php
                $config3 = ['minDate' => now()->format('Y-m-d')];
            @endphp
            <x-datepicker
                label="Select a Date" 
                hint="Pick a Date" 
                wire:model="appointmentDate" 
                icon="o-calendar" 
                :config="$config3"
            />

            <div class="mt-4">
            <p class="font-bold mb-2">Select a Time</p>
                <div class="grid grid-cols-3 gap-2">
                    @foreach(['09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'] as $time)
                        <x-button 
                            label="{{ $time }}" 
                            class="{{ $appointmentTime === $time ? 'btn-secondary' : 'btn-default' }}" 
                            wire:click="$set('appointmentTime', '{{ $time }}')"
                        />
                    @endforeach
                </div>
            </div>

            <x-slot:actions>
                <x-button label="Close" class="btn-ghost" wire:click="closeAppointmentModal" /> 
                <x-button label="Confirm Booking" class="btn-secondary" type="submit" spinner="bookAppointment" />
            </x-slot:actions>
        </x-form>
    </x-modal>

    @if($paymentStatusModal)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full" id="payment-status-modal">
            <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <div class="mt-3 text-center">
                    @if($paymentStatus === 'success')
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                            <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4">Payment Successful!</h3>
                    @else
                        <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                            <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg leading-6 font-medium text-gray-900 mt-4">Payment Not Completed</h3>
                    @endif
                    
                    <div class="mt-2 px-7 py-3">
                        <p class="text-sm text-gray-500">
                            {{ $paymentMessage }}
                        </p>
                    </div>
                    <div class="items-center px-4 py-3">
                        <button wire:click="closePaymentStatusModal"
                                class="px-4 py-2 bg-blue-500 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>