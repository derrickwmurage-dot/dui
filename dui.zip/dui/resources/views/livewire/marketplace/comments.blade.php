<div class="container mx-auto p-4">
    <x-button link="/marketplace" class="bg-primary" icon="o-arrow-uturn-left" label="Back to Marketplace" responsive />
    @if($marketplaceData)
    <div class="flex flex-col items-center justify-center">
        <x-header title="{{ $marketplaceData['title'] }}" />
        <div class="flex space-x-2">
            <x-icon name="o-star" />
            <p class="text-gray-700 mb-4">{{ number_format($averageRating, 2) }}</p>
        </div>
        <div class="text-center flex space-x-4">
            <!-- Interest Button with Count -->
            <button 
                wire:click="toggleInterest('interest')"
                class="flex items-center space-x-1 {{ in_array($userId, $marketplaceData['showedInterestUsers'] ?? []) ? 'text-green-500' : 'text-gray-700 hover:text-green-500' }} transition-colors"
            >
                <x-icon name="o-hand-thumb-up" class="w-5 h-5" />
                <span>Likes: {{ count($marketplaceData['showedInterestUsers'] ?? []) }}</span>
            </button>
            <!-- Disinterest Button with Count -->
            <button 
                wire:click="toggleInterest('disinterest')"
                class="flex items-center space-x-1 {{ in_array($userId, $marketplaceData['showedDisinterestUsers'] ?? []) ? 'text-red-500' : 'text-gray-700 hover:text-red-500' }} transition-colors"
            >
                <x-icon name="o-hand-thumb-down" class="w-5 h-5" />
                <span>Dislikes: {{ count($marketplaceData['showedDisinterestUsers'] ?? []) }}</span>
            </button>
        </div>
    </div>
        
    <x-button class="btn-primary mb-2" wire:click="openReviewModal" label="Add Review" icon="o-plus" responsive spinner="openReviewModal" />

    <div class="bg-white shadow-md rounded-lg p-4 mb-4">
        <h3 class="text-lg font-bold mb-2">Comments</h3>
        @if(isset($marketplaceData['reviews']) && count($marketplaceData['reviews']) > 0)
            @foreach($marketplaceData['reviews'] as $review)
                <div class="mb-4 p-4 border rounded-lg relative">
                    <p class="text-gray-600 text-sm font-bold mb-2">{{ $review['reviewer'] }}</p>
                    <div class="flex items-center mb-2">
                        @for ($i = 0; $i < $review['rating']; $i++)
                            <x-icon name="o-star" class="bg-warning" />
                        @endfor
                    </div>
                    <p class="text-gray-600 text-sm">{{ $review['reviewText'] }}</p>
                    <p class="text-gray-600 text-sm font-thin absolute top-0 right-0 mt-2 mr-2">{{ $review['date'] }}</p>
                </div>
            @endforeach
        @else
            <p>No comments available.</p>
        @endif
    </div>
    @else
        <p>No data found.</p>
    @endif

    <x-modal wire:model="reviewModal">
        <x-form wire:submit.prevent="addReview">
            <x-input label="Reviewer Name" wire:model="reviewerName" inline />
            <x-input label="Review" wire:model="reviewText" inline />
            <x-rating wire:model="reviewRating" class="bg-warning"/>

            <x-slot:actions>
                <x-button class="btn-primary" type="submit" label="Add Review" responsive spinner="addReview" />
            </x-slot:actions>
        </x-form>
    </x-modal>
</div>