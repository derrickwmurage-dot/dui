<div>
    <x-header title="Investors for {{ $marketplaceData['title'] }}" />
    <x-button wire:click="backToMarketplace" label="Go Back" icon="o-arrow-uturn-left" class="btn-secondary" />
    <div class="container mx-auto p-4">
        @if(empty($marketplaceData['investors']))
            <div class="flex flex-col items-center justify-center h-64">
                <x-icon name="o-x-circle" class="w-24 h-24 text-gray-500" />
                <p class="text-gray-600 dark:text-gray-400 mt-4">There are no investors currently.</p>
            </div>
        @else
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($marketplaceData['investors'] as $investor)
                    <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
                        <h5 class="text-xl font-bold mb-3 text-gray-800 dark:text-gray-100">{{ $investor['investorName'] }}</h5>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Investment Amount:</strong> ${{ $investor['investmentAmount'] }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Equity:</strong> {{ number_format($investor['equity'], 2) }}%</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Country:</strong> {{ $investor['country'] }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Date:</strong> {{ $investor['date'] }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Age:</strong> {{ $investor['age'] }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Company Name:</strong> {{ $investor['companyName'] }}</p>
                        <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Extra Offerings:</strong> {{ $investor['extraOfferings'] }}</p>
                        @if($investor['investmentComplete'])
                            <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Status:</strong> Investment Complete</p>
                        @else
                            @if(!$investor['approved'])
                                <x-button wire:click="approveInvestment('{{ $investor['investorId'] }}')" label="Approve Investment" class="btn-secondary" responsive spinner="approveInvestment" />
                                <x-button wire:click="rejectInvestment('{{ $investor['investorId'] }}')" label="Reject Investment" class="btn-error" responsive spinner="rejectInvestment" />
                            @else
                                <p class="text-gray-600 dark:text-gray-400 mb-4"><strong>Status:</strong> Investment Approved</p>
                            @endif
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </div>
</div>