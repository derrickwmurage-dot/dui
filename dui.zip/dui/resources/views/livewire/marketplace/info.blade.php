<div>
    <x-header title="More Info" />
    <x-button link="/marketplace" class="bg-secondary" icon="o-arrow-uturn-left" label="Back to Marketplace" />
    <div class="container mx-auto p-4">
        @if($moreInfo)
            <div class="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
                <h3 class="text-lg font-bold mb-4 text-gray-900 dark:text-white">More Information</h3>
                <ul class="list-disc list-inside">
                    @foreach($moreInfo as $key => $value)
                        <li class="mb-2 text-gray-800 dark:text-gray-200">
                            <strong class="text-gray-900 dark:text-white">{{ ucwords(str_replace('_', ' ', $key)) }}:</strong> {{ $value }}
                        </li>
                    @endforeach
                </ul>
            </div>
        @else
            <div class="flex flex-col items-center justify-center h-64">
                <x-icon name="o-exclamation-circle" class="w-16 h-16 text-gray-400 dark:text-gray-500" />
                <p class="text-gray-600 dark:text-gray-300 mt-4">No additional information available.</p>
            </div>
        @endif
    </div>
</div>