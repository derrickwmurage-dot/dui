<div
    x-data
    data-firebase-user="{{ session('firebase_user') }}"
    data-firebase-token="{{ session('firebase_token') }}"
>
    @assets
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-storage-compat.js"></script>
    @endassets

    <x-header title="Investor Application Form" with-anchor separator progress-indicator />
    
    <x-form wire:submit="submitDetails">
        <p>Name *</p>
        <div class="flex gap-4">
            <x-input label="First Name" wire:model="firstName" inline required />
            <x-input label="Second Name" wire:model="secondName" inline required />
        </div>
        <x-input 
            label="Age" 
            wire:model="age"
            placeholder="Please provide your age"
            type="number"
            min="18"
            max="120"
            required
        />
        <div>
            <x-select 
                label="In which country are you situated?" 
                icon="o-globe-europe-africa" 
                :options="$countryPhoneCodes" 
                wire:model.live="country" 
                required
            />
        </div>
        <x-input 
            label="Email"
            wire:model="email"
            placeholder="Email Address"
            type="email"
            required
        />
        <x-input 
            label="Phone Number"  
            wire:model="phone"
            placeholder="20913113123"
            type="number"
            max="999999999999999"
            min="10000000"
            required
            prefix="{{ $country }}"
        />
        <x-input
            label="Company Name (Optional)"
            wire:model="company"
            placeholder="Please provide company name"
        />
        <x-select
            label="Which Industry best applies to your venture? (Optional)"
            wire:model="industry"
            placeholder="Select one"
            :options="[
                ['id' => 'Agri-Tech', 'name' => 'Agri-Tech'],
                ['id' => 'AI/ML', 'name' => 'AI/ML'],
                ['id' => 'Augmented Reality/Virtual Reality', 'name' => 'Augmented Reality/Virtual Reality'],
                ['id' => 'Blockchain', 'name' => 'Blockchain'],
                ['id' => 'Community', 'name' => 'Community'],
                ['id' => 'Crypto', 'name' => 'Crypto'],
                ['id' => 'Developer Tools', 'name' => 'Developer Tools'],
                ['id' => 'Biotech', 'name' => 'Biotech'],
                ['id' => 'DeepTech', 'name' => 'DeepTech'],
                ['id' => 'Direct-To-Consumer-Brands', 'name' => 'Direct-To-Consumer-Brands'],
                ['id' => 'E-commerce', 'name' => 'E-commerce'],
                ['id' => 'Education', 'name' => 'Education'],
                ['id' => 'Energy', 'name' => 'Energy'],
                ['id' => 'Enterprise Tech', 'name' => 'Enterprise Tech'],
                ['id' => 'FinTech/Financial Services', 'name' => 'FinTech/Financial Services'],
                ['id' => 'Gaming/Entertainment', 'name' => 'Gaming/Entertainment'],
                ['id' => 'Government', 'name' => 'Government'],
                ['id' => 'Hardware', 'name' => 'Hardware'],
                ['id' => 'Health/MedTech/Healthcare', 'name' => 'Health/MedTech/Healthcare'],
                ['id' => 'Life Science', 'name' => 'Life Science'],
                ['id' => 'Marketplace', 'name' => 'Marketplace'],
                ['id' => 'Media/Social Media', 'name' => 'Media/Social Media'],
                ['id' => 'Mobility/Transportation', 'name' => 'Mobility/Transportation'],
                ['id' => 'Other', 'name' => 'Other'],
                ['id' => 'Robotics', 'name' => 'Robotics'],
                ['id' => 'Saas', 'name' => 'Saas'],
                ['id' => 'Security', 'name' => 'Security'],
                ['id' => 'SpaceTech', 'name' => 'SpaceTech'],
            ]"
        />
        <x-choices
            label="Which industry are you willing to invest? "
            wire:model="industryToInvest"
            placeholder="Select here"
            :options="[
                ['id' => 'Agri-Tech', 'name' => 'Agri-Tech'],
                ['id' => 'AI/ML', 'name' => 'AI/ML'],
                ['id' => 'Augmented Reality/Virtual Reality', 'name' => 'Augmented Reality/Virtual Reality'],
                ['id' => 'Blockchain', 'name' => 'Blockchain'],
                ['id' => 'Community', 'name' => 'Community'],
                ['id' => 'Crypto', 'name' => 'Crypto'],
                ['id' => 'Developer Tools', 'name' => 'Developer Tools'],
                ['id' => 'Biotech', 'name' => 'Biotech'],
                ['id' => 'DeepTech', 'name' => 'DeepTech'],
                ['id' => 'Direct-To-Consumer-Brands', 'name' => 'Direct-To-Consumer-Brands'],
                ['id' => 'E-commerce', 'name' => 'E-commerce'],
                ['id' => 'Education', 'name' => 'Education'],
                ['id' => 'Energy', 'name' => 'Energy'],
                ['id' => 'Enterprise Tech', 'name' => 'Enterprise Tech'],
                ['id' => 'FinTech/Financial Services', 'name' => 'FinTech/Financial Services'],
                ['id' => 'Gaming/Entertainment', 'name' => 'Gaming/Entertainment'],
                ['id' => 'Government', 'name' => 'Government'],
                ['id' => 'Hardware', 'name' => 'Hardware'],
                ['id' => 'Health/MedTech/Healthcare', 'name' => 'Health/MedTech/Healthcare'],
                ['id' => 'Life Science', 'name' => 'Life Science'],
                ['id' => 'Marketplace', 'name' => 'Marketplace'],
                ['id' => 'Media/Social Media', 'name' => 'Media/Social Media'],
                ['id' => 'Mobility/Transportation', 'name' => 'Mobility/Transportation'],
                ['id' => 'Other', 'name' => 'Other'],
                ['id' => 'Robotics', 'name' => 'Robotics'],
                ['id' => 'Saas', 'name' => 'Saas'],
                ['id' => 'Security', 'name' => 'Security'],
                ['id' => 'SpaceTech', 'name' => 'SpaceTech'],
            ]"
            option-label="name"
            option-value="id"
            multiple
            allow-all
            required
        />
        <x-select
            label="Field of Work "
            wire:model="field"
            placeholder="Select one"
            :options="[
                ['id' => 'Entrepreneur', 'name' => 'Entrepreneur'],
                ['id' => 'Investor', 'name' => 'Investor'],
                ['id' => 'Entrepreneurial Support Organization', 'name' => 'Entrepreneurial Support Organization'],
                ['id' => 'Development Professional', 'name' => 'Development Professional'],
                ['id' => 'Government', 'name' => 'Government'],
                ['id' => 'Potential Investor', 'name' => 'Potential Investor'],
                ['id' => 'None of the above', 'name' => 'None of the above'],
            ]"
            required
        />

        <!-- Modified Radio Component: "Work Title" -->
        <div>
            <label class="label">
                <span class="label-text">Work Title <span class="text-red-500">*</span></span>
            </label>
            <div class="flex flex-col gap-2">
                @foreach([
                    ['id' => 'Founder', 'name' => 'Founder'],
                    ['id' => 'CEO', 'name' => 'CEO'],
                    ['id' => 'Director', 'name' => 'Director'],
                    ['id' => 'Entrepreneur', 'name' => 'Entrepreneur'],
                ] as $option)
                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-2">
                            <input 
                                type="radio" 
                                wire:model="workTitle" 
                                value="{{ $option['id'] }}" 
                                class="radio radio-primary" 
                                required 
                            />
                            <span class="label-text">{{ $option['name'] }}</span>
                        </label>
                    </div>
                @endforeach
            </div>
        </div>

        <x-input
            label="Website URL (Optional)"
            wire:model="website"
            placeholder="Please provide your website URL"
            icon="o-link"
        />
        <x-choices 
            label="Which level of funding investment are you willing to invest? " 
            wire:model="level"
            placeholder="Select here"
            :options="[
                ['id' => 'Pre Seed', 'name' => 'Pre Seed'],
                ['id' => 'Seed', 'name' => 'Seed'],
                ['id' => 'Series A', 'name' => 'Series A'],
                ['id' => 'Series B', 'name' => 'Series B'],
                ['id' => 'Series C', 'name' => 'Series C'],
                ['id' => 'IPO', 'name' => 'IPO'],
            ]"
            option-label="name"
            option-value="id"
            multiple
            allow-all
            required
        />
        <x-choices
            label="Amount willing to Invest In Dollars "
            wire:model="amount"
            placeholder="Select here"
            :options="[
                ['id' => 'Less than $1,000', 'name' => 'Less than $1,000'],
                ['id' => '$1,000 - $5,000', 'name' => '$1,000 - $5,000'],
                ['id' => '$5,000 - $10,000', 'name' => '$5,000 - $10,000'],
                ['id' => '$10,000 - $50,000', 'name' => '$10,000 - $50,000'],
                ['id' => '$50,000 - $100,000', 'name' => '$50,000 - $100,000'],
                ['id' => '$100,000 - $500,000', 'name' => '$100,000 - $500,000'],
                ['id' => '$500,000 - $1,000,000', 'name' => '$500,000 - $1,000,000'],
                ['id' => 'More than $1,000,000', 'name' => 'More than $1,000,000'],
            ]"
            option-label="name"
            option-value="id"
            multiple
            allow-all
            required
        />

        <!-- Modified Radio Component: "How did you hear about us?" -->
        <div>
            <label class="label">
                <span class="label-text">How did you hear about us? <span class="text-red-500">*</span></span>
            </label>
            <div class="flex flex-col gap-2">
                @foreach([
                    ['id' => 'Social Media (LinkedIn, Twitter, Instagram)', 'name' => 'Social Media (LinkedIn, Twitter, Instagram)'],
                    ['id' => 'Investor Referral', 'name' => 'Investor Referral'],
                    ['id' => 'Incubator/Accelerator/Hub Referral', 'name' => 'Incubator/Accelerator/Hub Referral'],
                    ['id' => 'Google Search', 'name' => 'Google Search'],
                    ['id' => 'Event', 'name' => 'Event'],
                    ['id' => 'Other', 'name' => 'Other'],
                ] as $option)
                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-2">
                            <input 
                                type="radio" 
                                wire:model="referral" 
                                value="{{ $option['id'] }}" 
                                class="radio radio-primary" 
                                required 
                            />
                            <span class="label-text">{{ $option['name'] }}</span>
                        </label>
                    </div>
                @endforeach
            </div>
        </div>
{{--
        <div>
            <label for="sourceOfFunds">Upload Source of Funds</label>
            <input type="file" id="sourceOfFunds" onchange="uploadToFirebase(event, 'sourceOfFunds')" />
            <input type="hidden" wire:model="sourceOfFunds_url" />
            <span id="sourceOfFunds_status"></span>
        </div>
--}}
        <div class="mb-4">
            <label for="sourceOfFunds" class="label">
                <span class="label-text">Upload Source of funds <span class="text-red-500">*</span></span>
            </label>
            <input 
                type="file" 
                id="sourceOfFunds" 
                accept="application/pdf" 
                onchange="uploadToFirebase(event, 'sourceOfFunds_url', 'sourceOfFundsStatus', 'sourceOfFundsProgress', 'sourceOfFunds_percentage')" 
            />
            <input type="hidden" wire:model="sourceOfFunds_url" />
            <div id="sourceOfFundsStatus" class="mt-2"></div>
            <div id="sourceOfFundsProgress" class="mt-2 hidden">
                <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                <span id="sourceOfFunds_percentage" class="text-sm">0%</span>
            </div>
        </div>
{{--
        <div>
            <label for="proofOfResidence">Upload Proof of Residence</label>
            <input type="file" id="proofOfResidence" onchange="uploadToFirebase(event, 'proofOfResidence')" />
            <input type="hidden" wire:model="proofOfResidence_url" />
            <span id="proofOfResidence_status"></span>
        </div>
--}}
        <div class="mb-4">
            <label for="proofOfResidence" class="label">
                <span class="label-text">Upload Proof of Residence <span class="text-red-500">*</span></span>
            </label>
            <input 
                type="file" 
                id="proofOfResidence" 
                accept="application/pdf" 
                onchange="uploadToFirebase(event, 'proofOfResidence_url', 'proofOfResidenceStatus', 'proofOfResidenceProgress', 'proofOfResidence_percentage')" 
            />
            <input type="hidden" wire:model="proofOfResidence_url" />
            <div id="proofOfResidenceStatus" class="mt-2"></div>
            <div id="proofOfResidenceProgress" class="mt-2 hidden">
                <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                <span id="proofOfResidence_percentage" class="text-sm">0%</span>
            </div>
        </div>
        
        <script>
            (function() {
                let firebaseInitialized = false;
                const config = {
                    apiKey: "{{ env('FIREBASE_API_KEY') }}",
                    authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
                    projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
                    storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
                    messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
                    appId: "{{ env('FIREBASE_APP_ID') }}"
                };

                function initializeFirebase() {
                    if (firebaseInitialized) return;
                    
                    if (typeof firebase === 'undefined') {
                        console.error('Firebase SDK not loaded');
                        setTimeout(initializeFirebase, 1000);
                        return;
                    }

                    try {
                        if (!firebase.apps.length) {
                            firebase.initializeApp(config);
                        }
                        firebaseInitialized = true;
                        // console.log('Firebase initialized successfully');
                        
                        // Get user from data attribute
                        const rootElement = document.querySelector('[data-firebase-user]');
                        const sessionUser = rootElement?.dataset.firebaseUser;
                        const sessionToken = rootElement?.dataset.firebaseToken;

                        if (sessionUser) {
                            // console.log('User authenticated via session');
                            return;
                        }

                        // Only check Firebase auth if no session user
                        firebase.auth().onAuthStateChanged(user => {
                            if (!user && !sessionUser) {
                                // console.log('No user found in session or Firebase, redirecting to login...');
                                // console.log(sessionUser);
                                // window.location.href = '/login';
                            } else {
                                // console.log('User authenticated:', user?.uid || sessionUser);
                            }
                        });
                    } catch (error) {
                        console.error('Firebase initialization error:', error);
                        setTimeout(initializeFirebase, 1000);
                    }
                }

                // Initialize Firebase when DOM is loaded
                document.addEventListener('DOMContentLoaded', initializeFirebase);

                // Initialize Firebase immediately as well
                initializeFirebase();

                window.uploadToFirebase = function(event, modelName, statusElementId, progressElementId, percentageElementId, retries = 3) {
                    if (!firebaseInitialized) {
                        console.warn('Firebase not initialized, retrying...');
                        if (retries > 0) {
                            setTimeout(() => window.uploadToFirebase(event, modelName, statusElementId, progressElementId, percentageElementId, retries - 1), 1000);
                        } else {
                            alert('Upload system not ready. Please refresh the page.');
                        }
                        return;
                    }

                    // Get user from data attribute
                    const rootElement = document.querySelector('[data-firebase-user]');
                    const sessionUser = rootElement?.dataset.firebaseUser;

                    if (sessionUser) {
                        // console.log('Using session user for upload:');
                        proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, sessionUser);
                        return;
                    }

                    // Fallback to Firebase auth
                    const user = firebase.auth().currentUser;
                    if (!user) {
                        // console.log('No user found, checking auth state...');
                        firebase.auth().onAuthStateChanged(user => {
                            if (user) {
                                // console.log('User authenticated via Firebase, proceeding with upload...');
                                proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                            } else {
                                // console.log('No user found, redirecting to login...');
                                window.location.href = '/login';
                            }
                        });
                    } else {
                        proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, user.uid);
                    }
                };

                function proceedWithUpload(event, modelName, statusElementId, progressElementId, percentageElementId, userId) {
                    const file = event.target.files[0];
                    if (!file) {
                        console.error('No file');
                        alert('No file selected');
                        return;
                    }
                    if (file.type !== 'application/pdf') {
                        console.error('Invalid type:', file.type);
                        alert('Only PDFs allowed');
                        return;
                    }

                    const statusElement = document.getElementById(statusElementId);
                    const progressElement = document.getElementById(progressElementId);
                    const progressBar = progressElement.querySelector('progress');
                    const percentageElement = document.getElementById(percentageElementId);

                    statusElement.innerHTML = `<svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
                    progressElement.classList.remove('hidden');
                    progressBar.value = 0;
                    percentageElement.textContent = '0%';

                    const storage = firebase.storage();
                    const storageRef = storage.ref(`document/${file.name}_${Date.now()}`);
                    
                    const uploadTask = storageRef.put(file);
                    
                    uploadTask.on('state_changed',
                        snapshot => {
                            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                            progressBar.value = progress;
                            percentageElement.textContent = `${Math.round(progress)}%`;
                        },
                        error => {
                            console.error('Upload failed:', error);
                            alert('Upload failed: ' + error.message);
                            statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                            progressElement.classList.add('hidden');
                        },
                        () => {
                            uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                                @this.set(modelName, downloadURL);
                                Livewire.dispatch('set', { model: modelName, value: downloadURL });
                                statusElement.innerHTML = `<svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>`;
                                progressElement.classList.add('hidden');
                            }).catch(error => {
                                console.error('URL fetch failed:', error);
                                alert('Failed to get URL');
                                statusElement.innerHTML = '';
                                progressElement.classList.add('hidden');
                            });
                        }
                    );
                }
            })();
        </script>

        <x-textarea 
            label="Please Tell Us More Details About How You Heard About Us" 
            wire:model="details" 
            placeholder="If referral, please include name/organization of referee. If event, please include event name"
        />

        <x-slot:actions>
           <x-button 
                label="Submit" 
                class="btn-secondary" 
                type="submit" 
                spinner="submitDetails"
                icon="o-check-circle"
            >
            </x-button>
            <x-button
                label="Renew Subscription"
                class="btn-secondary"
                wire:click="openRenewSubscriptionModal"
                spinner="openRenewSubscriptionModal"
                responsive
                icon="o-arrow-path"
            />
        </x-slot:actions>
    </x-form>

    <x-modal wire:model="subscriptionExpiredModal">
        <div class="p-6">
            <x-header title="Subscription Expired" />
            <p class="text-gray-600 dark:text-gray-400">Your subscription has expired. Please renew your subscription to continue.</p>
        </div>
        <x-slot:actions>
            <x-button wire:click="closeSubscriptionExpiredModal" label="Close" class="btn-ghost" />
            @if($renewSubscriptionButton)
                <x-button
                    label="Renew Subscription" 
                    class="btn-secondary" 
                    wire:click="renewSubscription"
                    spinner="renewSubscription"
                    responsive
                    icon="o-arrow-path"
                />
            @endif
        </x-slot:actions>
    </x-modal>
</div>