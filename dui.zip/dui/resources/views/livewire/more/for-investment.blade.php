<div
    x-data
    data-firebase-user="{{ session('firebase_user') }}"
    data-firebase-token="{{ session('firebase_token') }}"
>
    @assets
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
        <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-storage-compat.js"></script>
    @endassets

    <x-header title="Investee Application Form" with-anchor separator progress-indicator />
    <x-form wire:submit="submitForm">
        <div class="mb-4">
            <label class="label">
                <span class="label-text">Name <span class="text-red-500">*</span></span>
            </label>
            <div class="flex gap-4">
                <x-input 
                    label="First Name" 
                    wire:model="firstName"
                    inline
                    required
                />
                <x-input 
                    label="Second Name" 
                    wire:model="secondName"
                    inline
                    required
                />
            </div>
        </div>
        <x-input 
            label="Email Address" 
            wire:model="email"
            type="email"
            required
        />
        <div>
            <x-select 
                label="What is your nationality?" 
                icon="o-globe-europe-africa" 
                :options="$countryOptions" 
                wire:model.live="selectedCountry"
                option-label="name"
                option-value="id"
                required
            />
        </div>
        <x-input 
            label="Phone Number"  
            wire:model="phone"
            placeholder="+254701...."
            type="text"
            :disabled="$phoneDisabled"
            required
            prefix="{{ $selectedCountry }}"
        />
        <x-input
            label="What is the name of your venture?" 
            wire:model="ventureName"
            placeholder="Name"
            required
        />
        <x-input
            label="What is your venture's website URL? (Optional)"
            wire:model="website"
            placeholder="Please provide your website URL"
            icon="o-link"
        />
        <x-select
            label="Which category best applies to your venture?" 
            wire:model="industry"
            required
            :options="[
                ['id' => 'Agri-Tech', 'name' => 'Agri-Tech'],
                ['id' => 'AI/ML', 'name' => 'AI/ML'],
                ['id' => 'Augmented Reality/Virtual Reality', 'name' => 'Augmented Reality/Virtual Reality'],
                ['id' => 'Blockchain', 'name' => 'Blockchain'],
                ['id' => 'Community', 'name' => 'Community'],
                ['id' => 'Crypto', 'name' => 'Crypto'],
                ['id' => 'Developer Tools', 'name' => 'Developer Tools'],
                ['id' => 'Biotech', 'name' => 'Biotech'],
                ['id' => 'DeepTech', 'name' => 'DeepTech'],
                ['id' => 'Direct-To-Consumer-Brands', 'name' => 'Direct-To-Consumer-Brands'],
                ['id' => 'E-commerce', 'name' => 'E-commerce'],
                ['id' => 'Education', 'name' => 'Education'],
                ['id' => 'Energy', 'name' => 'Energy'],
                ['id' => 'Enterprise Tech', 'name' => 'Enterprise Tech'],
                ['id' => 'FinTech/Financial Services', 'name' => 'FinTech/Financial Services'],
                ['id' => 'Gaming/Entertainment', 'name' => 'Gaming/Entertainment'],
                ['id' => 'Government', 'name' => 'Government'],
                ['id' => 'Hardware', 'name' => 'Hardware'],
                ['id' => 'Health/MedTech/Healthcare', 'name' => 'Health/MedTech/Healthcare'],
                ['id' => 'Life Science', 'name' => 'Life Science'],
                ['id' => 'Marketplace', 'name' => 'Marketplace'],
                ['id' => 'Media/Social Media', 'name' => 'Media/Social Media'],
                ['id' => 'Mobility/Transportation', 'name' => 'Mobility/Transportation'],
                ['id' => 'Other', 'name' => 'Other'],
                ['id' => 'Robotics', 'name' => 'Robotics'],
                ['id' => 'Saas', 'name' => 'Saas'],
                ['id' => 'Security', 'name' => 'Security'],
                ['id' => 'SpaceTech', 'name' => 'SpaceTech']
            ]"
        />
        <x-select
            label="What is your business model?" 
            wire:model="businessModel"
            placeholder="Select an option"
            :options="[
                ['id' => 'B2C', 'name' => 'B2C'],
                ['id' => 'B2B2C', 'name' => 'B2B2C'],
                ['id' => 'B2B', 'name' => 'B2B'],
                ['id' => 'GoVTech/B2G', 'name' => 'GoVTech/B2G']

            ]"
            required
        />
        <div>
            <x-select
                label="What is your level of funding?" 
                wire:model="level"
                placeholder="Select an option"
                :options="[
                    ['id' => 'preSeed', 'name' => 'Pre Seed'],
                    ['id' => 'seed', 'name' => 'Seed'],
                    ['id' => 'seriesA', 'name' => 'Series A'],
                    ['id' => 'seriesB', 'name' => 'Series B'],
                    ['id' => 'seriesC', 'name' => 'Series C'],
                    ['id' => 'ipo', 'name' => 'IPO']
                ]"
                required
            />
        </div>
        <x-textarea
            label="What does your venture do?" 
            wire:model="companySolution"
            placeholder="Please briefly describe your company/solution"
            required
        />
        <x-select
            label="Is your venture African-led?" 
            wire:model="africanLed"
            :options="[
                ['id' => 'Yes', 'name' => 'Yes'],
                ['id' => 'No', 'name' => 'No']
            ]"
            placeholder="Select an option"
            required
        />
        <x-input
            label="What percentage of your venture is owned by African National(s)?" 
            wire:model="africanPercentage"
            placeholder="Enter a value between 0 - 100"
            type="number"
            min="0"
            max="100"
            required
        />
        <x-select
            label="Does your venture have a female founder, co-founder or C-level executive?" 
            wire:model="femaleFounder"
            :options="[
                ['id' => 'YesFemaleCEO', 'name' => 'Yes - Female CEO'],
                ['id' => 'YesFemaleCoFounder', 'name' => 'Yes - female Co-Founder'],
                ['id' => 'No', 'name' => 'No']
            ]"
            placeholder="Select an option"
            required
        />
        <x-input
            label="What percentage of your venture is owned by women?" 
            wire:model="femalePercentage"
            type="number"
            min="0"
            max="100"
            placeholder="Enter a value between 0 - 100"
            required
        />
        <div>
            <x-select 
                label="In which country is your venture headquartered?" 
                icon="o-globe-europe-africa" 
                :options="$countrynames" 
                wire:model="countryHeadquarters" 
                option-label="name"
                option-value="name"
                required
            />
        </div>
        <x-select
            label="Does your venture have operations in any of the following cities - Lagos, Nairobi, Cape Town or Cairo?" 
            wire:model="city"
            :options="[
                ['id' => 'Yes', 'name' => 'Yes'],
                ['id' => 'No', 'name' => 'No']
            ]"
            placeholder="Select an option"
            required
        />
        @php
            $config1 = ['maxDate' => now()->format('Y-m-d')];
        @endphp
        <x-datepicker
            label="When did you start building this company?"
            wire:model="date"
            placeholder="Select date"
            :config="$config1"
            required
        />
        <x-select
            label="Where is your venture in its lifecycle?" 
            wire:model="lifecycle"
            placeholder="Select one"
            :options="[
                ['id' => 'idea', 'name' => 'Idea'],
                ['id' => 'preproduction', 'name' => 'Pre-production (Business Incorporated)'],
                ['id' => 'mvpBuildingInProgress', 'name' => 'MVP Building in progress'],
                ['id' => 'mvpCompleteNoCustomers', 'name' => 'MVP Complete, No Customers'],
                ['id' => 'mvpCompleteWithCustomers', 'name' => 'MVP Complete, Customers on Waitlist'],
                ['id' => 'pilotInProgress', 'name' => 'Pilot in Progress (Closed Beta)'],
                ['id' => 'productLaunchedAndLive', 'name' => 'Project Launched (Live Users, Pre - Revenue)'],
                ['id' => 'productLaunchedPayingCustomers', 'name' => 'Product Launched (Paying Customers)']
            ]"
            required
        />
        <x-input
            label="How does/will your venture make money?" 
            wire:model="makeMoney"
            required
        />
        <x-select
            label="Is your company already generating revenue?" 
            wire:model="generatingRevenue"
            :options="[
                ['id' => 'Yes', 'name' => 'Yes'],
                ['id' => 'No', 'name' => 'No']
            ]"
            placeholder="Select an option"
            required
        />
        <x-input
            label="How much are you raising in USD?" 
            wire:model="amountRaising"
            type="number"
            min="0"
            placeholder="Amount in $"
            required
        />
        <x-input
            label="How many months of runway will this raise give you?" 
            wire:model="monthsRunway"
            placeholder="Number of months e.g 2"
            type="number"
            max="100"
            min="0"
            required
        />
        <x-select
            label="Has your venture raised external funding till date?" 
            wire:model="externalFunding"
            :options="[
                ['id' => 'Yes', 'name' => 'Yes'],
                ['id' => 'No', 'name' => 'No']
            ]"
            placeholder="Select an option"
            required
        />
        <div class="mb-4">
            <label class="label">
                <span class="label-text">Select your top 3 Challenges as a venture Today <span class="text-red-500">*</span></span>
            </label>
            <div class="flex flex-col gap-2">
                <x-checkbox label="Access to Market" wire:model="selectedChallenges" value="Access to Market" right />
                <x-checkbox label="Branding/Marketing" wire:model="selectedChallenges" value="Branding/Marketing" right />
                <x-checkbox label="Customer Acquisition" wire:model="selectedChallenges" value="Customer Acquisition" right />
                <x-checkbox label="Funding" wire:model="selectedChallenges" value="Funding" right />
                <x-checkbox label="Hiring" wire:model="selectedChallenges" value="Hiring" right />
                <x-checkbox label="HR" wire:model="selectedChallenges" value="HR" right />
                <x-checkbox label="Legal" wire:model="selectedChallenges" value="Legal" right />
                <x-checkbox label="Operations" wire:model="selectedChallenges" value="Operations" right />
                <x-checkbox label="Product/Technology" wire:model="selectedChallenges" value="Product/Technology" right />
                <x-checkbox label="Strategy" wire:model="selectedChallenges" value="Strategy" right />
            </div>
        </div>
        <div class="mb-4">
            <label for="pitchDeck" class="label">
                <span class="label-text">Upload Pitch Deck <span class="text-red-500">*</span></span>
            </label>
            <input 
                type="file" 
                id="pitchDeck" 
                accept="application/pdf" 
                onchange="uploadToFirebase(event, 'pitchDeck_url', 'pitchDeck_status', 'pitchDeck_progress')" 
            />
            <input type="hidden" wire:model="pitchDeck_url" />
            <div id="pitchDeck_status" class="mt-2"></div>
            <div id="pitchDeck_progress" class="mt-2 hidden">
                <progress class="progress progress-primary w-full" value="0" max="100"></progress>
                <span id="pitchDeck_percentage" class="text-sm">0%</span>
            </div>
        </div>

        <script>
            (function() {
                let firebaseInitialized = false;
                const config = {
                    apiKey: "{{ env('FIREBASE_API_KEY') }}",
                    authDomain: "{{ env('FIREBASE_AUTH_DOMAIN') }}",
                    projectId: "{{ env('FIREBASE_PROJECT_ID') }}",
                    storageBucket: "{{ env('FIREBASE_STORAGE_BUCKET') }}",
                    messagingSenderId: "{{ env('FIREBASE_MESSAGING_SENDER_ID') }}",
                    appId: "{{ env('FIREBASE_APP_ID') }}"
                };

                function initializeFirebase() {
                    if (firebaseInitialized) return;
                    
                    if (typeof firebase === 'undefined') {
                        console.error('Firebase SDK not loaded');
                        setTimeout(initializeFirebase, 1000);
                        return;
                    }

                    try {
                        if (!firebase.apps.length) {
                            firebase.initializeApp(config);
                        }
                        firebaseInitialized = true;
                        // console.log('Firebase initialized successfully');
                        
                        // Get user from data attribute
                        const rootElement = document.querySelector('[data-firebase-user]');
                        const sessionUser = rootElement?.dataset.firebaseUser;
                        const sessionToken = rootElement?.dataset.firebaseToken;

                        if (sessionUser) {
                            // console.log('User authenticated via session');
                            return;
                        }

                        // Only check Firebase auth if no session user
                        firebase.auth().onAuthStateChanged(user => {
                            if (!user && !sessionUser) {
                                // console.log('No user found in session or Firebase, redirecting to login...');
                                // console.log(sessionUser);
                                // window.location.href = '/login';
                            } else {
                                // console.log('User authenticated:', user?.uid || sessionUser);
                            }
                        });
                    } catch (error) {
                        console.error('Firebase initialization error:', error);
                        setTimeout(initializeFirebase, 1000);
                    }
                }

                // Initialize Firebase when DOM is loaded
                document.addEventListener('DOMContentLoaded', initializeFirebase);

                // Initialize Firebase immediately as well
                initializeFirebase();

                window.uploadToFirebase = function(event, modelName, statusElementId, progressElementId, retries = 3) {
                    if (!firebaseInitialized) {
                        console.warn('Firebase not initialized, retrying...');
                        if (retries > 0) {
                            setTimeout(() => window.uploadToFirebase(event, modelName, statusElementId, progressElementId, retries - 1), 1000);
                        } else {
                            alert('Upload system not ready. Please refresh the page.');
                        }
                        return;
                    }

                    // Get user from data attribute
                    const rootElement = document.querySelector('[data-firebase-user]');
                    const sessionUser = rootElement?.dataset.firebaseUser;

                    if (sessionUser) {
                        // console.log('Using session user for upload:');
                        proceedWithUpload(event, modelName, statusElementId, progressElementId, sessionUser);
                        return;
                    }

                    // Fallback to Firebase auth
                    const user = firebase.auth().currentUser;
                    if (!user) {
                        // console.log('No user found, checking auth state...');
                        firebase.auth().onAuthStateChanged(user => {
                            if (user) {
                                // console.log('User authenticated via Firebase, proceeding with upload...');
                                proceedWithUpload(event, modelName, statusElementId, progressElementId, user.uid);
                            } else {
                                // console.log('No user found, redirecting to login...');
                                window.location.href = '/login';
                            }
                        });
                    } else {
                        proceedWithUpload(event, modelName, statusElementId, progressElementId, user.uid);
                    }
                };

                function proceedWithUpload(event, modelName, statusElementId, progressElementId, userId) {
                    const file = event.target.files[0];
                    if (!file) {
                        console.error('No file');
                        alert('No file selected');
                        return;
                    }
                    if (file.type !== 'application/pdf') {
                        console.error('Invalid type:', file.type);
                        alert('Only PDFs allowed');
                        return;
                    }

                    const statusElement = document.getElementById(statusElementId);
                    const progressElement = document.getElementById(progressElementId);
                    const progressBar = progressElement.querySelector('progress');
                    const percentageElement = document.getElementById('pitchDeck_percentage');

                    statusElement.innerHTML = `<svg class="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
                    progressElement.classList.remove('hidden');
                    progressBar.value = 0;
                    percentageElement.textContent = '0%';

                    const storage = firebase.storage();
                    const storageRef = storage.ref(`document/${file.name}_${Date.now()}`);
                    
                    const uploadTask = storageRef.put(file);
                    
                    uploadTask.on('state_changed',
                        snapshot => {
                            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                            progressBar.value = progress;
                            percentageElement.textContent = `${Math.round(progress)}%`;
                        },
                        error => {
                            console.error('Upload failed:', error);
                            alert('Upload failed: ' + error.message);
                            statusElement.innerHTML = `<svg class="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>`;
                            progressElement.classList.add('hidden');
                        },
                        () => {
                            uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
                                @this.set(modelName, downloadURL);
                                Livewire.dispatch('set', { model: modelName, value: downloadURL });
                                statusElement.innerHTML = `<svg class="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>`;
                                progressElement.classList.add('hidden');
                            }).catch(error => {
                                console.error('URL fetch failed:', error);
                                alert('Failed to get URL');
                                statusElement.innerHTML = '';
                                progressElement.classList.add('hidden');
                            });
                        }
                    );
                }
            })();
        </script>
        <x-textarea
            label="Link(s) to demo or other relevant documents"
            wire:model="relevantDocuments"
            placeholder="Please include links to any relevant documents or materials for us to better understand your venture"
        />
        <div class="mb-4">
            <label class="label">
                <span class="label-text">How did you hear about us? <span class="text-red-500">*</span></span>
            </label>
            <div class="flex flex-col gap-2">
                @foreach([
                    ['id' => 'Social Media (LinkedIn, Twitter, Instagram)', 'name' => 'Social Media (LinkedIn, Twitter, Instagram)'],
                    ['id' => 'Investor Referral', 'name' => 'Investor Referral'],
                    ['id' => 'Incubator/Accelerator/Hub Referral', 'name' => 'Incubator/Accelerator/Hub Referral'],
                    ['id' => 'Google Search', 'name' => 'Google Search'],
                    ['id' => 'Event', 'name' => 'Event'],
                    ['id' => 'Other', 'name' => 'Other']
                ] as $option)
                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-2">
                            <input 
                                type="radio" 
                                wire:model="referral" 
                                value="{{ $option['id'] }}" 
                                class="radio radio-primary" 
                                required 
                            />
                            <span class="label-text">{{ $option['name'] }}</span>
                        </label>
                    </div>
                @endforeach
            </div>
        </div>
        <x-textarea
            label="Please Tell Us More Details About How You Heard About Us"
            wire:model="details"
            placeholder="If referral, please include name/organization of referee. If event, please include event name"
        />
        <div class="mb-4">
            <label class="label">
                <span class="label-text">Sign Up to mailing list <span class="text-red-500">*</span></span>
            </label>
            <div class="flex flex-col gap-2">
                @foreach([
                    ['id' => 'Yes', 'name' => 'Yes'],
                    ['id' => 'No', 'name' => 'No']
                ] as $option)
                    <div class="form-control">
                        <label class="label cursor-pointer justify-start gap-2">
                            <input 
                                type="radio" 
                                wire:model="mailing" 
                                value="{{ $option['id'] }}" 
                                class="radio radio-primary" 
                                required 
                            />
                            <span class="label-text">{{ $option['name'] }}</span>
                        </label>
                    </div>
                @endforeach
            </div>
        </div>
        <x-slot:actions>
            <x-button 
                label="Submit" 
                class="btn-secondary" 
                type="submit"
                responsive
                spinner="submitForm"
                icon="o-check-circle"
            />
        </x-slot:actions>
    </x-form>
</div>