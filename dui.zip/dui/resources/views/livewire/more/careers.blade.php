<div class="container mx-auto p-6">
    <div class="text-center mb-12 space-y-4">
        <x-header title="Job Finder" separator progress-indicator class="justify-center" />
        <x-button 
            label="Post a Free Job" 
            wire:click="openCreateJobModal" 
            icon="o-plus" 
            class="btn-secondary transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
            spinner
        />
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
        <div class="group relative overflow-hidden rounded-2xl transition-all duration-300 hover:-translate-y-2">
            <div class="absolute inset-0 bg-gradient-to-r from-red-600 to-red-400 transform transition-transform duration-500 group-hover:scale-105"></div>
            <div class="relative p-6 text-white">
                <h3 class="text-xl font-bold">Remote Job</h3>
                <p class="mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">Work from anywhere in the world</p>
            </div>
        </div>
        <div class="group relative overflow-hidden rounded-2xl transition-all duration-300 hover:-translate-y-2">
            <div class="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-400 transform transition-transform duration-500 group-hover:scale-105"></div>
            <div class="relative p-6 text-white">
                <h3 class="text-xl font-bold">On Site Job</h3>
                <p class="mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">Permanent positions available</p>
            </div>
        </div>
        <div class="group relative overflow-hidden rounded-2xl transition-all duration-300 hover:-translate-y-2">
            <div class="absolute inset-0 bg-gradient-to-r from-green-600 to-green-400 transform transition-transform duration-500 group-hover:scale-105"></div>
            <div class="relative p-6 text-white">
                <h3 class="text-xl font-bold">Hybrid</h3>
                <p class="mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">Flexible working hours</p>
            </div>
        </div>
    </div>

    <div class="mt-12">
        <h2 class="text-3xl font-bold mb-8 text-gray-800 dark:text-gray-100 text-center">Find Your Dream Job</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @forelse($jobs as $job)
                @php
                    $gradients = [
                        'remote' => 'bg-gradient-to-br from-red-300 to-red-100 dark:from-red-600 dark:to-red-900',
                        'onsite' => 'bg-gradient-to-br from-blue-300 to-blue-100 dark:from-blue-600 dark:to-blue-900',
                        'hybrid' => 'bg-gradient-to-br from-green-300 to-green-100 dark:from-green-600 dark:to-green-900',
                        'default' => 'bg-gradient-to-br from-gray-300 to-gray-100 dark:from-gray-600 dark:to-gray-900',
                    ];
                    $bgGradient = $gradients[$job['jobType'] ?? 'default'];
                @endphp
                <div class="group relative {{ $bgGradient }} p-6 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 overflow-hidden">
                    <div class="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-10 -mt-10 transform transition-transform group-hover:scale-150 duration-500"></div>
                    
                    <div class="relative">
                        <span class="inline-block px-3 py-1 bg-white/90 dark:bg-gray-800/90 text-sm font-medium rounded-full mb-4 shadow-sm dark:text-gray-100">
                            {{ $job['type'] ?? 'Job Opening' }}
                        </span>
                        <h3 class="text-xl font-bold mb-2 text-gray-800 dark:text-gray-100">{{ $job['title'] }}</h3>
                        <div class="space-y-2 mb-4">
                            <p class="flex items-center text-gray-600 dark:text-gray-300">
                                <x-icon name="o-building-office" class="w-4 h-4 mr-2" />
                                {{ $job['company'] }}
                            </p>
                            <p class="flex items-center text-gray-600 dark:text-gray-300">
                                <x-icon name="o-map-pin" class="w-4 h-4 mr-2" />
                                {{ $job['location'] }}
                            </p>
                        </div>
                        <p class="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">{{ $job['roleOverview'] }}</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">Posted: {{ $job['datePosted'] }}</p>
                    </div>
                    
                    <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <div class="flex flex-wrap gap-2">
                            <button 
                                wire:click="openjobDetailsModal({{ $loop->index }})" 
                                class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-300"
                            >
                                More Details
                                <x-icon name="o-arrow-right" class="w-4 h-4 ml-2" />
                            </button>
                            @if($job['userId'] === session('firebase_user'))
                                <button 
                                    wire:click="openEditJobModal({{ $loop->index }})" 
                                    class="inline-flex items-center px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors duration-300"
                                >
                                    Edit Job
                                    <x-icon name="o-pencil" class="w-4 h-4 ml-2" />
                                </button>
                                <button 
                                    wire:click="openDeleteJobModal({{ $loop->index }})" 
                                    class="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-300"
                                >
                                    Delete Job
                                    <x-icon name="o-trash" class="w-4 h-4 ml-2" />
                                </button>
                            @endif
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-3 text-center py-12">
                    <x-icon name="o-document-magnifying-glass" class="w-16 h-16 mx-auto text-gray-400 dark:text-gray-600 mb-4" />
                    <p class="text-gray-500 dark:text-gray-400 text-lg">No jobs found. Check back later!</p>
                </div>
            @endforelse
        </div>
    </div>

    <x-modal wire:model="createJobModal" class="backdrop-blur" persistent>
        <div class="dark:bg-gray-800">
            <x-header title="Post a new Job" />
            <x-form wire:submit="createJob">
                <x-input label="Company Name" wire:model="companyName" icon="o-building-office" inline />
                <x-input label="Job Title" wire:model="jobTitle" icon="o-user" inline />
                <x-input label="Salary Range e.g 'Kshs 50k - 200k'" wire:model="salaryRange" icon="o-banknotes" inline />
                <x-input label="Location e.g Nairobi" wire:model="location" icon="o-map-pin" inline />
                <x-input label="Job Level e.g Senior" wire:model="jobLevel" icon="o-user-group" inline />
                <x-input label="Website/Email" wire:model="website" inline icon="o-link" />
                <x-textarea label="About Us" wire:model="aboutUs" icon="o-chat-bubble-bottom-center" inline />
                <x-textarea label="Role Overview" wire:model="roleOverview" inline />
                <x-tags label="Responsibilities" wire:model="responsibilities" icon="o-briefcase" hint="Hit enter to create a new tag" />
                <x-tags label="Requirements" wire:model="requirements" icon="o-document-check" hint="Hit enter to create a new tag" />
                <x-checkbox label="Is it Full Time?" wire:model="isFullTime" inline />

                <x-radio 
                    label="Select one" 
                    :options="[
                        ['id' => 'remote', 'name' => 'Remote'],
                        ['id' => 'hybrid', 'name' => 'hybrid'],
                        ['id' => 'onsite', 'name' => 'On Site'],
                    ]" 
                    wire:model="jobType" 
                />
                <x-slot:actions>
                    <x-button label="Close" wire:click="closeCreateJobModal" spinner />
                    <x-button label="Add Career" type="submit" class="btn btn-secondary" spinner="createJob" />
                </x-slot:actions>
            </x-form>
        </div>
    </x-modal>

    <x-modal wire:model="editJobModal" class="backdrop-blur" persistent>
        <div class="dark:bg-gray-800">
            <x-header title="Edit Job" />
            <x-form wire:submit="updateJob">
                <x-input label="Company Name" wire:model="companyName" icon="o-building-office" inline />
                <x-input label="Job Title" wire:model="jobTitle" icon="o-user" inline />
                <x-input label="Salary Range e.g Kshs 50k - 200k'" wire:model="salaryRange" icon="o-banknotes" inline />
                <x-input label="Location e.g Nairobi" wire:model="location" icon="o-map-pin" inline />
                <x-input label="Job Level" wire:model="jobLevel" icon="o-user-group" inline />
                <x-input label="Website" wire:model="website" inline icon="o-link" />
                <x-textarea label="About Us" wire:model="aboutUs" icon="o-chat-bubble-bottom-center" inline />
                <x-textarea label="Role Overview" wire:model="roleOverview" inline />
                <x-tags label="Responsibilities" wire:model="responsibilities" icon="o-briefcase" hint="Hit enter to create a new tag" />
                <x-tags label="Requirements" wire:model="requirements" icon="o-document-check" hint="Hit enter to create a new tag" />
                <x-checkbox label="Is it Full Time?" wire:model="isFullTime" inline />

                <x-radio 
                    label="Select one" 
                    :options="[
                        ['id' => 'remote', 'name' => 'Remote'],
                        ['id' => 'hybrid', 'name' => 'hybrid'],
                        ['id' => 'onsite', 'name' => 'On Site'],
                    ]" 
                    wire:model="jobType" 
                />
                <x-slot:actions>
                    <x-button label="Close" wire:click="closeEditJobModal" spinner />
                    <x-button label="Update Career" type="submit" class="btn btn-secondary" spinner="updateJob" />
                </x-slot:actions>
            </x-form>
        </div>
    </x-modal>

    <x-modal wire:model="jobDetailsModal">
        @if($selectedJob)
            <div class="p-6 dark:bg-gray-800">
                <h2 class="text-xl font-bold dark:text-gray-100">{{ $selectedJob['title'] }}</h2>
                <div class="mt-4">
                    <div class="flex">
                        <x-icon name="o-building-office" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['company'] }}</p>
                    </div>
                    <br />
                    <div class="flex">
                        <x-icon name="o-map-pin" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['location'] }}</p>
                    </div>
                    <br />
                    <div class="flex">
                        <x-icon name="o-currency-dollar" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['salary'] }}</p>
                    </div>
                    <br />
                    <div class="flex">
                        <x-icon name="o-briefcase" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['jobType'] }}</p>
                    </div>
                    <br />
                    <div class="flex">
                        <x-icon name="o-document-text" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['roleOverview'] }}</p>
                    </div>
                    <br />
                    <div class="flex">
                        <x-icon name="o-calendar" class="w-5 h-5 text-blue-500 mr-2" />
                        <p class="dark:text-gray-300">{{ $selectedJob['datePosted'] }}</p>
                    </div>
                    <br />
                    <div>
                        <h3 class="text-lg font-bold mb-2 dark:text-gray-100">Key Responsibilities</h3>
                        <ul class="list-disc list-inside">
                            @foreach($selectedJob['responsibilities'] as $responsibility)
                                <li class="text-gray-700 dark:text-gray-300 mb-2">{{ $responsibility }}</li>
                            @endforeach
                        </ul>
                    </div>
                    <br />
                    <div>
                        <h3 class="text-lg font-bold mb-2 dark:text-gray-100">Requirements</h3>
                        <ul class="list-disc list-inside">
                            @foreach($selectedJob['requirements'] as $requirement)
                                <li class="text-gray-700 dark:text-gray-300 mb-2">{{ $requirement }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <x-slot:actions>
                    <a 
                        href="{{ strpos($selectedJob['website'], 'http') === 0 ? $selectedJob['website'] : 'http://' . $selectedJob['website'] }}" 
                        target="_blank" 
                        class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-300"
                    >
                        Apply Now
                        <x-icon name="o-arrow-right" class="w-4 h-4 ml-2" />
                    </a>
                </x-slot:actions>
            </div>
        @endif
    </x-modal>
    
    <!-- Delete Job Confirmation Modal -->
    <x-modal wire:model="deleteJobModal">
        <x-slot name="title">Delete Job</x-slot>
            <p>Are you sure you want to delete this job?</p>
        <x-slot:actions>
            <x-button wire:click="deleteJob" label="Delete" class="bg-red-600" spinner="deleteJob" />
            <x-button wire:click="closeDeleteJobModal" label="Cancel" class="bg-secondary" />
        </x-slot:actions>
    </x-modal>

</div>