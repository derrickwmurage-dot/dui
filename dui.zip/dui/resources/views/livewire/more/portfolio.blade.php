<div>
    <x-header title="My Portfolio" subtitle="These are the startups you've invested in" />
    <div class="container mx-auto p-4">
        @if(empty($marketplaceData))
            <div class="flex flex-col items-center justify-center h-64">
                <x-icon name="o-x-circle" class="w-24 h-24 text-gray-500" />
                <p class="text-gray-600 dark:text-gray-400 mt-4">No items in your portfolio yet.</p>
            </div>
        @else
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($marketplaceData as $index => $data)
                    <div class="group bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl cursor-pointer" wire:click="openMarketplaceModal({{ $index }})">
                        <!-- Image Container with Overlay -->
                        <div class="relative h-64 overflow-hidden">
                            <img 
                                src="{{ $data['imageUrl'][0] }}" 
                                alt="{{ $data['title'] }}" 
                                class="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                            >
                            <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            </div>
                        </div>

                        <!-- Content -->
                        <div class="p-6">
                            <h5 class="text-xl font-bold mb-3 text-gray-800 dark:text-gray-100 line-clamp-1">
                                {{ $data['title'] }}
                            </h5>
                            <p class="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3 text-sm leading-relaxed">{{ $data['description'] }}</p>
                            <p class="text-gray-800 dark:text-gray-200 font-medium text-lg">${{ number_format($data['companyAsk'], 0, '.', ',') }}</p>
                            
                            <!-- Equity Display -->
                            <div class="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                                <div class="flex space-x-4">
                                    @foreach($data['investors'] as $investor)
                                        @if($investor['investorId'] === session('firebase_user') && $investor['investmentComplete'] === true)
                                            <p class="text-gray-800 dark:text-gray-200 font-medium text-lg">Equity: {{ number_format($investor['equity'], 2) }}%</p>
                                        @endif
                                    @endforeach
                                </div>
                            </div>

                            <!-- Interaction Bar -->
                            <div class="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                                <div class="flex space-x-4">
                                    <button 
                                        wire:click.stop="toggleInterest({{ $index }}, 'interest')"
                                        class="group/btn flex items-center space-x-1 transition-colors {{ isset($data['showedInterestUsers']) && in_array(session('firebase_user'), $data['showedInterestUsers']) ? 'text-green-500' : 'text-gray-500 dark:text-gray-400 hover:text-green-500' }}"
                                    >
                                        <x-icon name="o-hand-thumb-up" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                        <span class="text-sm font-medium">{{ count($data['showedInterestUsers'] ?? []) }}</span>
                                    </button>
                                    <button 
                                        wire:click.stop="toggleInterest({{ $index }}, 'disinterest')"
                                        class="group/btn flex items-center space-x-1 transition-colors {{ isset($data['showedDisinterestUsers']) && in_array(session('firebase_user'), $data['showedDisinterestUsers']) ? 'text-red-500' : 'text-gray-500 dark:text-gray-400 hover:text-red-500' }}"
                                    >
                                        <x-icon name="o-hand-thumb-down" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                        <span class="text-sm font-medium">{{ count($data['showedDisinterestUsers'] ?? []) }}</span>
                                    </button>
                                    <button 
                                        wire:click.stop="openComments({{ $index }})"
                                        class="group/btn flex items-center space-x-1 text-gray-500 dark:text-gray-400 hover:text-blue-500 transition-colors"
                                    >
                                        <x-icon name="o-chat-bubble-bottom-center-text" class="w-5 h-5 transition-transform group-hover/btn:scale-110" />
                                        <span class="text-sm font-medium">{{ count($data['reviews'] ?? []) }}</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    <!-- Marketplace Modal -->
    <x-modal wire:model="marketplaceModal" max-width="4xl">
        @if($modalData)
            <div class="relative overflow-hidden rounded-xl bg-white dark:bg-gray-800">
                <div class="relative h-[60vh] transform transition-transform duration-1000 hover:scale-105">
                    <img 
                        src="{{ $modalData['imageUrl'][0] }}" 
                        alt="{{ $modalData['title'] }}" 
                        class="absolute inset-0 w-full h-full object-cover"
                    >
                    <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                    
                    <div class="absolute bottom-0 left-0 right-0 p-8 text-white">
                        <h2 class="text-4xl font-bold mb-2 transform transition-all duration-500 translate-y-0">
                            {{ $modalData['title'] }}
                        </h2>
                    </div>
                </div>

                <div class="mt-4 text-gray-800 dark:text-gray-200">
                    {{ $modalData['description'] }}
                    <hr class="border-gray-200 dark:border-gray-700" />
                </div>

                <div class="p-6">
                    <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Company Valuation:</b> ${{ number_format($companyValuation, 2) }}</p>
                    <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Company Ask: </b> ${{ number_format($modalData['companyAsk'], 2) }}</p>
                    <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Equity Stake:</b> {{ number_format($equityAmount * 100, 2) }}%</p>
                    <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Current Number of Investors:</b> {{ $modalData['noOfInvestors'] }}</p>
                    <p class="text-gray-600 dark:text-gray-400 mb-4"><b>Amount Raised:</b> ${{ number_format($modalData['amountInvested'], 2) }}</p>
                    
                    <x-button link="/marketplace/info/{{ $modalData['id'] }}" class="btn-secondary" label="More Info here" icon="o-information-circle" spinner />
                </div>
            </div>
        @endif
    </x-modal>
</div>