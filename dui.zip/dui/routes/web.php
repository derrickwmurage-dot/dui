<?php

use App\Livewire\Welcome;
use Illuminate\Support\Facades\Route;
use App\Livewire\Dashboard;

use Illuminate\Support\Facades\Mail;

use App\Livewire\More\ForInvestment;
use App\Livewire\More\Careers;
use App\Livewire\More\ToInvest;
use App\Livewire\More\WishList;
use App\Livewire\More\Portfolio;
use App\Livewire\More\Pay;

use App\Livewire\Profile\PrivacyPolicy;
use App\Livewire\Profile\KYC;
use App\Livewire\Profile\BusinessVerification;
use App\Livewire\Profile\TermsOfService;

use App\Livewire\AdvisoryServices;
use App\Livewire\CollaborativeSpaces;
use App\Livewire\Home;
use App\Livewire\Marketplace;
use App\Livewire\Profile;

use App\Livewire\AdvisoryServices\ServiceProviders;

use App\Livewire\Marketplace\Comments;
use App\Livewire\Marketplace\Info;
use App\Livewire\Marketplace\Investors;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\SubscriptionController;
use App\Htpp\Controllers\InvestorSubscriptionController;
use App\Http\Controllers\CollaborativeSpacesPaymentController;
use App\Http\Controllers\MarketplacePaymentController;
use App\Http\Controllers\MarketplaceController;
use App\Http\Middleware\FirebaseAuth;

use App\Http\Controllers\CollaborativeSpacesController;
use App\Http\Controllers\ServiceProvidersPaymentController;
use App\Http\Controllers\BookingApprovalController;
use App\Http\Controllers\ServiceProviderApprovalController;
use App\Http\Controllers\KYCController;
use App\Http\Controllers\InvestorApplicationController;
use App\Http\Controllers\FileUploadController;

use App\Http\Controllers\ContactController;
use App\Http\Controllers\ImageUploadController;
use Illuminate\Support\Facades\Storage;

use App\Mail\TestMail;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('homepage');
})->name('homepage')->withoutMiddleware([FirebaseAuth::class]);



Route::middleware([FirebaseAuth::class])->group(function () {
    Route::get('/dashboard', function() { return redirect()->route('home');})->name('dashboard');
    Route::get('/more/for-investment', ForInvestment::class)->name('more.for-investment');
    Route::get('/more/careers', Careers::class)->name('more.careers');
    Route::get('/more/to-invest', ToInvest::class)->name('more.to-invest');
    Route::get('/more/wishlist', WishList::class)->name('more.wishlist');
    Route::get('/more/portfolio', Portfolio::class)->name('more.portfolio');
    Route::get('/more/pay', Pay::class)->name('more.pay');
    Route::get('/home', Home::class)->name('home');
    Route::get('/marketplace', Marketplace::class)->name('marketplace');
    // Route::get('/marketplace/comments/{index}', Comments::class)->name('marketplace.comments');
    Route::get('/marketplace/comments/{id}', Comments::class)->name('marketplace.comments');
    Route::get('/marketplace/info/{id}', Info::class)->name('marketplace.info');
    Route::get('/marketplace/payment/callback', [MarketplacePaymentController::class, 'handleCallback'])->name('marketplace.callback');
    Route::get('/marketplace/investors/{id}', Investors::class)->name('marketplace.investors');
    Route::post('/marketplace/store', [MarketplaceController::class, 'store'])->name('marketplace.store');
    Route::get('/advisory-services', AdvisoryServices::class)->name('advisory-services.new');
    Route::get('/advisory-services/service-providers', ServiceProviders::class)->name('advisory-services.service-providers');
    Route::get('/advisory-services/{serviceType}', ServiceProviders::class)->name('advisory-services');
    Route::get('/service-providers/callback', [ServiceProvidersPaymentController::class, 'handleCallback'])->name('service-providers.callback');
    Route::get('/collaborative-spaces', CollaborativeSpaces::class)->name('collaborative-spaces');
    Route::get('/collaborative-spaces/callback', [CollaborativeSpacesController::class, 'handleCallback'])->name('collaborative-spaces.callback');
    Route::get('/profile', Profile::class)->name('profile');

    Route::get('/profile/privacy-policy', PrivacyPolicy::class)->name('profile.privacy-policy');
    Route::get('/profile/kyc', KYC::class)->name('profile.kyc');
    Route::get('/profile/business-verification', BusinessVerification::class)->name('profile.business-verification');
    Route::get('/profile/terms-and-conditions', TermsOfService::class)->name('profile.terms-and-conditions');  
    Route::post('/kyc/store', [KYCController::class, 'store'])->name('kyc.store');
    Route::post('/investor-application/store', [InvestorApplicationController::class, 'store'])->name('investor-application.store');

    // File upload routes
    Route::post('/more/to-invest/uploadProofOfResidence', [FileUploadController::class, 'uploadProofOfResidence'])->name('to-invest.uploadProofOfResidence');
    Route::post('/more/to-invest/uploadSourceOfFunds', [FileUploadController::class, 'uploadSourceOfFunds'])->name('to-invest.uploadSourceOfFunds');

    Route::post('/more/for-investment/uploadPitchdeck', [FileUploadController::class, 'uploadPitchdeck'])->name('for-investment.uploadPitchdeck');

    Route::post('/profile/kyc/uploadIdPhoto', [ImageUploadController::class, 'uploadIdPhoto'])->name('kyc.uploadIdPhoto');
    Route::post('/profile/kyc/uploadProfilePhoto', [ImageUploadController::class, 'uploadProfilePhoto'])->name('kyc.uploadProfilePhoto');

    Route::post('/marketplace/imageUpload', [ImageUploadController::class, 'uploadMarketplaceImage'])->name('marketplace.imageUpload');
    Route::post('/marketplace/uploadFile', [FileUploadController::class, 'uploadMarketplaceFile'])->name('marketplace.uploadFile');
});

Route::post('/payments/initiate', [PaymentController::class, 'initiatePayment'])->withoutMiddleware([FirebaseAuth::class])->name('payments.initiate');
Route::get('/payments/verify/{transactionId}', [PaymentController::class, 'verifyPayment'])->withoutMiddleware([FirebaseAuth::class])->name('payments.verify');

Route::get('/login', [AuthController::class, 'showLoginForm'])
    ->name('login')
    ->withoutMiddleware([FirebaseAuth::class]);

Route::post('/login', [AuthController::class, 'login'])
    ->name('login')
    ->withoutMiddleware([FirebaseAuth::class]);Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register')->withoutMiddleware([FirebaseAuth::class]);
Route::post('/register', [AuthController::class, 'register']);
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::post('/auth/google/callback', [AuthController::class, 'handleGoogleCallback'])->name('auth.google.callback')->withoutMiddleware([FirebaseAuth::class]);

Route::get('session-details', function () {
    return session()->all();
})->withoutMiddleware([FirebaseAuth::class])->name('session.details');

Route::get('/password-reset', function () {
    return view('password-reset');
})->name('password.reset')->withoutMiddleware([FirebaseAuth::class]);

Route::post('/password-reset', [AuthController::class, 'sendResetPasswordEmail'])->name('password.reset')->withoutMiddleware([FirebaseAuth::class]);

// Route::get('/auth/firebase-config', [AuthController::class, 'getFirebaseConfig'])->name('auth.firebase.config')->withoutMiddleware([FirebaseAuth::class]);

Route::get('/subscription/callback', [SubscriptionController::class, 'handleSubscriptionCallback'])->name('subscription.callback')->withoutMiddleware([FirebaseAuth::class]);
// Route::get('/subscription/initiate', [SubscriptionController::class, 'initiateSubscription'])->name('subscription.initiate')->withoutMiddleware([FirebaseAuth::class]);
Route::get('/investor-subscription/callback', [InvestorSubscriptionController::class, 'handleCallback'])->name('investor-subscription.callback')->withoutMiddleware([FirebaseAuth::class]);
Route::get('/investor-subscription/initiate', [InvestorSubscriptionController::class, 'initiatePayment'])->name('investor-subscription.initiate')->withoutMiddleware([FirebaseAuth::class]);

Route::get('/collaborative-spaces/payment/initiate', [CollaborativeSpacesPaymentController::class, 'initiatePayment'])
    ->name('collaborative-spaces.payment.initiate')
    ->withoutMiddleware([FirebaseAuth::class]);

Route::get('/collaborative-spaces/payment/callback', [CollaborativeSpacesPaymentController::class, 'handleCallback'])
    ->name('collaborative-spaces.payment.callback')
    ->withoutMiddleware([FirebaseAuth::class]);


Route::get('/approve-booking/{id}', [BookingApprovalController::class, 'showApprovalForm'])->name('approve-booking')->withoutMiddleware([FirebaseAuth::class]);
Route::post('/approve-booking/{id}', [BookingApprovalController::class, 'approveBooking'])->name('approve-booking.submit')->withoutMiddleware([FirebaseAuth::class]);

Route::get('/approve-service-booking/{id}', [ServiceProviderApprovalController::class, 'showApprovalForm'])->name('approve-service-booking');
Route::post('/approve-service-booking/{id}', [ServiceProviderApprovalController::class, 'approveBooking'])->name('approve-service-booking.submit');

// Route::get('/contact', [ContactController::class, 'showContactForm'])->name('contact.show');
// Route::post('/contact', [ContactController::class, 'sendContactForm'])->name('contact.send');

Route::post('/send-contact', [ContactController::class, 'send'])->name('contact.send');

Route::get('/send-test-email', function () {
    Mail::to('munyaolance1@gmail.com')->send(new TestMail());
    return 'Test email sent!';
})->middleware([FirebaseAuth::class]);
