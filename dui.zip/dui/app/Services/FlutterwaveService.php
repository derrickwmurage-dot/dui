<?php
namespace App\Services;

use Illuminate\Support\Facades\Http;

class FlutterwaveService
{
    protected string $baseUrl;
    protected string $secretKey;

    public function __construct()
    {
        $this->baseUrl = config('services.flutterwave.base_url');
        $this->secretKey = config('services.flutterwave.secret_key');
    }

    public function initiatePayment(array $data)
    {
        $response = Http::withToken($this->secretKey)
            ->post("{$this->baseUrl}/payments", $data);

        if ($response->successful()) {
            return $response->json();
        } else {
            return [
                'status' => 'error',
                'message' => 'Payment initiation failed.',
                'data' => $response->json()
            ];
        }
    }

    public function verifyPayment($transactionId)
    {
        $response = Http::withToken($this->secretKey)
            ->get("{$this->baseUrl}/transactions/{$transactionId}/verify");

        if ($response->successful()) {
            return $response->json();
        } else {
            return [
                'status' => 'error',
                'message' => 'Payment verification failed.',
                'data' => $response->json()
            ];
        }
    }
}
