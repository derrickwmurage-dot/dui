<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class PaystackService
{
    protected string $secretKey;

    public function __construct()
    {
        $this->secretKey = config('services.paystack.secret');
    }

    public function initiatePayment(array $data)
    {
        $response = Http::withToken($this->secretKey)
            ->post('https://api.paystack.co/transaction/initialize', $data);

        return $response->json();
    }

    public function verifyPayment($reference)
    {
        $response = Http::withToken($this->secretKey)
            ->get("https://api.paystack.co/transaction/verify/{$reference}");

        return $response->json();
    }
}