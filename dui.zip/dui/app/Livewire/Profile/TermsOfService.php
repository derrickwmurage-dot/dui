<?php

namespace App\Livewire\Profile;

use Livewire\Component;

class TermsOfService extends Component
{
    public function render()
    {
        return view('livewire.profile.terms-of-service');
    }
}
