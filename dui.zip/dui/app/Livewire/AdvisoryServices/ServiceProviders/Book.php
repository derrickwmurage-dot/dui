<?php

namespace App\Livewire\AdvisoryServices\ServiceProviders;

use Livewire\Component;

class Book extends Component
{
    public function render()
    {
        return view('livewire.advisory-services.service-providers.book');
    }
}
