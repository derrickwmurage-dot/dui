<?php

namespace App\Livewire\More;

use Livewire\Component;

class Pay extends Component
{
    public function render()
    {
        return view('livewire.more.pay');
    }
}
