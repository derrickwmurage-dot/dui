<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class SubscriptionExpiryReminder extends Mailable
{
    public $name;
    public $subscriptionMessage;

    public function __construct($name, $subscriptionMessage)
    {
        $this->name = $name;
        $this->subscriptionMessage = (string) $subscriptionMessage; // Ensure it's a string
        error_log("CHECKPOINT_MAIL_MESSAGE: " . gettype($this->subscriptionMessage) . " - " . $this->subscriptionMessage);
    }

    public function build()
    {
        return $this->subject('Subscription Expiry Reminder')
                    ->view('emails.subscription_expiry')
                    ->with([
                        'name' => $this->name,
                        'subscriptionMessage' => $this->subscriptionMessage, // Use the new variable name
                    ]);
    }
}