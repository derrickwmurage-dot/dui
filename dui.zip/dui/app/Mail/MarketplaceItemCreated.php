<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class MarketplaceItemCreated extends Mailable
{
    use Queueable, SerializesModels;

    public $marketplaceItem;
    public $creatorName;
    public $creatorEmail;

    /**
     * Create a new message instance.
     */
    public function __construct(array $marketplaceItem, string $creatorName, string $creatorEmail)
    {
        $this->marketplaceItem = $marketplaceItem;
        $this->creatorName = $creatorName;
        $this->creatorEmail = $creatorEmail;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'New Marketplace Item Created: ' . $this->marketplaceItem['title'],
            to: [env('MAIL_ADMIN')],
            cc: [env('MAIL_CC_1'), env('MAIL_CC_2')],
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            markdown: 'emails.marketplace_item_created',
            with: [
                'marketplaceItem' => $this->marketplaceItem,
                'creatorName' => $this->creatorName,
                'creatorEmail' => $this->creatorEmail,
            ],
        );
    }

    /**
     * Get the attachments for the message.
     */
    public function attachments(): array
    {
        return [];
    }
}