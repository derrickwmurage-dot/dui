<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class PaymentConfirmation extends Mailable
{
    public $userName;
    public $amount;
    public $serviceProviderName;
    public $serviceDate;
    public $serviceTime;

    // Constructor to accept the data from the controller
    public function __construct($paymentInfo)
    {
        $this->userName = $paymentInfo['userName'];
        $this->amount = $paymentInfo['amount'];
        $this->serviceProviderName = $paymentInfo['serviceProviderName'];
        $this->serviceDate = $paymentInfo['serviceDate'];
        $this->serviceTime = $paymentInfo['serviceTime'];
    }

    public function build()
    {
        return $this->view('emails.payment-confirmation');
    }
}
