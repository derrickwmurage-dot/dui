<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class WelcomeMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public string $userEmail) {}

    public function build()
    {
        return $this->subject('Welcome to Our Platform')
            ->view('emails.welcome')
            ->attach('https://perplexing-beans-assets.vercel.app/assets/pdfs/Investor_Guide.pdf')
            ->attach('https://perplexing-beans-assets.vercel.app/assets/pdfs/Startup_Guide.pdf');
    }
}
