<?php

namespace App\Mail;

use Illuminate\Mail\Mailable;

class ProfileUpdatedMail extends Mailable
{
    public $userId;
    public $completionPercentage;
    public $profileData;

    public function __construct($userId, $completionPercentage, $profileData)
    {
        $this->userId = $userId;
        $this->completionPercentage = $completionPercentage;
        $this->profileData = is_array($profileData) ? $profileData : json_decode(json_encode($profileData), true); // Ensure it's an array
    }

    public function build()
    {
        return $this->subject('Profile Updated Notification')
                    ->view('emails.profile-updated')
                    ->with([
                        'userId' => $this->userId,
                        'completionPercentage' => $this->completionPercentage,
                        'profileData' => $this->profileData,
                    ]);
    }
}