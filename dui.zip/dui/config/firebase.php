<?php

return [
    'credentials' => env('FIREBASE_CREDENTIALS'),
];